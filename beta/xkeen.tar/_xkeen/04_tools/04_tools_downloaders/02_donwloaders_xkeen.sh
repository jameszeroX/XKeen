# Загрузка xkeen

download_xkeen() {
    if [ -z "$reinstall_xreen" ]; then
        # Получение URL для загрузки последней версии xkeen с помощью cURL и jq
        download_url=$(curl -s "$xkeen_api_url" | jq -r '.assets[0].browser_download_url')
    
        if [ -z "$download_url" ]; then
            printf "${red}Нет доступа к GitHub$ API.{reset} Проверьте соединение с интернетом или повторите позже\n"
        fi
    else
    download_url="${xkeen_tar_url}"
    unset reinstall_xreen
    fi
        # Если URL для загрузки доступен
        if [ -n "$download_url" ]; then
            filename=$(basename "$download_url")
            extension="${filename##*.}"
            
            # Создание временной директории для загрузки файла
            mkdir -p "$tmp_dir"
            
            echo -e "  ${yellow}Выполняется загрузка${reset} XKeen"
    
            # Загрузка файла с использованием cURL и сохранение его во временной директории
            curl -L -o "/tmp/$filename" "$download_url" &> /dev/null
    
            # Если файл был успешно загружен
            if [ -e "/tmp/$filename" ]; then
                mv "/tmp/$filename" "$tmp_dir/xkeen.$extension"
                echo -e "  XKeen ${green}успешно загружен${reset}"
            fi
        else
            echo -e "  ${red}Ошибка${reset}: Не удалось загрузить XKeen. Проверьте соединение с интернетом или повторите позже"
        fi
}
