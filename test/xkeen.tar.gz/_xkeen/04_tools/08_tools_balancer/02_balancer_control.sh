# Управление балансировкой по скорости: включение/выключение, автонастройка
# gRPC api Xray, cron, интерактивное меню и статус.

# Жив ли gRPC api (RoutingService). lsrules не зависит от имени балансировщика,
# поэтому годится как проба живости.
sb_api_alive() {
    xray api lsrules -s "$sb_api_addr" -timeout "${1:-3}" >/dev/null 2>&1
}

# Запущен ли Xray. Отдельно от sb_api_alive: у остановленного ядра api молчит
# независимо от того, настроен он или нет, и по одной пробе живости уже
# настроенная конфигурация неотличима от ненастроенной.
sb_xray_running() {
    pidof xray >/dev/null 2>&1
}

# Версия установленного Xray-core: второе поле первой строки `xray version`
# (формат 'Xray X.Y.Z ...', тот же вызов уже используется в diagnostic.sh).
# Пусто, если распарсить не удалось — это не ошибка сама по себе, вызывающий
# код обязан трактовать пустой результат как fail-open.
_sb_xray_version() {
    xray version 2>/dev/null | awk 'NR==1 { print $2 }'
}

# Сравнение версий вида X.Y.Z без sort -V/массивов/regex/[[ ]]: разбор по
# точкам через IFS, сравнение полей арифметикой sh. $1 — фактическая версия,
# $2 — минимально требуемая. Возврат: 0 — фактическая >= минимальной,
# 1 — фактическая < минимальной, 2 — $1 не в ожидаемом формате (только цифры
# и точки, например суффикс вида "-beta" или совсем другой вывод в будущих
# версиях) — вызывающий код обязан трактовать это как fail-open, а не как «старая».
_sb_version_ge() {
    local ver min v1 v2 v3 m1 m2 m3

    ver="$1"; min="$2"
    case "$ver" in
        ''|*[!0-9.]*) return 2 ;;
    esac

    # разбиение по точкам здесь намеренное: версия вида X.Y.Z раскладывается по IFS
    IFS='.'
    # shellcheck disable=SC2086
    set -- $ver
    unset IFS
    v1=${1:-0}; v2=${2:-0}; v3=${3:-0}
    IFS='.'
    # shellcheck disable=SC2086
    set -- $min
    unset IFS
    m1=${1:-0}; m2=${2:-0}; m3=${3:-0}

    [ "$v1" -gt "$m1" ] && return 0
    [ "$v1" -lt "$m1" ] && return 1
    [ "$v2" -gt "$m2" ] && return 0
    [ "$v2" -lt "$m2" ] && return 1
    [ "$v3" -ge "$m3" ] && return 0
    return 1
}

# Гейт минимальной версии Xray-core перед первой попыткой lsrules: подкоманда
# `xray api lsrules`, на которой держится sb_api_alive, появилась только в
# $sb_min_xray_version (RPC ListRule); на более старом ядре она падает с
# ошибкой разбора аргументов, а не просто отвечает «не жив» — без гейта
# sb_ensure_api все 20с крутит цикл ожидания и sb_status показывает generic
# «api недоступен», хотя причина известна и не требует ожидания.
# Fail-open: если версию не удалось разобрать (неожиданный или будущий формат
# вывода `xray version`), гейт не блокирует — лучше сохранить прежнее
# поведение, чем ложно отказать на исправной версии.
sb_check_xray_version() {
    local ver rc min

    # sb_min_xray_version — SSoT-константа из 01_info_variable.sh (как и
    # sb_api_addr выше); при линтинге модуля по отдельности shellcheck об этом
    # не знает.
    # shellcheck disable=SC2154
    min="$sb_min_xray_version"
    ver=$(_sb_xray_version)
    [ -n "$ver" ] || return 0

    _sb_version_ge "$ver" "$min"; rc=$?
    if [ "$rc" = "1" ]; then
        echo
        echo -e "  ${red}✗${reset} Xray-core ${yellow}$ver${reset} слишком старый для балансировки по скорости (нужен ${yellow}$min${reset}+ — используется \`xray api lsrules\`)."
        return 1
    fi
    return 0
}

# Обновить ОДИН ключ .xkeen.xray.speed_balancer.KEY = VALUE в xkeen.json, трогая
# ТОЛЬКО блок балансера. Весь остальной файл (policy, geodata, комментарии)
# сохраняется как есть — XKeen сам xkeen.json не переписывает, и балансер тоже
# не должен.
#
# Как: новый блок собирается через jq (текущий speed_balancer + этот ключ, чтобы
# сохранить значения прочих параметров), затем ТЕКСТОВО вставляется на место
# старого блока (jc_set_path — универсальная функция, см. её описание выше).
# Комментарии/формат ВНУТРИ блока балансера при этом нормализуются — блок
# машинный; всё вне блока цело.
#
# Страховка: перед записью — реальный бэкап; результат проходит синтаксис (jq -e .)
# и структуру (тем же критерием, что валидатор старта: policy, если есть, — массив
# объектов с name). При любом сбое конфиг восстанавливается из бэкапа, так что
# ошибка текстовой хирургии не оставит битый файл.
sb_write_setting() {
    local key raw val new tmp bak struct_ok rc
    key="$1"; raw="$2"
    case "$raw" in
        true|false)   val="$raw" ;;
        ''|*[!0-9]*)  val="\"$raw\"" ;;   # строка -> в кавычки
        *)            val="$raw" ;;       # число как есть
    esac

    command -v jq >/dev/null 2>&1 || { echo "  jq не найден — настройку не записать"; return 1; }
    [ -f "$xkeen_config" ] || printf '{}\n' > "$xkeen_config"

    validate_xkeen_json_syntax || return 1

    # jq без -c: блок пишется в файл человекочитаемым, по ключу на строку —
    # выравнивание по месту вставки делает сама jc_set_path.
    new=$(strip_json_comments "$xkeen_config" \
        | jq --arg k "$key" --argjson v "$val" '(.xkeen.xray.speed_balancer // {}) | .[$k] = $v' 2>/dev/null)
    [ -n "$new" ] || { echo "  Не удалось разобрать xkeen.json — настройку не записать"; return 1; }

    bak="$xkeen_config.bak"
    cp "$xkeen_config" "$bak" 2>/dev/null

    # jc_set_path сама решает: заменить существующий блок (rc=0) или вставить
    # недостающий хвост пути хоть в .xkeen.xray, хоть в .xkeen, хоть прямо в
    # корень файла, если нет вообще ничего (rc=1) — четыре прежних варианта
    # (_sb_replace_block / _sb_insert_into_xray / _sb_insert_xray_into_xkeen /
    # jq-фолбэк по всему файлу) больше не нужны, а rc=2/4 (конфликт типов или
    # битый файл) обрабатываются общей веткой отката ниже, как раньше делал
    # любой "иной" код возврата.
    tmp="$xkeen_config.sb.tmp"
    jc_set_path "xkeen.xray.speed_balancer" "$new" "$xkeen_config" > "$tmp"; rc=$?

    # Критерий структуры повторяет validate_xkeen_json (04_register_init.sh):
    # менять его надо синхронно в обоих местах.
    struct_ok='
      if has("xkeen") and .xkeen != null then
        if .xkeen.policy then
          .xkeen.policy | type == "array" and ([.[] | select(has("name") | not)] | length == 0)
        else true end
      else true end'

    # Валидируем через strip: в tmp теперь СОХРАНЕНЫ комментарии, и голый jq на
    # них упал бы, ложно забраковав корректный результат.
    if { [ "$rc" = 0 ] || [ "$rc" = 1 ]; } && strip_json_comments "$tmp" | jq -e . >/dev/null 2>&1 \
       && strip_json_comments "$tmp" | jq -e "$struct_ok" >/dev/null 2>&1 \
       && strip_json_comments "$tmp" | jq -e --arg k "$key" --argjson v "$val" '.xkeen.xray.speed_balancer[$k] == $v' >/dev/null 2>&1 \
       && chmod 600 "$tmp" && mv "$tmp" "$xkeen_config"; then
        return 0
    fi

    # Сбой хирургии или проверки: не оставляем ни битого tmp, ни повреждённого конфига.
    rm -f "$tmp"
    [ -f "$bak" ] && cp "$bak" "$xkeen_config" 2>/dev/null
    echo "  Не удалось безопасно обновить блок балансера в $xkeen_config (восстановлено из бэкапа)"
    return 1
}

# shellcheck disable=SC2154
sb_probe_configured() {
    local conf
    for conf in "$xray_conf_dir"/*.json; do
        [ -f "$conf" ] || continue
        if strip_json_comments "$conf" | jq -e --arg tag "$sb_probe_intag" \
            --arg host "${sb_probe_addr%:*}" --arg port "${sb_probe_addr##*:}" '
            any(.inbounds[]?;
                .tag == $tag and .protocol == "http" and
                (.listen == $host or .listen == "0.0.0.0" or .listen == null) and
                (.port | tostring) == $port)
        ' >/dev/null 2>&1; then
            return 0
        fi
    done
    return 1
}

sb_restore_api_config() {
    if ! cp -p "$1"/*.json "$xray_conf_dir"/ 2>/dev/null; then
        echo "  Не удалось восстановить конфигурацию Xray из резервной копии."
        return 1
    fi
    [ "$3" = true ] || rm -f "$2"
}

# Гарантировать наличие рабочего gRPC api и probe-inbound. Если api и probe уже настроены —
# ничего не делает. Иначе с подтверждением добавляет api-блок, probe-inbound и
# правило маршрутизации api, проверяет конфиг и перезапускает Xray.
#
# Правило api пишется ПЕРВЫМ прямо в routing-файл (по умолчанию 05_routing.json),
# а не отдельным файлом: Xray при мердже confdir заменяет routing.rules последним
# файлом, а не склеивает — правило из отдельного файла потерялось бы. Обновление и
# переустановка XKeen существующий routing-файл не перезаписывают, поэтому правило
# сохраняется; но при РУЧНОЙ перегенерации роутинга (например смене outbound'ов)
# его нужно вернуть повторным `xkeen -sb on`. Это известное ограничение.
sb_ensure_api() {
    # Пока Xray не запущен, api молчит и по нему нельзя судить, настроены ли уже
    # api и probe: предложение «настроить автоматически» здесь означало бы
    # повторное добавление того, что в конфигурации уже есть.
    if ! sb_xray_running; then
        echo
        if pidof mihomo >/dev/null 2>&1; then
            echo -e "  Балансировка по скорости работает только с ядром ${yellow}Xray${reset} — сейчас запущен ${yellow}Mihomo${reset}."
            echo -e "  Переключить ядро: '${green}xkeen -xray${reset}'"
        else
            echo -e "  ${yellow}XKeen${reset} остановлен — состояние api и probe определить нельзя."
            echo -e "  Запустите ${yellow}XKeen${reset} командой '${green}xkeen -start${reset}' и повторите '${green}xkeen -sb on${reset}'"
        fi
        return 1
    fi

    sb_check_xray_version || return 1

    local api_ready generated_config generated_existed probe_json
    api_ready=false
    sb_api_alive && api_ready=true
    if [ "$api_ready" = "true" ] && sb_probe_configured; then
        return 0
    fi

    echo
    echo -e "  Для балансировки нужен gRPC api Xray (${yellow}RoutingService${reset}) и probe-inbound для замера."
    printf "  Настроить автоматически? Будут добавлены api и probe, конфигурация Xray перезапущена. [y/N]: "
    read -r ans
    case "$ans" in
        [Yy]*) ;;
        *) echo "  Отменено. Ручная настройка описана в docs/commands.md."; return 1 ;;
    esac

    local bkp
    mkdir -p "$backups_dir" || return 1
    bkp=$(mktemp -d "$backups_dir/xray-configs-sb-XXXXXX") || return 1
    cp -p "$xray_conf_dir"/*.json "$bkp"/ 2>/dev/null || return 1
    echo -e "  Бэкап конфигурации Xray: ${yellow}$bkp${reset}"

    generated_config="$sb_api_config"
    # shellcheck disable=SC2154
    [ "$api_ready" = "true" ] && generated_config="$sb_probe_config"
    generated_existed=false
    [ -f "$generated_config" ] && generated_existed=true
    if [ "$api_ready" = "true" ]; then
        probe_json='{}'
        [ ! -f "$generated_config" ] || probe_json=$(strip_json_comments "$generated_config")
        if ! printf '%s\n' "$probe_json" | jq --arg tag "$sb_probe_intag" \
            --arg host "${sb_probe_addr%:*}" --argjson port "${sb_probe_addr##*:}" '
            .inbounds = ([.inbounds[]? | select(.tag != $tag)] +
                [{protocol:"http",listen:$host,port:$port,tag:$tag}])
        ' > "$generated_config.tmp" 2>/dev/null; then
            rm -f "$generated_config.tmp"
            return 1
        fi
        chmod 600 "$generated_config.tmp" && mv "$generated_config.tmp" "$generated_config" || return 1
    else
        # api-блок + api-inbound + probe-inbound одним файлом (мержатся по tag)
        cat > "$sb_api_config" <<EOF
{
  "api": {
    "services": [
      "RoutingService",
      "StatsService"
    ],
    "tag": "api"
  },
  "inbounds": [
    {
      "protocol": "tunnel",
      "listen": "127.0.0.1",
      "port": 10085,
      "settings": {
        "address": "127.0.0.1"
      },
      "tag": "api"
    },
    {
      "protocol": "http",
      "listen": "127.0.0.1",
      "port": 10808,
      "tag": "probe"
    }
  ]
}
EOF
    fi

    # api-правило первым в основной routing.rules, если его там ещё нет
    if [ "$api_ready" != "true" ]; then
        local rjson has_rule
        rjson="$sb_routing_file"
        if [ -f "$rjson" ]; then
            has_rule=$(strip_json_comments "$rjson" \
                | jq '[.routing.rules[]? | select(.outboundTag=="api")] | length' 2>/dev/null)
            if [ "${has_rule:-0}" = "0" ]; then
                # без "type": "field" — поле deprecated с xray-core v1.8.10 и правилу не нужно
                if strip_json_comments "$rjson" \
                    | jq '.routing.rules = ([{inboundTag:["api"],outboundTag:"api"}] + (.routing.rules // []))' \
                      > "$rjson.tmp" 2>/dev/null && jq -e . "$rjson.tmp" >/dev/null 2>&1; then
                    mv "$rjson.tmp" "$rjson"
                else
                    rm -f "$rjson.tmp"
                    echo -e "  ${red}✗${reset} Не удалось добавить правило api в $rjson"
                    sb_restore_api_config "$bkp" "$generated_config" "$generated_existed"
                    return 1
                fi
            fi
        fi
    fi

    # проверка конфига до рестарта — битый конфиг не должен убить ядро
    if ! XRAY_LOCATION_ASSET="$geo_dir" xray run -confdir "$xray_conf_dir" -test >/dev/null 2>&1; then
        echo -e "  ${red}✗${reset} Конфигурация не прошла проверку — восстанавливаю из бэкапа"
        sb_restore_api_config "$bkp" "$generated_config" "$generated_existed"
        return 1
    fi

    echo -e "  ${yellow}Перезапуск${reset} XKeen для применения api..."
    local deadline
    if XKEEN_FOREGROUND=1 "$install_dir/xkeen" -restart >/dev/null 2>&1; then
        deadline=$(($(date +%s) + 20))
        while [ "$(date +%s)" -lt "$deadline" ]; do
            sb_api_alive 1 && sb_probe_configured && { echo -e "  api ${green}поднят${reset}"; return 0; }
            sleep 1
        done
        echo -e "  ${red}✗${reset} api не поднялся за 20с — проверьте $xray_error_log"
    else
        echo -e "  ${red}✗${reset} Не удалось перезапустить XKeen с новой конфигурацией."
    fi
    echo "  Восстанавливаю прежнюю конфигурацию Xray и перезапускаю XKeen."
    if sb_restore_api_config "$bkp" "$generated_config" "$generated_existed"; then
        XKEEN_FOREGROUND=1 "$install_dir/xkeen" -restart >/dev/null 2>&1 ||
            echo "  Не удалось запустить XKeen после восстановления конфигурации."
    fi
    return 1
}

# Cron-задача периодического замера. Формат совпадает с install_cron.
sb_install_cron() {
    local path
    path="$cron_dir/$cron_file"
    mkdir -p "$cron_dir"; touch "$path"; chmod +x "$path"
    grep -v "$install_dir/xkeen -sbt" "$path" > "$path.tmp" 2>/dev/null
    mv "$path.tmp" "$path"
    printf '*/%s * * * * %s/xkeen -sbt\n' "$sb_interval" "$install_dir" >> "$path"
    sed -i '/^$/d' "$path"
}

sb_remove_cron() {
    local path
    path="$cron_dir/$cron_file"
    [ -f "$path" ] || return 0
    grep -v "$install_dir/xkeen -sbt" "$path" > "$path.tmp" 2>/dev/null
    mv "$path.tmp" "$path"
    sed -i '/^$/d' "$path"
}

sb_cron_installed() {
    grep -q "$install_dir/xkeen -sbt" "$cron_dir/$cron_file" 2>/dev/null
}

# Предложение прогнать замер вне расписания. Без TTY (cron, ssh без -t, пайп)
# read возвращает EOF — трактуем как отказ, чтобы вызов из скрипта не завис.
sb_ask_measure() {
    local ans
    printf "  Выполнить замер сейчас? [y/N]: "
    read -r ans || { echo; return 0; }
    case "$ans" in
        [Yy]*) ;;
        *) return 0 ;;
    esac
    echo -e "  ${yellow}Замер...${reset}"
    sb_tick
    echo -e "  ${green}✔${reset} Замер завершён. Текущая нода: ${yellow}$(sb_current_target)${reset}"
}

# Балансировка считается включённой, только когда настройка и cron-задача есть
# обе: enabled правят и руками в xkeen.json, и тогда расписание ещё не стоит —
# такой полувключённый случай нужно доводить до конца, а не рапортовать «уже».
sb_enable() {
    speed_balancer_settings
    # причина уже напечатана внутри sb_ensure_api — здесь только итог.
    # Проверка идёт и при повторном включении: молчащий api означает, что
    # правило api потеряно (например при ручной перегенерации роутинга).
    sb_ensure_api || { echo -e "  ${red}✗${reset} Балансировка не включена."; return 1; }

    if [ "$sb_enabled" = "true" ] && sb_cron_installed; then
        echo
        echo -e "  Балансировка по скорости уже ${green}включена${reset} (замер каждые ${yellow}$sb_interval${reset} мин)."
        echo -e "  Текущая нода: ${yellow}$(sb_current_target)${reset}"
        # при автоустановке с использованием нескольких параметров приведет остановке до выбора ответа
        # sb_ask_measure
        return 0
    fi

    sb_write_setting enabled true || return 1
    sb_install_cron
    echo
    echo -e "  ${green}✔${reset} Балансировка по скорости включена (замер каждые ${yellow}$sb_interval${reset} мин)."
    echo -e "  Первый замер выполняется сейчас..."
    speed_balancer_settings
    sb_tick
    echo -e "  Готово. Текущая нода: ${yellow}$(sb_current_target)${reset}"
}

sb_disable() {
    speed_balancer_settings
    if [ "$sb_enabled" != "true" ] && ! sb_cron_installed; then
        echo
        echo -e "  Балансировка по скорости уже ${yellow}выключена${reset}."
        return 0
    fi
    # снять override — без него выбор залипнет на последней ноде (у bo нет TTL)
    if ! xray api bo -s "$sb_api_addr" -b "$sb_balancer" -r >/dev/null 2>&1; then
        echo -e "  ${red}✗${reset} Не удалось снять override — балансировка остаётся включённой."
        return 1
    fi
    sb_pin_clear
    sb_remove_cron
    sb_write_setting enabled false || return 1
    echo
    echo -e "  ${green}✔${reset} Балансировка по скорости выключена, override снят."
}

sb_status() {
    speed_balancer_settings
    echo
    if [ "$sb_enabled" = "true" ]; then
        echo -e "  Балансировка по скорости: ${green}включена${reset}"
    else
        echo -e "  Балансировка по скорости: ${yellow}выключена${reset}"
    fi
    echo -e "  Балансировщик: ${yellow}$sb_balancer${reset}   Интервал: ${yellow}$sb_interval${reset} мин   Гистерезис: ${yellow}$sb_hysteresis${reset}%"
    if sb_api_alive; then
        echo -e "  Текущая нода: ${yellow}$(sb_current_target)${reset}"
        [ -n "$(sb_pin_get)" ] && echo -e "  Режим: ${yellow}закреплена вручную${reset} (вернуть автовыбор: xkeen -sb auto)"
    elif ! sb_xray_running; then
        echo -e "  Xray не запущен — текущая нода неизвестна"
    else
        local sb_ver sb_ver_rc sb_min
        # sb_min_xray_version — SSoT-константа из 01_info_variable.sh, см.
        # пояснение в sb_check_xray_version.
        # shellcheck disable=SC2154
        sb_min="$sb_min_xray_version"
        sb_ver=$(_sb_xray_version)
        sb_ver_rc=1
        [ -n "$sb_ver" ] && { _sb_version_ge "$sb_ver" "$sb_min"; sb_ver_rc=$?; }
        if [ -n "$sb_ver" ] && [ "$sb_ver_rc" = "1" ]; then
            echo -e "  api Xray (${yellow}$sb_api_addr${reset}) недоступен — Xray-core ${yellow}$sb_ver${reset} старее требуемых ${yellow}$sb_min${reset}"
        else
            echo -e "  api Xray (${yellow}$sb_api_addr${reset}) недоступен"
        fi
    fi
    if [ "$sb_log_enabled" != "false" ] && [ -f "$sb_log_file" ]; then
        echo "  Последние события:"
        tail -n 8 "$sb_log_file" | sed 's/^/    /'
    fi
}

# Пронумерованный список нод балансировщика (без служебных outbound'ов).
# Помечает активную ноду (*) и закреплённую вручную. Нумерация — порядок в
# outbounds-файле, её же использует `xkeen -sb N`. Возврат 1, если нод нет.
sb_list() {
    speed_balancer_settings
    if ! sb_node_list; then
        echo
        echo -e "  ${red}✗${reset} Ноды балансировщика ${yellow}$sb_balancer${reset} не найдены (проверьте selector в $sb_routing_file и теги в $sb_outbounds_file)."
        return 1
    fi

    local cur pinned n i mark
    cur=""; sb_api_alive && cur=$(sb_current_target)
    pinned=$(sb_pin_get)

    echo
    echo -e "  Ноды балансировщика ${yellow}$sb_balancer${reset}:"
    i=0
    while IFS= read -r n; do
        [ -n "$n" ] || continue
        i=$((i + 1))
        mark=" "; [ "$n" = "$cur" ] && mark="*"
        if [ -n "$pinned" ] && [ "$n" = "$pinned" ]; then
            printf '   %s %2d. %s  (закреплена вручную)\n' "$mark" "$i" "$n"
        else
            printf '   %s %2d. %s\n' "$mark" "$i" "$n"
        fi
    done <<EOF_LIST
$sb_nodes
EOF_LIST
    echo
    echo -e "  * — активная сейчас. Выбрать: '${green}xkeen -sb N${reset}', вернуть автовыбор: '${green}xkeen -sb auto${reset}'"
    return 0
}

# Применить ноду вручную: override через bo и закрепление выбора. Общая часть
# `xkeen -sb N` и циклического переключения (-sb next/prev). Вывода не делает —
# сообщения печатает вызывающий. Возврат 1, если bo не принял ноду.
sb_apply_node() {
    if ! xray api bo -s "$sb_api_addr" -b "$sb_balancer" "$1" >/dev/null 2>&1; then
        sb_log "ручное переключение на $1 не удалось"
        return 1
    fi
    sb_pin_set "$1"
    sb_log "ручное переключение: -> $1 (закреплена)"
    return 0
}

# Запись в системный журнал роутера (веб-интерфейс Keenetic -> Журнал): при
# запуске с аппаратной кнопки терминала нет, и это единственная обратная связь.
sb_syslog() {
    command -v logger >/dev/null 2>&1 || return 0
    logger -p notice -t XKeen "$1" 2>/dev/null
}

# Блокировка от двойных нажатий кнопки: второй запуск, пока идёт первый,
# иначе прочитал бы ту же текущую ноду и «съел» нажатие. mkdir атомарен;
# в каталоге лежит pid владельца, чтобы переживший kill замок не залип.
sb_lock_acquire() {
    local d pid
    d="$sb_pin_file.lock"
    if mkdir "$d" 2>/dev/null; then echo $$ > "$d/pid"; return 0; fi
    pid=$(cat "$d/pid" 2>/dev/null)
    # pid ещё не записан — владелец только что создал замок, даём ему секунду
    [ -n "$pid" ] || { sleep 1; pid=$(cat "$d/pid" 2>/dev/null); }
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then return 1; fi
    rm -rf "$d"
    mkdir "$d" 2>/dev/null || return 1
    echo $$ > "$d/pid"
    return 0
}

sb_lock_release() {
    rm -rf "$sb_pin_file.lock" 2>/dev/null
}

# Циклическое переключение на следующую (next) или предыдущую (prev) ноду.
# Рассчитано на запуск с аппаратной кнопки роутера (/opt/etc/ndm/button.d):
# без вопросов и меню, при любом отказе — код 1 и запись в журнал. Не пытается
# сам настроить api (sb_ensure_api спрашивает подтверждение и перезапускает
# ядро — для кнопки недопустимо).
# Точка отсчёта — закреплённая нода, а если её нет — текущая эффективная. Если
# её нет в списке (outbounds правили), цикл начинается с первой (next) или
# последней (prev) ноды.
sb_cycle() {
    local rc
    sb_lock_acquire || { sb_syslog "sb $1: переключение уже выполняется, нажатие пропущено"; return 1; }
    sb_cycle_locked "$1"; rc=$?
    sb_lock_release
    return "$rc"
}

sb_cycle_locked() {
    local dir cur idx total n tag
    dir="$1"
    speed_balancer_settings

    if ! sb_xray_running; then
        echo -e "  ${red}✗${reset} Xray не запущен — переключать нечего."
        sb_syslog "sb $dir: Xray не запущен"
        return 1
    fi
    if ! sb_api_alive; then
        echo -e "  ${red}✗${reset} api Xray недоступен. Настройте его: '${green}xkeen -sb on${reset}'"
        sb_syslog "sb $dir: api Xray недоступен"
        return 1
    fi
    if ! sb_node_list; then
        echo -e "  ${red}✗${reset} Ноды балансировщика ${yellow}$sb_balancer${reset} не найдены."
        sb_syslog "sb $dir: ноды балансировщика $sb_balancer не найдены"
        return 1
    fi

    total=$(printf '%s\n' "$sb_nodes" | grep -c .)
    cur=$(sb_pin_get)
    [ -n "$cur" ] || cur=$(sb_current_target)

    # номер текущей ноды: точное совпадение строки целиком. Тег передаётся через
    # окружение, а не awk -v: -v обрабатывает бэкслеши, и тег с ними не совпал бы.
    idx=$(printf '%s\n' "$sb_nodes" | SB_CUR="$cur" awk 'NF && $0 == ENVIRON["SB_CUR"] { print NR; exit }')

    if [ "$dir" = "prev" ]; then
        if [ -n "$idx" ]; then n=$(( (idx + total - 2) % total + 1 )); else n="$total"; fi
    else
        if [ -n "$idx" ]; then n=$(( idx % total + 1 )); else n=1; fi
    fi

    tag=$(printf '%s\n' "$sb_nodes" | sed -n "${n}p")
    if ! sb_apply_node "$tag"; then
        echo -e "  ${red}✗${reset} Не удалось переключить балансировщик на ${yellow}$tag${reset}"
        sb_syslog "sb $dir: не удалось переключиться на $tag"
        return 1
    fi
    echo -e "  ${green}✔${reset} Нода ${yellow}$n${reset}/$total: ${yellow}$tag${reset} (закреплена вручную)"
    sb_syslog "sb $dir: активная нода $n/$total: $tag"
    return 0
}

# Подготовка api к ручному переключению (xkeen -sb N). Для bo нужен только api:
# probe-inbound нужен замеру скорости, а не переключению. sb_ensure_api требует
# и api, и probe, и при отсутствии probe предложил бы перенастроить конфигурацию
# и перезапустить ядро ради функции, которая probe не использует. Поэтому при
# живом api идём напрямую, а sb_ensure_api зовём только когда api недоступен
# (он объяснит, что не так, или предложит настроить api).
sb_ensure_switch_api() {
    if sb_xray_running && sb_api_alive; then
        sb_check_xray_version
        return $?
    fi
    sb_ensure_api
}

# Принудительно переключиться на ноду номер $1 из sb_list. Выбор закрепляется:
# автозамер (cron) его не перебивает, а после перезапуска Xray он возвращается
# на место при ближайшем тике. Снять закрепление — sb_auto.
sb_select() {
    local idx tag total
    idx="$1"
    speed_balancer_settings
    sb_ensure_switch_api || return 1

    if ! sb_node_list; then
        echo -e "  ${red}✗${reset} Ноды балансировщика ${yellow}$sb_balancer${reset} не найдены."
        return 1
    fi
    total=$(printf '%s\n' "$sb_nodes" | grep -c .)
    case "$idx" in
        ''|*[!0-9]*) echo -e "  ${red}✗${reset} Номер ноды должен быть числом. Список: '${green}xkeen -sb list${reset}'"; return 1 ;;
    esac
    if [ "$idx" -lt 1 ] || [ "$idx" -gt "$total" ]; then
        echo -e "  ${red}✗${reset} Нет ноды с номером ${yellow}$idx${reset} (доступно 1-$total). Список: '${green}xkeen -sb list${reset}'"
        return 1
    fi

    tag=$(printf '%s\n' "$sb_nodes" | sed -n "${idx}p")
    if ! sb_apply_node "$tag"; then
        echo -e "  ${red}✗${reset} Не удалось переключить балансировщик на ${yellow}$tag${reset}"
        return 1
    fi
    echo
    echo -e "  ${green}✔${reset} Активная нода: ${yellow}$tag${reset} (закреплена вручную)"
    if [ "$sb_enabled" = "true" ]; then
        echo -e "  Автозамер приостановлен. Вернуть: '${green}xkeen -sb auto${reset}'"
    fi
    return 0
}

# Снять ручное закрепление: сбросить override (балансировщик возвращается к
# своей strategy) и, если автозамер включён, сразу выбрать лучшую ноду.
sb_auto() {
    speed_balancer_settings
    sb_pin_clear
    if sb_api_alive; then
        xray api bo -s "$sb_api_addr" -b "$sb_balancer" -r >/dev/null 2>&1
    fi
    sb_log "ручное закрепление снято"
    echo
    echo -e "  ${green}✔${reset} Ручное закрепление снято."
    if [ "$sb_enabled" = "true" ] && sb_api_alive; then
        echo -e "  ${yellow}Замер...${reset}"
        sb_tick
        echo -e "  Текущая нода: ${yellow}$(sb_current_target)${reset}"
    fi
    return 0
}

# Интерактивный выбор ноды из пронумерованного списка.
sb_pick() {
    local num
    sb_list || return 1
    printf '  Номер ноды (0 — отмена): '
    read -r num || { echo; return 0; }
    case "$num" in
        ''|0) return 0 ;;
    esac
    sb_select "$num"
}

# Интерактивное меню (стиль main: printf + read + case).
sb_menu() {
    local choice
    while true; do
        sb_status
        speed_balancer_settings
        echo
        if [ "$sb_enabled" = "true" ]; then
            printf '     1. Выключить балансировку\n'
        else
            printf '     1. Включить балансировку\n'
        fi
        printf '     2. Прогнать замер сейчас\n'
        printf '     3. Выбрать ноду вручную\n'
        [ -n "$(sb_pin_get)" ] && printf '     4. Вернуть автовыбор (снять закрепление)\n'
        printf '     0. Выход\n\n'
        printf '  Ваш выбор: '
        # read возвращает ненулевой код на EOF (нет TTY: пайп, ssh без -t, cron).
        # Без этой проверки пустой ввод уходил бы в ветку * и while true крутился
        # бы вплотную — CPU-spin. EOF трактуем как выход из меню.
        read -r choice || { echo; return 0; }
        case "$choice" in
            0) return 0 ;;
            1)
                speed_balancer_settings
                if [ "$sb_enabled" = "true" ]; then sb_disable; else sb_enable; fi
                ;;
            2)
                speed_balancer_settings
                if [ "$sb_enabled" = "true" ]; then
                    echo -e "  ${yellow}Замер...${reset}"; sb_tick; echo -e "  ${green}✔${reset} Замер завершён."
                else
                    echo "  Сначала включите балансировку."
                fi
                ;;
            3) sb_pick ;;
            4)
                if [ -n "$(sb_pin_get)" ]; then sb_auto; else echo "  Нода не закреплена."; fi
                ;;
            *) echo "  Неверный ввод." ;;
        esac
    done
}

# Второй параметр `xkeen -sb`, если это распознанная команда; иначе пусто.
# Аналог get_state_arg диспетчера, но для трёх команд балансировки.
sb_command_arg() {
    case "$1" in
        on|off|status|list|auto|next|prev) echo "$1" ;;
        ''|*[!0-9]*) ;;
        *) echo "$1" ;;   # число — номер ноды для ручного переключения
    esac
}

# Точка входа `xkeen -sb [on|off|status|list|auto|next|prev|N]`. Разбор команды здесь, а не в case
# диспетчера: там код завершения операции терялся на завершающем shift, и
# `xkeen -sb on` возвращал 0 даже когда включение было отклонено.
sb_control() {
    case "$1" in
        on)     smart_clear; sb_enable ;;
        off)    smart_clear; sb_disable ;;
        status) sb_status ;;
        list)   sb_list ;;
        auto)   sb_auto ;;
        next|prev) sb_cycle "$1" ;;   # циклическое переключение (кнопка роутера)
        '')     smart_clear; sb_menu ;;
        *)      sb_select "$1" ;;   # xkeen -sb N
    esac
}
