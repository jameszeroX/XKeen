# Запрос на добавление ядер проксирования
choice_add_proxy_cores() {
    # Автоустановка (xkeen -i auto cores=...)
    if [ "$autoinstall_mode" = "true" ]; then
        add_xray=false
        add_mihomo=false
        case "$auto_cores" in
            xray)   add_xray=true ;;
            mihomo) add_mihomo=true ;;
            all)    add_xray=true; add_mihomo=true ;;
            none)   echo "  Выполнен пропуск установки / обновления ядра проксирования" ;;
        esac
        return 0
    fi

    echo
    echo -e "  Выберите ${yellow}ядро проксирования${reset} для загрузки и установки:"
    echo
    echo "     1. Xray"
    echo "     2. Mihomo"
    echo "     3. Xray + Mihomo"
    echo
    echo "     0. Пропустить загрузку ядра проксирования, если оно уже установлено"
    echo

    add_xray=false
    add_mihomo=false

    while true; do
        read -r -p "  Ваш выбор: " proxy_choice

        if echo "$proxy_choice" | grep -qE '^[0-3]$'; then
            break
        else
            echo -e "  ${red}Некорректный ввод.${reset} Выберите один из предложенных вариантов"
        fi
    done

    case "$proxy_choice" in
        1)
            add_xray=true
            ;;
        2)
            add_mihomo=true
            ;;
        3)
            add_xray=true
            add_mihomo=true
            ;;
        0)
            echo "  Выполнен пропуск установки / обновления ядра проксирования"
            add_xray=false
            add_mihomo=false
            ;;
    esac
}

# Смена ядра проксирования на Xray
choice_xray_core() {  
    command -v xray >/dev/null 2>&1 || { echo -e "  ${red}Ошибка${reset}: Ядро Xray не установлено. Выполните установку командой ${yellow}xkeen -ux${reset}"; exit 1; }
    if [ -f "$initd_file" ]; then
        if grep -q 'name_client="xray"' $initd_file; then
            echo -e " Смена ядра ${red}не выполнена${reset}. Устройство уже работает на ядре ${yellow}Xray${reset}"
        elif [ -f "$install_dir/xray" ] && grep -q 'name_client="mihomo"' $initd_file; then
            # pidof-гейт намеренно: вызывать $initd_file stop безусловно здесь бессмысленно —
            # proxy_stop() (04_register_init.sh, ветка `if ! proxy_status`) сам содержит
            # идентичный pidof-гейт вокруг clean_firewall и для уже мёртвого mihomo его всё равно
            # не выполнит. Остаточные xkeen-tagged правила старого ядра безусловно вычищаются и
            # пересобираются _xkeen_apply_table (04_register_init.sh) при следующем `xkeen -start`,
            # который сообщение об успешной смене ядра ниже и так предписывает выполнить.
            if pidof "mihomo" >/dev/null; then
                $initd_file stop
            fi
            sed -i 's/name_client="mihomo"/name_client="xray"/' $initd_file
            add_chmod_init
            echo -e "  ${green}Выполнена${reset} смена ядра на ${yellow}Xray${reset}"
            echo -e "  Настройте конфигурацию по пути '${yellow}$xray_conf_dir/${reset}'"
            echo -e "  И запустите проксирование командой ${yellow}xkeen -start${reset}"
        else
            echo -e " Произошла ${red}ошибка${reset} при смене ядра проксирования"
            return 1
        fi
    else
        echo -e "  ${red}Ошибка${reset}: Не найден файл автозапуска ${yellow}S05xkeen${reset}"
        return 1
    fi
}

# Смена ядра проксирования на Mihomo
choice_mihomo_core() {
    command -v mihomo >/dev/null 2>&1 || { echo -e "  ${red}Ошибка${reset}: Ядро Mihomo не установлено. Выполните установку командой ${yellow}xkeen -um${reset}"; exit 1; }
    command -v yq >/dev/null 2>&1 || { echo -e "  ${red}Ошибка${reset}: не установлен парсер конфигурационных файлов Mihomo - ${yellow}Yq${reset}"; exit 1; }
    if [ -f "$initd_file" ]; then
        if grep -q 'name_client="mihomo"' $initd_file; then
            echo -e " Смена ядра ${red}не выполнена${reset}. Устройство уже работает на ядре ${yellow}Mihomo${reset}"
        elif [ -f "$install_dir/mihomo" ] && [ -f "$install_dir/yq" ] && grep -q 'name_client="xray"' $initd_file; then
            # pidof-гейт намеренно: вызывать $initd_file stop безусловно здесь бессмысленно —
            # proxy_stop() (04_register_init.sh, ветка `if ! proxy_status`) сам содержит
            # идентичный pidof-гейт вокруг clean_firewall и для уже мёртвого xray его всё равно
            # не выполнит. Остаточные xkeen-tagged правила старого ядра безусловно вычищаются и
            # пересобираются _xkeen_apply_table (04_register_init.sh) при следующем `xkeen -start`,
            # который сообщение об успешной смене ядра ниже и так предписывает выполнить.
            if pidof "xray" >/dev/null; then
                $initd_file stop
            fi
            sed -i 's/name_client="xray"/name_client="mihomo"/' $initd_file
            add_chmod_init
            echo -e "  ${green}Выполнена${reset} смена ядра на ${yellow}Mihomo${reset}"
            echo -e "  Настройте конфигурацию по пути '${yellow}$mihomo_conf_dir/${reset}'"
            echo -e "  И запустите проксирование командой ${yellow}xkeen -start${reset}"
        else
            echo -e " Произошла ${red}ошибка${reset} при смене ядра проксирования"
            return 1
        fi
    else
        echo -e "  ${red}Ошибка${reset}: Не найден файл автозапуска ${yellow}S05xkeen${reset}"
        return 1
    fi
}