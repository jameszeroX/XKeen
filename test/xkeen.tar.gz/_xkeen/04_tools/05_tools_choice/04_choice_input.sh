toggle_param() {
    param="$1"
    description="$2"
    restart_needed="$3"
    force_state="$4"

    echo
    if [ ! -f "$initd_file" ]; then
        echo -e "  ${red}Ошибка${reset}: Не найден файл ${yellow}S05xkeen${reset}"
        return 1
    fi

    current_state=$(grep -m 1 -E "^[[:space:]]*$param=" "$initd_file" | cut -d'=' -f2 | tr -d '"[:space:]')

    if [ "$force_state" = "on" ] || [ "$force_state" = "off" ]; then
        if [ "$current_state" = "$force_state" ]; then
            [ "$bypass_autostart_msg" = "yes" ] && return 0
            if [ "$current_state" = "on" ]; then
                echo -e "  Состояние ${description} уже ${green}включено${reset}"
            else
                echo -e "  Состояние ${description} уже ${light_blue}отключено${reset}"
            fi
            [ "$apply" = "restart" ] && echo
            return 0
        fi
        desired_state="$force_state"
    elif [ "$bypass_autostart_msg" = "yes" ]; then
        if [ "$current_state" = "on" ]; then
            desired_state="off"
        else
            desired_state="on"
        fi
    else
        echo -e "  Текущее состояние ${description}:"

        if [ "$current_state" = "on" ]; then
            echo -e "  ${green}Включено${reset}"
            echo
            echo "     1. Отключить"
            echo "     0. Оставить без изменений"
            desired_state="off"
        else
            echo -e "  ${light_blue}Отключено${reset}"
            echo
            echo "     1. Включить"
            echo "     0. Оставить без изменений"
            desired_state="on"
        fi

        echo
        while true; do
            read -r -p "  Ваш выбор: " choice
            case "$choice" in
                0) 
                    echo
                    if [ "$current_state" = "on" ]; then
                        echo -e "  Состояние ${description} ${green}оставлено включённым${reset}"
                    else
                        echo -e "  Состояние ${description} ${light_blue}оставлено отключённым${reset}"
                    fi
                    return 0 
                    ;;
                1) break ;;
                *) echo -e "  ${red}Некорректный ввод${reset}" ;;
            esac
        done
    fi

    if awk -v param="$param" -v value="$desired_state" '
        !found && $0 ~ "^[[:space:]]*" param "=" {
            sub(/"[^"]*"/, "\"" value "\"")
            found=1
        }
        {print}
    ' "$initd_file" > "$initd_file.tmp" && mv "$initd_file.tmp" "$initd_file"; then

        [ "$bypass_autostart_msg" = "yes" ] && return 0

        if [ "$desired_state" = "on" ]; then
            echo -e "  Новое состояние ${description} ${green}включено${reset}"
        else
            echo -e "  Новое состояние ${description} ${light_blue}отключено${reset}"
        fi

        if [ "$restart_needed" = "reboot" ]; then
            echo
            echo -e "  ${yellow}Перезагрузите роутер для применения изменений${reset}"
        elif [ "$restart_needed" = "restart" ] && [ "$apply" != "restart" ]; then
            echo
            echo -e "  ${yellow}Перезапустите XKeen для применения изменений${reset}"
        fi

        add_chmod_init
    else
        echo
        echo -e "  ${red}Ошибка${reset} при изменении параметра $param"
        return 1
    fi
}

choice_menu() {
    title="$1"
    option_yes="$2"
    option_no="$3"

    echo
    [ -n "$title" ] && echo -e "  $title"
    echo
    echo "     1. $option_yes"
    echo "     0. $option_no"
    echo

    while true; do
        # Без TTY (cron, ssh без -t) read получает EOF: код возврата ненулевой,
        # choice остаётся пустым, попадает в ветку * — while true крутится
        # без блокировки на read, CPU-spin. Трактуем EOF как явный ввод 0.
        read -r -p "  Ваш выбор: " choice || choice=0
        case "$choice" in
            1) return 0 ;;
            0) return 1 ;;
            *) echo -e "  ${red}Некорректный ввод${reset}" ;;
        esac
    done
}