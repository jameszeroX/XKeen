# Сформировать download_url и extension для указанной версии Xray.
# $1 = version_selected (например v25.4.30)
# Устанавливает глобальные переменные: download_url, filename, extension
# Возврат: 0 — успех, 1 — неизвестная архитектура
_xray_build_url() {
    _xbu_version="$1"
    _xbu_base="${xray_zip_url}/$_xbu_version"
    case "$architecture" in
        "arm64-v8a") download_url="$_xbu_base/Xray-linux-arm64-v8a.zip" ;;
        "mips32le")  download_url="$_xbu_base/Xray-linux-mips32le.zip" ;;
        "mips32")    download_url="$_xbu_base/Xray-linux-mips32.zip" ;;
        *)           download_url=; return 1 ;;
    esac
    filename=$(basename "$download_url")
    extension="${filename##*.}"
    return 0
}

# Функция для проверки и загрузки выбранной версии Xray
# $1 = version_selected
_xray_perform_install() {
    local version="$1"
    # Кэш списка релизов (см. fetch_release_tags/_release_cache_path в
    # 00_fetch_with_mirrors.sh) - удаляется на каждом пути выхода отсюда,
    # использован он verify_github_sha256() или нет.
    local xpi_cache
    xpi_cache=$(_release_cache_path "$xray_api_url") || xpi_cache=""

    if ! _xray_build_url "$version"; then
        printf "  ${red}Ошибка${reset}: Не удалось получить URL для загрузки Xray\n"
        [ -n "$xpi_cache" ] && rm -f "$xpi_cache"
        return 1
    fi
    mkdir -p "$tmp_ram"

    if ! _network_probe "$download_url" "Xray $version"; then
        [ -n "$xpi_cache" ] && rm -f "$xpi_cache"
        return 1
    fi

    printf "  ${yellow}Выполняется загрузка${reset} Xray %s\n" "$version"
    if ! _network_download "$download_url" "$tmp_ram/xray.$extension" "Xray" "$max_attempts" "$delay" 1048576; then
        [ -n "$xpi_cache" ] && rm -f "$xpi_cache"
        return 1
    fi
    if ! verify_github_sha256 "$tmp_ram/xray.$extension" "$download_url" "${xray_api_url}/tags/$version"; then
        [ -n "$xpi_cache" ] && rm -f "$xpi_cache"
        return 1
    fi
    [ -n "$xpi_cache" ] && rm -f "$xpi_cache"

    printf "  Xray ${green}успешно загружен${reset}\n"
    return 0
}

# Загрузка Xray
download_xray() {
    USE_JSDELIVR=""
    printf "\n  ${green}Запрос информации${reset} о релизах ${yellow}Xray${reset}\n"
    fetch_release_tags "$xray_api_url" "$xray_jsd_url" "10"
    _dlx_cache=$(_release_cache_path "$xray_api_url") || _dlx_cache=""

    # --- Автоустановка (xkeen -ux auto | -ux vX.Y.Z | -i auto [xray=vX.Y.Z]) ---
    if [ "$autoinstall_mode" = "true" ]; then
        if [ -n "$auto_xray_version" ]; then
            # Конкретная версия, заданная пользователем (как при ручном вводе: всегда с префиксом v)
            version_selected="$auto_xray_version"
            printf "  ${green}Автоустановка${reset}: выбрана указанная версия ${yellow}%s${reset}\n" "$version_selected"
        else
            version_selected=$(echo "$RELEASE_TAGS" | head -1)
            if [ -z "$version_selected" ]; then
                printf "  ${red}Ошибка${reset}: Не удалось определить последнюю версию Xray\n"
                [ -n "$_dlx_cache" ] && rm -f "$_dlx_cache"
                return 1
            fi
            [ "$USE_JSDELIVR" = "true" ] && version_selected="v$version_selected"
            printf "  ${green}Автоустановка${reset}: выбрана последняя версия ${yellow}%s${reset}\n" "$version_selected"
        fi

        # _xray_perform_install сам удаляет кэш релизов на всех путях выхода
        _xray_perform_install "$version_selected"
        return $?
    fi

    # --- Интерактивная установка ---
    while true; do
        echo
        echo "$RELEASE_TAGS" | awk '{printf "    %2d. %s\n", NR, $0}'
        echo
        echo "     9. Ручной ввод версии"
        echo
        echo "     0. Пропустить загрузку Xray"

        printf "\n  Введите порядковый номер релиза (0 - пропустить, 9 - ручной ввод): "
        read -r choice

        case "$choice" in
            [0-9]) ;;
            *) 
                printf "  ${red}Некорректный${reset} ввод. Пожалуйста, введите число\n"
                sleep 1
                continue
                ;;
        esac

        if [ "$choice" = "0" ]; then
            bypass_xray="true"
            [ -n "$_dlx_cache" ] && rm -f "$_dlx_cache"
            printf "  Загрузка Xray ${yellow}пропущена${reset}\n"
            return
        fi

        if [ "$choice" = "9" ]; then
            printf "  Введите версию Xray для загрузки (например: v26.7.28): "
            read -r version_selected
            if [ -z "$version_selected" ]; then
                printf "  ${red}Ошибка${reset}: Версия не может быть пустой\n"
                sleep 1
                continue
            fi
            version_selected=$(echo "$version_selected" | sed 's/^v//')
            version_selected="v$version_selected"
        else
            version_selected=$(echo "$RELEASE_TAGS" | awk -v line="$choice" 'NR == line {print $0; exit}')
            if [ -z "$version_selected" ]; then
                printf "  Выбранный номер ${red}вне диапазона.${reset} Пожалуйста, попробуйте снова\n"
                sleep 1
                continue
            fi
            [ "$USE_JSDELIVR" = "true" ] && version_selected="v$version_selected"
        fi

        if _xray_perform_install "$version_selected"; then
            return 0
        fi
    done
}