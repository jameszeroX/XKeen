# Импорт модулей выбора пользователя

# Модули выбора
. "$xtools_dir/02_tools_choice/01_choice_input.sh"
. "$xtools_dir/02_tools_choice/01_choice_mihomo.sh"
. "$xtools_dir/02_tools_choice/01_choice_xray.sh"
. "$xtools_dir/02_tools_choice/02_choice_xkeen.sh"
. "$xtools_dir/02_tools_choice/03_choice_geosite.sh"
. "$xtools_dir/02_tools_choice/03_choice_geoip.sh"

. "$xtools_dir/02_tools_choice/04_choice_cron/00_cron_import.sh"
