# Импорт модулей сравнения версий

# Модули сравнения версий
. "$xinfo_dir/09_info_compare/01_compare_xkeen.sh"
. "$xinfo_dir/09_info_compare/02_compare_xray.sh"