# Импорт информационных модулей

# Модуль информации
. "$xinfo_dir/01_info_variable.sh"
. "$xinfo_dir/02_info_packages.sh"
. "$xinfo_dir/03_info_router.sh"
. "$xinfo_dir/04_info_mihomo.sh"
. "$xinfo_dir/04_info_xray.sh"
. "$xinfo_dir/05_info_geofile.sh"
. "$xinfo_dir/06_info_console.sh"
. "$xinfo_dir/07_info_cron.sh"

. "$xinfo_dir/08_info_version/00_version_import.sh"
