# Импорт модулей удаления

# Модули удаления
. "$xdelete_dir/01_delete_geosite.sh"
. "$xdelete_dir/02_delete_geoip.sh"
. "$xdelete_dir/03_delete_cron.sh"
. "$xdelete_dir/04_delete_configs.sh"
. "$xdelete_dir/05_delete_register.sh"
. "$xdelete_dir/06_delete_tmp.sh"
