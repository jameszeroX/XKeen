# Определение места установки Entware
location_entware_storage() {
    preinstall_warn="false"
    mount_point=$(mount | grep 'on /opt ')
    device=$(echo "$mount_point" | awk '{print $1}')

    case "$device" in
        /dev/sd*)   entware_storage="на внешний USB-накопитель" ;;
        /dev/nvme*) entware_storage="на NVMe-накопитель" ;;
        /dev/ubi*)  entware_storage="во внутреннюю память роутера"; preinstall_warn="true" ;;
        *)          entware_storage="на неидентифицированный носитель информации" ;;
    esac
}

# Информационный варнинг при установке во внутреннюю память
preinstall_warn() {
    if [ -n "$preinstall_warn" ]; then
        echo
        echo -e "  ${red}Внимание${reset}: Инициирована установка XKeen $entware_storage"
        echo "  Убедитесь, что на ней достаточно свободного места. Сбой при такой"
        echo "  установке не является проблемой XKeen и багрепорт не будет рассмотрен"
        echo -e "  XKeen ${green}рекомендуется${reset} устанавливать на внешний ${green}USB-накопитель${reset}"
        echo

        if [ "$autoinstall_mode" = "true" ]; then
            echo "  Установка $entware_storage продолжается"
            return 0
        fi

        echo "  1. Продолжить установку $entware_storage"
        echo "  2. Выйти из установщика"
        echo

        while true; do
            read -r -p "  Выберите действие: " choice || exit 1

            case $choice in
                1)
                    [ -t 1 ] && clear
                    break
                    ;;
                2)
                    echo
                    echo -e "  ${red}Установка отменена${reset}"
                    exit 0
                    ;;
                *)
                    echo -e "  ${red}Некорректный ввод.${reset} Выберите один из предложенных вариантов"
                    ;;
            esac
        done
    fi
}

# Проверка свободного места для установки ядер проксирования
check_free_space() {
    local client_name="$1"
    local required_space=0

    case "$client_name" in
        xray)   required_space=$xray_free_space ;;
        mihomo) required_space=$mihomo_free_space ;;
        *)      return 0 ;;
    esac

    local free_space
    free_space=$(df -m "$target_dir" | awk 'NR==2 {print $4}')

    [ -z "$free_space" ] && return 0

    if [ "$free_space" -lt "$required_space" ]; then
        smart_clear
        echo
        echo -e "  ${red}Внимание: Недостаточно свободного места для установки $client_name${reset}"
        echo -e "  Требуется: ${light_blue}${required_space} MB${reset}, доступно: ${light_blue}${free_space} MB${reset}"
        echo

        if [ "$autoinstall_mode" = "true" ]; then
            echo -e "  Установка ${yellow}$client_name${reset} отменена"
            return 1
        fi

        echo -e "  1) Продолжить установку ${yellow}$client_name${reset} ${red}на свой страх и риск${reset}"
        echo -e "  0) Отменить установку ${yellow}$client_name${reset} (${green}Рекомендуется${reset})"
        echo
        printf "  Выберите вариант: "
        read -r response

        case "$response" in
            1)
                echo "  Предупреждение проигнорировано. Продолжаем..."
                return 0
                ;;
            0|"")
                echo -e "  Установка ${yellow}$client_name${reset} отменена пользователем"
                return 1
                ;;
            *)
                echo -e "  Неверный ввод. В целях безопасности установка ${yellow}$client_name${reset} отменена"
                return 1
                ;;
        esac
    fi
    return 0
}