#!/bin/sh

# Информация о службе: Запуск / Остановка XKeen

# Окружение
PATH="/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin"

# Цвета
green="\033[92m"
red="\033[91m"
yellow="\033[93m"
light_blue="\033[96m"
reset="\033[0m"

# Имена
name_client="xray"
name_app="XKeen"
name_policy="xkeen"
name_policy_full="xkeen_full"
name_profile="xkeen"
name_chain="xkeen"
name_ipset_deny_mac="xkeen_deny_mac"

# Директории
_uname_r="$(uname -r)"
directory_os_modules="/lib/modules/$_uname_r"
directory_user_modules="/opt/lib/modules"
directory_opkg_modules="/opt/lib/system-modules/$_uname_r"
directory_system_modules="/lib/system-modules/$_uname_r"
directory_configs_app="/opt/etc/$name_client"
directory_xray_config="$directory_configs_app/configs"
directory_xray_asset="$directory_configs_app/dat"
log_dir="/opt/var/log"
xkeen_cfg="/opt/etc/xkeen"
ipset_cfg="$xkeen_cfg/ipset"
install_dir="/opt/sbin"

# Файлы
file_netfilter_hook="/opt/etc/ndm/netfilter.d/proxy.sh"
file_schedule_hook="/opt/etc/ndm/schedule.d/00-xkeen-hotspot-sync.sh"
log_access="$log_dir/$name_client/access.log"
log_error="$log_dir/$name_client/error.log"
mihomo_config="$directory_configs_app/config.yaml"
file_port_proxying="$xkeen_cfg/port_proxying.lst"
file_port_exclude="$xkeen_cfg/port_exclude.lst"
file_ip_exclude="$xkeen_cfg/ip_exclude.lst"
xkeen_config="$xkeen_cfg/xkeen.json"
file_pid_fd="/var/run/xkeen_fd.pid"
file_ca="/opt/etc/ssl/certs/ca-certificates.crt"
ru_exclude_ipv4="$ipset_cfg/ru_exclude_ipv4.lst"
ru_exclude_ipv6="$ipset_cfg/ru_exclude_ipv6.lst"
ru_override="$ipset_cfg/ru_exclude_override.lst"

# URL
url_server="127.0.0.1:79"
url_policy="rci/show/ip/policy"
url_keenetic_port="rci/ip/http/ssl"
url_redirect_port="rci/ip/static"
url_hotspot="rci/show/ip/hotspot"

# Настройки правил iptables
table_id="111"
table_mark="0x111"
table_redirect="nat"
table_tproxy="mangle"
comment_tag="xkeen_rule"
comment="-m comment --comment $comment_tag"
custom_mark=""

# DSCP-метки
dscp_enable="on"
dscp_force_proxy_tag="force-proxy"
dscp_force_proxy="61"
dscp_exclude="62"
dscp_proxy="63"

ipv4_proxy="127.0.0.1"
ipv4_exclude="0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 255.255.255.255 78.47.125.180 198.51.100.11 198.51.100.37"
ipv6_proxy="::1"
ipv6_exclude="::/128 ::1/128 64:ff9b::/96 2001::/32 2002::/16 fd00::/8 ff00::/8 fe80::/10 2001:2:7847:1251:feee:ed78:4712:5180 2001:2::c633:640b 2001:2::c633:6425"

# Перехват DNS в прокси
proxy_dns="off"

# Проксирование трафика Entware
proxy_router="off"
# Cовместимость проксирования Entware с nfqws2
nfqws_mark="0x40000000"

# Строгая PBR-проверка mark / routing-mark
pbr_strict="off"

# Настройки запуска
start_verbose="on"
start_attempts=10
start_auto="on"
start_delay=20
init_delay=0

# Контроль файловых дескрипторов
check_fd="off"
arm64_fd=40000
other_fd=10000
delay_fd=60

# Поддержка IPv6
ipv6_support="on"

## Расширенные сообщения запуска
extended_msg="off"

## Резервное копирование XKeen при обновлении
backup="on"

## Клиенты XKeen под своими IP в журнале AdGuard Home
aghfix="off"

if [ "$dscp_enable" = "off" ]; then
    dscp_force_proxy=""
    dscp_exclude=""
    dscp_proxy=""
fi

# Функции журналирования
log_info_router() { logger -p notice -t "$name_app" "$1"; }
log_warning_router() { logger -p warning -t "$name_app" "$1"; }
log_error_router() { logger -p error -t "$name_app" "$1"; }

# Сообщения начинаются с пустой строки и не заканчиваются ею. Если выводилось
# хотя бы одно сообщение, перед дальнейшим выводом (старт прокси-клиента)
# flush_warn_gap добавляет одну разделяющую пустую строку.
_warn_gap=""
log_info_terminal() { _warn_gap=1; echo -e "\n${green}Информация${reset}: $1" >&2; }
log_warning_terminal() { _warn_gap=1; echo -e "\n${yellow}Предупреждение${reset}: $1" >&2; }
flush_warn_gap() { [ -n "$_warn_gap" ] && echo; _warn_gap=""; return 0; }
log_error_terminal() { echo -e "\n${red}Ошибка${reset}: $1" >&2; exit 1; }

# Runtime state must stay in tmpfs, but must never be created in a
# world-writable location.  Recreate a squatted or incorrectly-modeled dir.
_xkeen_secure_rundir() {
    d="/tmp/.xkeen"
    if [ -e "$d" ] && [ ! -d "$d" ]; then
        rm -f "$d" 2>/dev/null
    fi
    if [ -d "$d" ]; then
        set -- $(ls -ld "$d" 2>/dev/null)
        mode="$1"
        owner="$3"
        if [ "$owner" != "root" ] || [ "$mode" != "drwx------" ]; then
            rm -rf "$d" 2>/dev/null
        else
            # Каталог уже существовал и прошёл проверку owner/mode —
            # chmod не нужен, права и так верны.
            printf '%s' "$d"
            return 0
        fi
    fi
    [ -d "$d" ] || mkdir -m 700 "$d" 2>/dev/null || return 1
    chmod 700 "$d" 2>/dev/null || return 1
    printf '%s' "$d"
}
if ! xkeen_rundir=$(_xkeen_secure_rundir); then
    case "$1" in
        stop|status)
            xkeen_rundir="/tmp/.xkeen-unavailable"
            log_warning_router "Недоступен runtime-каталог; продолжаем $1 без runtime-state"
            ;;
        *)
            exit 1
            ;;
    esac
fi

# Дубль функции из 01_info_common.sh: этот файл побайтово копируется в
# init.d/S05xkeen и модули не подключает, поэтому правки нужны в обоих местах.
# Обоснование разбора состоянием — там же.
strip_json_comments() {
    awk '
    {
        line = ""; i = 1; n = length($0); instr = 0; esc = 0
        while (i <= n) {
            c = substr($0, i, 1)
            if (inblk) {
                if (c == "*" && substr($0, i + 1, 1) == "/") { inblk = 0; i += 2 } else i++
                continue
            }
            if (instr) {
                line = line c
                if (esc) esc = 0
                else if (c == "\\") esc = 1
                else if (c == "\"") instr = 0
                i++
                continue
            }
            if (c == "\"") { instr = 1; line = line c; i++; continue }
            if (c == "/" && substr($0, i + 1, 1) == "*") { inblk = 1; i += 2; continue }
            if (c == "/" && substr($0, i + 1, 1) == "/") break
            line = line c; i++
        }
        print line
    }' "$@"
}

# Кэш разобранного xkeen.json на время одного запуска процесса: файл за
# время работы S05xkeen не меняется, поэтому strip_json_comments достаточно
# выполнить один раз, а не при каждом обращении к xkeen.json.
_xkeen_json_cache=""
_xkeen_json_cache_set=0
_xkeen_cached_json() {
    [ "$_xkeen_json_cache_set" = 1 ] && { printf '%s' "$_xkeen_json_cache"; return; }
    _xkeen_json_cache=$(strip_json_comments "$xkeen_config")
    _xkeen_json_cache_set=1
    printf '%s' "$_xkeen_json_cache"
}
# Прогреваем кэш бэровым (не в $()/пайпе) вызовом: все обращения к
# _xkeen_cached_json ниже идут через $(...) или пайп, а это отдельный
# subshell — переменные, выставленные внутри него, наружу не попадают.
# Без этого прогрева каждый вызов ниже видел бы _xkeen_json_cache_set=0
# из родительского процесса и заново форкал strip_json_comments.
[ -f "$xkeen_config" ] && _xkeen_cached_json >/dev/null 2>&1

# Функция извлечения rci-токена из xkeen.json
get_rci_token() {
    rci_token=""
    [ ! -f "$xkeen_config" ] && return 1

    local json_clean
    json_clean=$(_xkeen_cached_json)

    rci_token=$(printf '%s' "$json_clean" | sed -n 's/.*"rci_token": *"\([^"]*\)".*/\1/p' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' 2>/dev/null)

    [ "$rci_token" = "null" ] && rci_token=""
}
get_rci_token

# Fail closed is deliberately opt-in.  Old configurations remain fail-open.
load_killswitch_settings() {
    local _ks_v
    killswitch="off"

    [ -f "$xkeen_config" ] || return 0
    command -v jq >/dev/null 2>&1 || return 0

    _ks_v=$(_xkeen_cached_json | jq -r '.xkeen.killswitch // "off"' 2>/dev/null)

    [ "$_ks_v" = "on" ] && killswitch="on"
}
load_killswitch_settings

# GOMEMLIMIT для mihomo: доля RAM или абсолютный лимит из xkeen.json.
# Дефолт — 50% RAM (сохраняет прежнее поведение). Внешний
# GOMEMLIMIT в окружении всегда побеждает.
load_gomemlimit_settings() {
    gomemlimit_percent=50
    gomemlimit_mb=""

    [ ! -f "$xkeen_config" ] && return 0
    command -v jq >/dev/null 2>&1 || return 0

    _gml_json=$(_xkeen_cached_json)
    _gml_v=$(printf '%s' "$_gml_json" | jq -r '.xkeen.mihomo.gomemlimit_percent // empty' 2>/dev/null)
    if [ -n "$_gml_v" ] && [ "$_gml_v" -ge 1 ] 2>/dev/null && [ "$_gml_v" -le 90 ] 2>/dev/null; then
        gomemlimit_percent="$_gml_v"
    fi
    _gml_v=$(printf '%s' "$_gml_json" | jq -r '.xkeen.mihomo.gomemlimit_mb // empty' 2>/dev/null)
    if [ -n "$_gml_v" ] && [ "$_gml_v" -ge 64 ] 2>/dev/null; then
        gomemlimit_mb="$_gml_v"
    fi
    unset _gml_json _gml_v
}

# Выставляет GOMEMLIMIT и gomemlimit_value (для inject в netfilter-хук).
apply_gomemlimit() {
    [ -n "$GOMEMLIMIT" ] && { gomemlimit_value="$GOMEMLIMIT"; return 0; }

    load_gomemlimit_settings
    gomemlimit_value=""

    if [ -n "$gomemlimit_mb" ]; then
        gomemlimit_value="${gomemlimit_mb}MiB"
        export GOMEMLIMIT="$gomemlimit_value"
        return 0
    fi

    _mem_kb=$(awk '/^MemTotal:/{print $2}' /proc/meminfo 2>/dev/null)
    if [ -n "$_mem_kb" ] && [ "$_mem_kb" -gt 0 ] 2>/dev/null; then
        _goml=$(( _mem_kb * gomemlimit_percent / 100 / 1024 ))
        [ "$_goml" -lt 64 ] && _goml=64
        gomemlimit_value="${_goml}MiB"
        export GOMEMLIMIT="$gomemlimit_value"
    fi
    unset _mem_kb _goml
}

wait_for_webui() {
    max_wait=20
    i=0

    while [ "$i" -lt "$max_wait" ]; do
        pidof nginx >/dev/null 2>&1 && return 0
        sleep 2
        i=$((i + 1))
    done

    return 1
}

wait_for_rci_token() {
    [ -n "$rci_token" ] || return 1

    wait_for_webui || {
        log_error_router "Веб-интерфейс недоступен"
        return 1
    }

    # nginx-процесс может подняться раньше, чем сам RCI-демон начнёт
    # отвечать на запросы (асинхронная инициализация служб NDM), поэтому
    # даём RCI до ~20 сек на "прогрев" и ретраим именно код 000 / прочие
    # временные коды. 401/403 — это уже реальная проблема токена, здесь
    # ретраить бессмысленно, выходим сразу.
    _rci_wait_attempts=20
    _rci_wait_i=0
    while [ "$_rci_wait_i" -lt "$_rci_wait_attempts" ]; do
        http_code=$(curl --noproxy '*' -ksS -o /dev/null -w "%{http_code}" --connect-timeout 2 -m 5 -H "X-Ndma-Tkn: $rci_token" "${url_server}/${url_policy}")

        case "$http_code" in
            200) return 0 ;;
            401|403)
                log_error_router "Отсутствует или недействителен токен доступа к RCI роутера"
                log_error_terminal "Отсутствует или недействителен токен доступа к RCI роутера"
                ;;
        esac

        _rci_wait_i=$((_rci_wait_i + 1))
        sleep 1

    done

    log_error_router "RCI не отвечает (http_code=$http_code)"
    log_error_terminal "RCI не отвечает (http_code=$http_code)"
}
# stop/status не используют curl_api (proxy_stop/proxy_status/clean_firewall
# работают только с pidof/iptables), поэтому недействительный rci_token не
# должен блокировать аварийную остановку и проверку статуса (killswitch-
# инвариант из wiki/Конфигурационный-файл.md). restart/start/cold_start
# зависят от RCI через proxy_start -> api_cache_init -> curl_api, там
# проверка остаётся обязательной.
case "$1" in
    stop|status) : ;;
    start)
        if [ -n "$2" ]; then
            wait_for_rci_token
        fi
        ;;
    *) wait_for_rci_token ;;
esac

# Параметры curl
# Дубль функции: см. также строку ~2221 этого файла (heredoc proxy.sh) и
# 01_info_common.sh:curl_api — правь все три места синхронно.
curl_api() {
    if [ -n "$rci_token" ]; then
        curl --noproxy '*' --connect-timeout 2 -m 5 -kfsS -H "X-Ndma-Tkn: $rci_token" "$@"
    else
        curl --noproxy '*' --connect-timeout 2 -m 5 -kfsS "$@"
    fi
}

detect_architecture() {
    arm_cpu="false"
    command -v opkg >/dev/null 2>&1 || return
    case "$(opkg print-architecture | awk '!/all/ {print $2; exit}')" in
        aarch64*) arm_cpu="true" ;;
    esac
}

print_policy_info() {
    found="$1"
    has_custom="$2"
    ignored_custom="$3"

    ignore_line=""
    if [ "$ignored_custom" = "yes" ]; then
        ignore_line="
  Пользовательские политики из '${yellow}xkeen.json${reset}' будут проигнорированы"
    fi

    if [ "$extended_msg" != "on" ]; then
        if [ "$found" = "no" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Прокси будет запущен для всех клиентов устройства"
        fi
        return
    fi

    if [ "$found" = "yes" ]; then

        if [ "$has_custom" = "yes" ]; then
            custom_names=$(echo "$user_policies" | cut -d'|' -f1 | tr '\n' ',' | sed 's/,$//; s/,/, /g')
            policies="${name_policy}, ${custom_names}"

            detail_list=""
            if [ -n "$port_donor" ]; then
                detail_list="  - ${yellow}$name_policy${reset} на портах ${green}${port_donor}${reset}"
            elif [ -n "$port_exclude" ]; then
                detail_list="  - ${yellow}$name_policy${reset} на всех портах кроме ${green}${port_exclude}${reset}"
            else
                detail_list="  - ${yellow}$name_policy${reset} на всех портах"
            fi

            custom_details=$(echo "$user_policies" | while IFS='|' read -r p_name p_mark p_mode p_ports; do
                if [ "$p_mode" = "include" ]; then
                    echo "  - ${yellow}$p_name${reset} на портах ${green}${p_ports}${reset}"
                elif [ "$p_mode" = "exclude" ]; then
                    echo "  - ${yellow}$p_name${reset} на всех портах кроме ${green}${p_ports}${reset}"
                else
                    echo "  - ${yellow}$p_name${reset} на всех портах"
                fi
            done)

            log_info_terminal "
  Найдены политики '${yellow}${policies}${reset}'
  Прокси будет запущен для клиентов политик:
${detail_list}
${custom_details}"
        else
            if [ -z "$port_donor" ] && [ -z "$port_exclude" ]; then
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Не определены целевые порты для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}' на всех портах"
            elif [ -n "$port_donor" ]; then
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Определены целевые порты для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}'
  на портах ${green}${port_donor}${reset}"
            else
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Определены порты исключения для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}'
  на всех портах кроме ${green}${port_exclude}${reset}"
            fi
        fi
    else
        if [ -n "$port_donor" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Определены целевые порты для XKeen
  Прокси будет запущен для всех клиентов
  на портах ${green}${port_donor}${reset}"
        elif [ -n "$port_exclude" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Определены порты исключения для XKeen
  Прокси будет запущен для всех клиентов
  на всех портах кроме ${green}${port_exclude}${reset}"
        else
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Не определены целевые порты для XKeen
  Прокси будет запущен для всех клиентов на всех портах"
        fi
    fi
}

utils="jq curl grep awk sed ipset ip logger killall"
[ "$name_client" = "mihomo" ] && utils="$utils yq"
for cmd in $utils; do
    command -v "$cmd" >/dev/null 2>&1 || log_error_terminal "Не найдена необходимая утилита: ${yellow}$cmd${reset}"
done

if readlink "$(which ip)" | grep -q 'busybox'; then
    log_error_terminal "Обнаружена урезанная версия ip (BusyBox). Необходим пакет: ${yellow}ip-full${reset}"
fi

log_clean() { [ "$name_client" = "xray" ] && : > "$log_access" && : > "$log_error"; }

api_cache_init() {
    api_policy_json=$(curl_api "${url_server}/${url_policy}" 2>/dev/null)
    api_port_json=$(curl_api "${url_server}/${url_keenetic_port}" 2>/dev/null)
    api_static_json=$(curl_api "${url_server}/${url_redirect_port}" 2>/dev/null)
}

json_get_ports() { [ -n "$api_port_json" ] && printf '%s' "$api_port_json" | jq -r '(.port // 443)' 2>/dev/null; }

# Получение ssl порта Keenetic
get_keenetic_port() {
    ports=""
    ports=$(json_get_ports)
    case " $ports " in
        *" 443 "*) return 1 ;;
    esac
    [ -n "$ports" ] || return 1
    echo "$ports"
    return 0
}

check_ipv6_active() {
    [ -r /proc/net/if_inet6 ] || return 1
    awk '
        $4 == "20" {
            name = $6
            if (name ~ /^ezcfg0$/ || name ~ /^t2s/) next
            found = 1
        }
        END { exit !found }
    ' /proc/net/if_inet6
}

apply_ipv6_state() {
    ipv6_disabled=
    ipv6_disabled=$(sysctl -n net.ipv6.conf.default.disable_ipv6 2>/dev/null || echo "0")

    [ "$ipv6_disabled" -eq 1 ] && return 0

    [ "$ipv6_support" != "off" ] && return 0

    check_ipv6_active || return 0

    sysctl -w net.ipv6.conf.default.disable_ipv6=1 >/dev/null 2>&1

    for dir in /proc/sys/net/ipv6/conf/*; do
        [ -d "$dir" ] || continue
        iface="${dir##*/}"

        case "$iface" in
            all|ezcfg0|t2s*)
                continue
                ;;
            *)
                [ -f "$dir/disable_ipv6" ] && echo "1" > "$dir/disable_ipv6" 2>/dev/null
                ;;
        esac
    done

    sleep 2

    if [ "$(sysctl -n net.ipv6.conf.default.disable_ipv6 2>/dev/null)" -eq 1 ]; then
        log_info_router "Отключение IPv6 выполнено"
        return 0
    fi
}

get_ipver_support() {
    ip4_supported=$(ip -4 addr show 2>/dev/null | grep -q "inet " && echo true || echo false)
    ip6_supported=$(check_ipv6_active && echo true || echo false)

    iptables_supported=$([ "$ip4_supported" = "true" ] && command -v iptables >/dev/null 2>&1 && echo true || echo false)
    ip6tables_supported=$([ "$ip6_supported" = "true" ] && command -v ip6tables >/dev/null 2>&1 && echo true || echo false)
}

append_multiline() {
    current_value="$1"
    new_value="$2"

    if [ -n "$current_value" ]; then
        printf '%s\n%s' "$current_value" "$new_value"
    else
        printf '%s' "$new_value"
    fi
}

format_routing_mark_items() {
    item_label="$1"
    mark_label="$2"
    raw_items="$3"

    printf '%b\n' "$raw_items" | awk -F '\t' -v item_label="$item_label" -v mark_label="$mark_label" '
        NF == 0 || seen[$0]++ { next }
        {
            status = ($2 == "" ? mark_label " отсутствует" : "найден " mark_label " " $2)
            print "  - " item_label " " $1 ": " status
        }
    '
}

# Функция валидации xkeen.json
validate_xkeen_json() {
    [ ! -f "$xkeen_config" ] && return 0

    if ! _xkeen_cached_json | jq -e . >/dev/null 2>&1; then
        log_error_terminal "
  Валидация JSON: файл '${yellow}xkeen.json${reset}' содержит синтаксические ошибки
  Запуск прокси невозможен
"
    fi

    jq_check=
    jq_check='
      if has("xkeen") and .xkeen != null then
        if .xkeen.policy then
          .xkeen.policy | type == "array" and ([.[] | select(has("name") | not)] | length == 0)
        else
          true
        end
      else
        true
      end
    '

    if ! _xkeen_cached_json | jq -e "$jq_check" >/dev/null 2>&1; then
        log_error_terminal "
  Файл '${yellow}xkeen.json${reset}' имеет неверную структуру
  Запуск прокси невозможен
"
    fi

    return 0
}

# Функция поиска резервных копий конфигурационных файлов Xray
check_xray_backups() {
    [ "$name_client" != "xray" ] && return 0

    # Ищем json-файлы с типичными признаками копий
    bad_files=$(find "$directory_xray_config" -maxdepth 1 -type f \( -iname "*bak*.json" -o -iname "*old*.json" -o -iname "*copy*.json" -o -iname "*копия*.json" -o -iname "*orig*.json" -o -iname "*save*.json" -o -iname "*temp*.json" -o -iname "*tmp*.json" -o -name "*(*).json" \))

    if [ -n "$bad_files" ]; then
        bad_list=$(printf '%s\n' "$bad_files" | awk -F/ '{print "  - " $NF}')
        
        log_error_terminal "
  В директории конфигурации Xray найдены резервные копии:
${light_blue}${bad_list}${reset}

  Измените расширение резервных копий, например, на ${yellow}.bak${reset}
  Либо переместите их в поддиректорию
  Запуск ${yellow}$name_client${reset} ${red}отменен${reset}
"
    fi
    return 0
}

build_allowed_policy_marks() {
    include_service_mark="$1"
    allowed_marks=""
    policy_hex_marks="$policy_mark $policy_mark_full"

    if [ "$include_service_mark" = "yes" ]; then
        allowed_marks="255"
    fi

    if [ -n "$user_policies" ]; then
        user_policy_hex_marks=$(printf '%s\n' "$user_policies" | awk -F'|' '$2 != "" {print "0x"$2}')
        policy_hex_marks="$policy_hex_marks $user_policy_hex_marks"
    fi

    for policy_hex_mark in $policy_hex_marks; do
        policy_mark_dec=$(hex_mark_to_decimal "$policy_hex_mark" 2>/dev/null)
        [ -n "$policy_mark_dec" ] && allowed_marks="$allowed_marks $policy_mark_dec"
    done

    if [ -n "$allowed_marks" ]; then
        allowed_marks=$(printf '%s\n' $allowed_marks | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/ $//')
    fi

    printf '%s\n' "$allowed_marks"
}

format_allowed_marks_display() {
    printf '%s\n' "$1" | tr ' ' '\n' | awk '
        NF && !seen[$0]++ {
            if (out != "") {
                out = out ", " $0
            } else {
                out = $0
            }
        }
        END {
            print out
        }
    '
}

format_single_line_error() {
    printf '%s' "$1" | tr '\n' ' ' | sed 's/[[:space:]]\{1,\}/ /g; s/^ //; s/ $//'
}

convert_mihomo_yaml_to_json() {
    config_file="$1"
    tmp_base="${TMPDIR:-/tmp}/xkeen_mihomo_json.$$"
    out_file="${tmp_base}.out"
    err_file="${tmp_base}.err"

    rm -f "$out_file" "$err_file"

    if yq -o=json '.' "$config_file" >"$out_file" 2>"$err_file" \
        && jq -e . <"$out_file" >/dev/null 2>&1; then
        cat "$out_file"
        rm -f "$out_file" "$err_file"
        return 0
    fi

    last_stderr=$(format_single_line_error "$(cat "$err_file" 2>/dev/null)")
    rm -f "$out_file" "$err_file"

    if [ -n "$last_stderr" ]; then
        printf '%s' "не удалось преобразовать YAML в JSON через yq: $last_stderr"
    else
        printf '%s' "yq не вернул валидный JSON"
    fi

    return 1
}

validate_client_routing_mark() {
    validation_mode="$1"
    include_service_mark="$2"

    bad_items=""
    has_items="false"
    allowed_marks=$(build_allowed_policy_marks "$include_service_mark")
    validation_errors=""
    mark_msg=""
    item_label=""
    item_label_plural=""
    config_hint=""
    needs_attention="false"
    allowed_marks_display=""
    global_mark_valid="false"
    provider_mark_valid="false"

    allowed_marks_display=$(format_allowed_marks_display "$allowed_marks")
    if [ "$name_client" = "xray" ]; then
        mark_msg="mark"
        item_label="outbound"
        item_label_plural="outbounds"
        config_hint="  Для Xray задайте ${green}mark${reset} в ${yellow}streamSettings.sockopt${reset} у всех реальных outbounds, кроме служебных (${yellow}blackhole${reset}, ${yellow}loopback${reset})"

        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue

            outbounds_state=$(strip_json_comments "$file" | jq -r '
                if .outbounds == null then
                    "missing"
                elif (.outbounds | type) == "array" then
                    "array"
                else
                    "invalid"
                end
            ' 2>&1)
            outbounds_state_rc=$?

            if [ "$outbounds_state_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): $outbounds_state")
                continue
            fi

            case "$outbounds_state" in
                missing)
                    continue
                    ;;
                invalid)
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): поле .outbounds должно быть массивом")
                    continue
                    ;;
                array)
                    has_items="true"
                    ;;
            esac

            current_bad=$(strip_json_comments "$file" | jq -r --arg allowed "$allowed_marks" '
                def flatten_nested_arrays:
                    if type == "array" then
                        .[] | flatten_nested_arrays
                    else
                        .
                    end;

                (.outbounds // [])
                | .[]?
                | flatten_nested_arrays
                | select(type == "object")
                | select((.protocol // "") != "blackhole" and (.protocol // "") != "loopback")
                | (.streamSettings? | if type == "object" then . else {} end) as $stream
                | ($stream.sockopt? | if type == "object" then . else {} end) as $sockopt
                | ($sockopt.mark? // null) as $mark
                | select(($allowed | split(" ") | index((if $mark == null or $mark == "" then "" else ($mark | tostring) end))) | not)
                | [(.tag // .protocol // "<unnamed>"), (if $mark == null or $mark == "" then "" else ($mark | tostring) end)] | @tsv
            ' 2>&1)
            current_bad_rc=$?

            if [ "$current_bad_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): $current_bad")
                continue
            fi

            if [ -n "$current_bad" ]; then
                bad_items=$(append_multiline "$bad_items" "$current_bad")
            fi
        done

    elif [ "$name_client" = "mihomo" ]; then
        mark_msg="routing-mark"
        item_label="proxy"
        item_label_plural="proxies"
        config_hint="  Для Mihomo задайте ${green}routing-mark${reset} глобально либо у нужных ${yellow}proxies${reset}/${yellow}proxy-providers${reset}"

        if [ -f "$mihomo_config" ]; then
            mihomo_json=$(convert_mihomo_yaml_to_json "$mihomo_config")
            mihomo_json_rc=$?

            if [ "$mihomo_json_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $mihomo_json")
            else
                if ! printf '%s' "$mihomo_json" | jq -e . >/dev/null 2>&1; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): yq не вернул валидный JSON")
                else
                root_kind=$(printf '%s' "$mihomo_json" | jq -r 'type' 2>&1)
                root_kind_rc=$?

                if [ "$root_kind_rc" -ne 0 ]; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $root_kind")
                elif [ "$root_kind" != "object" ]; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): корень config.yaml должен быть map/object")
                else
                    global_mark_valid=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" '
                        .["routing-mark"] as $mark
                        | if $mark != null and (($allowed | split(" ") | index($mark | tostring)) != null) then
                            "true"
                        else
                            "false"
                        end
                    ' 2>&1)
                    global_mark_valid_rc=$?
                    [ "$global_mark_valid_rc" -ne 0 ] && validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $global_mark_valid")

                    provider_mark_valid=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" '
                        def values_or_items:
                            if type == "object" or type == "array" then
                                .[]?
                            else
                                empty
                            end;

                        [
                            (.["proxy-providers"] // empty)
                            | values_or_items
                            | select(type == "object")
                            | (.override? | if type == "object" then . else {} end)
                            | .["routing-mark"]? as $mark
                            | select($mark != null)
                            | (($allowed | split(" ") | index($mark | tostring)) != null)
                        ] | any
                    ' 2>&1)
                    provider_mark_valid_rc=$?
                    [ "$provider_mark_valid_rc" -ne 0 ] && validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $provider_mark_valid")

                    proxies_state=$(printf '%s' "$mihomo_json" | jq -r '
                        if .proxies == null then
                            "missing"
                        elif (.proxies | type) == "array" then
                            "array"
                        else
                            "invalid"
                        end
                    ' 2>&1)
                    proxies_state_rc=$?

                    if [ "$proxies_state_rc" -ne 0 ]; then
                        validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $proxies_state")
                    else
                        case "$proxies_state" in
                            missing)
                                if [ "$global_mark_valid" != "true" ] && [ "$provider_mark_valid" != "true" ]; then
                                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): не найдены proxies и нет глобального/provider routing-mark для проверки")
                                fi
                                ;;
                            invalid)
                                validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): поле .proxies должно быть массивом")
                                ;;
                            array)
                                has_items="true"
                                current_bad=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" --arg global_valid "$global_mark_valid" '
                                    def flatten_nested_arrays:
                                        if type == "array" then
                                            .[] | flatten_nested_arrays
                                        else
                                            .
                                        end;

                                    (.proxies // [])
                                    | .[]?
                                    | flatten_nested_arrays
                                    | select(type == "object")
                                    | (.["routing-mark"]? // null) as $mark
                                    | select(
                                        if $mark == null or $mark == "" then
                                            $global_valid != "true"
                                        else
                                            (($allowed | split(" ") | index($mark | tostring)) == null)
                                        end
                                    )
                                    | [(.name // .type // "<unnamed>"), (if $mark == null or $mark == "" then "" else ($mark | tostring) end)] | @tsv
                                ' 2>&1)
                                current_bad_rc=$?

                                if [ "$current_bad_rc" -ne 0 ]; then
                                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $current_bad")
                                elif [ -n "$current_bad" ]; then
                                    bad_items=$(append_multiline "$bad_items" "$current_bad")
                                fi
                                ;;
                        esac
                    fi
                fi
                fi
            fi
        else
            validation_errors=$(append_multiline "$validation_errors" "config.yaml: файл не найден")
        fi
    fi

    if [ -n "$validation_errors" ] || [ -n "$bad_items" ] || { [ "$name_client" = "xray" ] && [ "$has_items" != "true" ]; }; then
        needs_attention="true"
    fi

    [ "$needs_attention" != "true" ] && return 0

    error_details=""

    if [ "$name_client" = "xray" ] && [ "$has_items" != "true" ] && [ -z "$validation_errors" ]; then
        validation_errors=$(append_multiline "$validation_errors" "Не найдены реальные outbounds для проверки")
    fi

    if [ -n "$validation_errors" ]; then
        validation_list=$(printf "%b\n" "$validation_errors" | awk '!seen[$0]++ {print "  - " $0}')
        error_details="${error_details}

  Не удалось полностью проверить конфигурацию:
${light_blue}${validation_list}${reset}"
    fi

    if [ -n "$bad_items" ]; then
        bad_list=$(format_routing_mark_items "$item_label" "$mark_msg" "$bad_items")
        error_details="${error_details}

  Проблемные ${item_label_plural}:
${light_blue}${bad_list}${reset}"
    fi

    if [ -n "$bad_items" ] || { [ "$name_client" = "xray" ] && [ "$has_items" != "true" ] && [ -z "$validation_errors" ]; }; then
        validation_summary="не найден"
        pbr_validation_summary="не найден корректный"
    else
        validation_summary="не удалось проверить"
        pbr_validation_summary="не удалось проверить корректный"
    fi

    if [ "$validation_mode" = "pbr" ]; then
        log_error_terminal "
  Включена strict PBR-проверка, но у исходящих подключений ${yellow}${name_client}${reset} ${pbr_validation_summary} ${yellow}mark/routing-mark${reset} политики Keenetic$error_details

  Разрешённые policy marks Keenetic: ${yellow}${allowed_marks_display}${reset}
$config_hint
  Служебная метка ${yellow}255${reset} не является policy mark и не подходит для PBR
  Получите код политики командой ${yellow}xkeen -pbr codes${reset} и укажите его в конфигурации
  Управление режимом: ${yellow}xkeen -pbr on${reset} | ${yellow}xkeen -pbr off${reset} | ${yellow}xkeen -pbr status${reset}
"
    else
        log_warning_terminal "
  Для проксирования трафика Entware требуется его маркировка
  В конфигурации ${yellow}${name_client}${reset} ${validation_summary} ${yellow}mark/routing-mark${reset} для bypass$error_details

  Для обычного Entware proxy можно использовать служебную метку ${yellow}255${reset}
  Разрешённые bypass marks: ${yellow}${allowed_marks_display}${reset}
$config_hint
  Если нужно направить сам ${yellow}${name_client}${reset} через конкретную политику Keenetic, используйте код из ${yellow}xkeen -pbr codes${reset}

  Отсутствие маркировки в этом режиме приведет к петле трафика и зависанию роутера
  Проксирование трафика Entware ${red}отключено${reset} для безопасности"
        proxy_router="off"
    fi

    return 0
}

validate_entware_proxy_mark() {
    [ "$proxy_router" != "on" ] && return 0
    validate_client_routing_mark "entware" "yes"
}

validate_pbr_routing_mark() {
    [ "$pbr_strict" != "on" ] && return 0

    allowed_policy_marks=$(build_allowed_policy_marks "no")
    if [ -z "$allowed_policy_marks" ]; then
        log_error_terminal "
  Не удалось получить коды политик Keenetic для PBR
  Создайте или проверьте политику в веб-интерфейсе Keenetic и повторите ${yellow}xkeen -pbr codes${reset}
  Служебная метка ${yellow}255${reset} не является policy mark и не подходит для PBR
"
    fi

    validate_client_routing_mark "pbr" "no"
}

load_user_ipset_family() {
    set_name="$1"
    family="$2"
    addr_regex="$3"
    source_file="$4"
    tmp="${set_name}_tmp"

    # Заполняем tmp; основной набор подменяется только после успешного pipeline
    ipset create "$set_name" hash:net family "$family" -exist
    ipset create "$tmp" hash:net family "$family" -exist
    ipset flush "$tmp"

    if sed -e 's/\r$//' -e 's/#.*//' -e '/^[[:space:]]*$/d' "$source_file" |
       grep -Eo "$addr_regex" |
       awk -v s="$tmp" '{print "add "s" "$1}' | ipset restore -exist; then
        ipset swap "$set_name" "$tmp"
    fi
    ipset destroy "$tmp"
}

# Функция загрузки пользовательских исключений в ipset
load_user_ipset() {
    [ ! -f "$file_ip_exclude" ] && return
    [ "$iptables_supported" = "true" ] && load_user_ipset_family user_exclude inet '([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?' "$file_ip_exclude"
    [ "$ip6tables_supported" = "true" ] && load_user_ipset_family user_exclude6 inet6 '([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(/[0-9]{1,3})?' "$file_ip_exclude"

    # Обработка списка исключений из geo_exclude
    if [ -f "$ru_override" ]; then
        [ "$iptables_supported" = "true" ] && load_user_ipset_family geo_override inet '([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?' "$ru_override"
        [ "$ip6tables_supported" = "true" ] && load_user_ipset_family geo_override6 inet6 '([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(/[0-9]{1,3})?' "$ru_override"
    else
        # Если файла исключений нет, создаем пустые сеты, чтобы iptables не ругался на их отсутствие
        [ "$iptables_supported" = "true" ] && ipset create geo_override hash:net family inet -exist
        [ "$ip6tables_supported" = "true" ] && ipset create geo_override6 hash:net family inet6 -exist
    fi
}

# Функция чтения пользовательских портов из файлов
read_ports_from_file() {
    file_ports="$1"
    [ -f "$file_ports" ] || return

    sed -e 's/\r$//' -e 's/#.*//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e '/^$/d' "$file_ports"
}

# Функция обработки, валидации и нормализации списка портов
validate_and_clean_ports() {
    input_ports="$1"
    mandatory_ports="$2"
    [ -z "$input_ports" ] && [ -z "$mandatory_ports" ] && return 1

    echo "${mandatory_ports}${mandatory_ports:+,}${input_ports}" | tr ',' '\n' | awk '
        function is_valid(p) {
            return p ~ /^[0-9]+$/ && p > 0 && p <= 65535
        }
        {
            gsub(/[[:space:]]/, "", $0)
            gsub(/-/, ":", $0)
            if ($0 == "") next

            n = split($0, a, ":")

            if (n == 1) {
                if (is_valid(a[1])) {
                    print a[1]
                }
            }

            else if (n == 2) {
                if (is_valid(a[1]) && is_valid(a[2])) {
                    start = a[1]
                    end   = a[2]

                    if (start > end) {
                        tmp = start
                        start = end
                        end = tmp
                    }

                    if (start <= end) {
                        print start ":" end
                    }
                }
            }
        }
    ' | sort -n -u | tr '\n' ',' | sed 's/,$//'
}

# Функция обработки пользовательских портов
process_user_ports() {
    raw_donor=$(read_ports_from_file "$file_port_proxying")
    [ -n "$raw_donor" ] && port_donor=$(validate_and_clean_ports "$raw_donor" "80,443") || port_donor=""
    port_exclude=$(validate_and_clean_ports "$(read_ports_from_file "$file_port_exclude")")

    if [ -n "$port_donor" ] && [ -n "$port_exclude" ]; then
        log_warning_terminal "
  Заданы и порты проксирования, и порты исключения
  Прокси будет запущен на портах проксирования, порты исключения игнорируются"
        port_exclude=""
    fi
}

# Функция нормализации сторонних политик
process_mark_var() {
    local var_name="$1"
    local current_marks
    local clean_mark=""
    local val
    local mask
    local mark
    local IFS=', '

    eval "current_marks=\"\$$var_name\""
    [ -n "$current_marks" ] || return

    for mark in $current_marks; do
        [ -n "$mark" ] || continue

        case "$mark" in
            */*) val=${mark%%/*}; mask=${mark#*/} ;;
            *)   val="$mark";     mask="" ;;
        esac

        val=${val#0x}
        val=${val#0X}
        mask=${mask#0x}
        mask=${mask#0X}

        case "$val" in
            ''|*[!0-9a-fA-F]*) continue ;;
        esac

        case "$mask" in
            '')             clean_mark="$clean_mark 0x$val" ;;
            *[!0-9a-fA-F]*) continue ;;
            *)              clean_mark="$clean_mark 0x$val/0x$mask" ;;
        esac
    done

    clean_mark=${clean_mark# }
    [ -n "$clean_mark" ] || log_warning_router "Значение $var_name отброшено при нормализации, правила для этой метки не создаются"
    eval "$var_name=\"\$clean_mark\""
}

# Проверка статуса прокси-клиента
proxy_status() { pidof "$name_client" >/dev/null; }

# Поиск конфигураций DNS
check_dns_config() {
    [ "$proxy_dns" != "on" ] && echo "false" && return

    if [ "$name_client" = "xray" ]; then
        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue
            strip_json_comments "$file" | jq -e '.dns.servers? != null' >/dev/null 2>&1 && { echo "true"; return; }
        done
    elif [ "$name_client" = "mihomo" ]; then
        [ -f "$mihomo_config" ] && yq -e '.dns.enable == true' "$mihomo_config" >/dev/null 2>&1 && { echo "true"; return; }
    fi

    echo "false"
}
file_dns=$(check_dns_config)

# Кэш зарегистрированных в ядре модулей
_registered_modules=""
_load_registered_modules_cache() {
    for _f in /proc/net/ip_tables_matches /proc/net/ip_tables_targets; do
        [ -f "$_f" ] || continue
        while IFS= read -r _n; do
            [ -n "$_n" ] && _registered_modules="$_registered_modules xt_$_n"
        done < "$_f"
    done

    _registered_modules=" $_registered_modules "
}
_load_registered_modules_cache

# Кэш списка загруженных модулей; is_module_loaded читает его без форков
_loaded_modules=""
_refresh_modules_cache() { _loaded_modules=" $(lsmod 2>/dev/null | awk '{print $1}' | tr '\n' ' ')$_registered_modules"; }

is_module_loaded() {
    case "$_loaded_modules" in
        *" $1 "*) return 0 ;;
        *) return 1 ;;
    esac
}

# Определение пути к модулям
find_module_path() {
    module_name="$1"

    for dir in "$directory_os_modules" "$directory_user_modules" "$directory_opkg_modules" "$directory_system_modules"; do
        if [ -f "$dir/$module_name" ]; then
            echo "$dir/$module_name"
            return 0
        fi
    done
    return 1
}

# Загрузка модулей
load_modules() {
    name="${1%.ko}"

    if ! is_module_loaded "$name"; then
        module_path=$(find_module_path "$1")
        if [ -n "$module_path" ]; then
            insmod "$module_path" >/dev/null 2>&1
        fi
    fi
}

# Обработка модулей и портов
get_modules() {
    _refresh_modules_cache
    load_modules xt_comment.ko
    load_modules xt_TPROXY.ko
    load_modules xt_socket.ko
    load_modules xt_multiport.ko
    load_modules xt_dscp.ko
    _refresh_modules_cache  # подхватить только что insmod-нутые модули

    if ! is_module_loaded xt_comment; then
        log_error_router "Модуль xt_comment не загружен"
        log_error_terminal "
  Модуль '${light_blue}xt_comment${reset}' не загружен
  Невозможно запустить XKeen без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'
"
    fi

    if [ "$mode_proxy" = "TProxy" ] || [ "$mode_proxy" = "Hybrid" ]; then
        for module in xt_TPROXY.ko xt_socket.ko; do
            if ! is_module_loaded "${module%.ko}"; then
                proxy_stop
                log_error_router "Модуль ${module} не загружен"
                log_error_terminal "
  Модуль '${light_blue}${module}${reset}' не загружен
  Невозможно запустить XKeen в режиме ${mode_proxy} без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'
"
            fi
        done
    fi

    if [ -n "$port_donor" ] || [ -n "$port_exclude" ]; then
        if ! is_module_loaded xt_multiport; then
            log_warning_router "Модуль xt_multiport не загружен"
            log_warning_terminal "
  Модуль '${light_blue}xt_multiport${reset}' не загружен
  Невозможно использовать выбранные порты без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'

  Прокси будет запущен на всех портах"
            port_donor=""
            port_exclude=""
        fi
    fi

    if [ -n "$dscp_force_proxy" ] || [ -n "$dscp_exclude" ] || [ -n "$dscp_proxy" ]; then
        if ! is_module_loaded xt_dscp; then
            log_warning_router "Модуль xt_dscp не загружен"
            log_warning_terminal "
  Модуль '${light_blue}xt_dscp${reset}' не загружен
  Работа с DSCP-метками невозможна
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'"
            dscp_force_proxy=""
            dscp_exclude=""
            dscp_proxy=""
        fi
    fi
}

# Получение transparent inbound'ов Xray
_invalidate_inbounds_cache() { rm -f "$xkeen_rundir/inbounds-cache"; }

get_xray_transparent_inbounds() {
    cache_file="$xkeen_rundir/inbounds-cache"
    cache_valid=0
    if [ -f "$cache_file" ]; then
        newer=$(find "$directory_xray_config" -maxdepth 1 -name '*.json' -newer "$cache_file" 2>/dev/null | head -n 1)
        [ -z "$newer" ] && cache_valid=1
    fi
    if [ "$cache_valid" = "1" ]; then
        cat "$cache_file"
        return 0
    fi
    cache_tmp="${cache_file}.tmp.$$"
    {
        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue

            strip_json_comments "$file" |
            jq -r --arg file "$file" '
                .inbounds[]? |
                select(
                    (.protocol == "dokodemo-door" or .protocol == "tunnel") and
                    ((.settings.followRedirect? // false) == true)
                ) |
                (.streamSettings.sockopt.tproxy? // "") as $tproxy |
                select($tproxy == "" or $tproxy == "redirect" or $tproxy == "tproxy") |
                [
                    (if $tproxy == "tproxy" then "tproxy" else "redirect" end),
                    (.port // ""),
                    (.settings.allowedNetwork // .settings.network // ""),
                    (.tag // ""),
                    $file
                ] | @tsv
            ' 2>/dev/null
        done
    } > "$cache_tmp"
    mv "$cache_tmp" "$cache_file"
    cat "$cache_file"
}

get_xray_port_by_mode() {
    mode="$1"
    # Отдельный DSCP force-inbound не должен подменять штатный transparent inbound.
    ignore_tag="$dscp_force_proxy_tag"
    ignore_tag_redirect="${dscp_force_proxy_tag}-redirect"
    ignore_tag_tproxy="${dscp_force_proxy_tag}-tproxy"
    port=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v mode="$mode" -v ignore_tag="$ignore_tag" -v ignore_tag_redirect="$ignore_tag_redirect" -v ignore_tag_tproxy="$ignore_tag_tproxy" '
            $1 == mode && $4 != ignore_tag && $4 != ignore_tag_redirect && $4 != ignore_tag_tproxy && $2 != "" {
                print $2
                exit
            }
        '
    )

    echo "$port"
}

get_xray_network_by_mode() {
    mode="$1"
    ignore_tag="$dscp_force_proxy_tag"
    ignore_tag_redirect="${dscp_force_proxy_tag}-redirect"
    ignore_tag_tproxy="${dscp_force_proxy_tag}-tproxy"
    network=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v mode="$mode" -v ignore_tag="$ignore_tag" -v ignore_tag_redirect="$ignore_tag_redirect" -v ignore_tag_tproxy="$ignore_tag_tproxy" '
            function add_networks(value, count, i, item) {
                gsub(/,/, " ", value)
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
                if (value == "") {
                    return
                }

                count = split(value, items, /[[:space:]]+/)
                for (i = 1; i <= count; i++) {
                    item = items[i]
                    if (item != "" && !seen[item]++) {
                        order[++order_count] = item
                    }
                }
            }

            $1 == mode && $4 != ignore_tag && $4 != ignore_tag_redirect && $4 != ignore_tag_tproxy {
                add_networks($3)
            }

            END {
                for (i = 1; i <= order_count; i++) {
                    printf "%s%s", order[i], (i < order_count ? " " : "")
                }
            }
        '
    )

    echo "$network"
}

get_xray_port_by_tag_mode() {
    tag="$1"
    mode="$2"
    port=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" -v mode="$mode" '
            $4 == tag && $1 == mode && $2 != "" {
                print $2
                exit
            }
        '
    )

    echo "$port"
}

get_xray_network_by_tag_mode() {
    tag="$1"
    mode="$2"
    network=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" -v mode="$mode" '
            function add_networks(value, count, i, item) {
                gsub(/,/, " ", value)
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
                if (value == "") {
                    return
                }

                count = split(value, items, /[[:space:]]+/)
                for (i = 1; i <= count; i++) {
                    item = items[i]
                    if (item != "" && !seen[item]++) {
                        order[++order_count] = item
                    }
                }
            }

            $4 == tag && $1 == mode {
                add_networks($3)
            }

            END {
                for (i = 1; i <= order_count; i++) {
                    printf "%s%s", order[i], (i < order_count ? " " : "")
                }
            }
        '
    )

    echo "$network"
}

# Кэш разбора config.yaml Mihomo (listeners+rules) с mtime-инвалидацией
# по единственному файлу конфига — тот же паттерн, что у get_xray_transparent_inbounds,
# но без проекции: горячему пути resolve_dscp_force_proxy() нужны разные поля
# разных listener'ов, поэтому кэшируется весь JSON, а выборки идут через jq.
_invalidate_mihomo_config_cache() { rm -f "$xkeen_rundir/mihomo-config-cache"; }

get_mihomo_config_cache() {
    cache_file="$xkeen_rundir/mihomo-config-cache"
    cache_valid=0
    if [ -f "$cache_file" ]; then
        newer=$(find "$mihomo_config" -newer "$cache_file" 2>/dev/null | head -n 1)
        [ -z "$newer" ] && cache_valid=1
    fi
    if [ "$cache_valid" = "1" ]; then
        cat "$cache_file"
        return 0
    fi
    cache_tmp="${cache_file}.tmp.$$"
    yq -o=json '.' "$mihomo_config" >"$cache_tmp" 2>/dev/null
    mv "$cache_tmp" "$cache_file"
    cat "$cache_file"
}

get_mihomo_listener_field_by_name() {
    listener_name="$1"
    field_name="$2"

    get_mihomo_config_cache | jq -r --arg name "$listener_name" --arg field "$field_name" '
        .listeners[]? | select(.name == $name) | .[$field] // ""
    ' 2>/dev/null | sed -n '1p'
}

get_mihomo_listener_rule_proxy_by_name() {
    listener_name="$1"

    get_mihomo_config_cache | jq -r '.rules[]? // empty' 2>/dev/null | awk -F',' -v tag="$listener_name" '
        {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $3)
        }
        $1 == "IN-NAME" && $2 == tag { print $3; exit }
    '
}

# listener_type вторым аргументом — если вызывающий код (find_dscp_force_listener)
# уже получил type тем же get_mihomo_listener_field_by_name, повторный запрос не нужен.
get_mihomo_listener_network_by_name() {
    listener_name="$1"
    if [ "$#" -ge 2 ]; then
        listener_type="$2"
    else
        listener_type=$(get_mihomo_listener_field_by_name "$listener_name" "type")
    fi

    case "$listener_type" in
        redir)
            echo "tcp"
            ;;
        tproxy)
            udp_enabled=$(get_mihomo_listener_field_by_name "$listener_name" "udp")
            if [ "$udp_enabled" = "true" ]; then
                echo "tcp udp"
            else
                echo "tcp"
            fi
            ;;
        *)
            echo ""
            ;;
    esac
}

# Получение порта для Redirect
get_port_redirect() {
    if [ "$name_client" = "xray" ]; then
        port=$(get_xray_port_by_mode "redirect")
        [ -n "$port" ] && echo "$port" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        port=$(yq '.redir-port // ""' "$mihomo_config" 2>/dev/null)
        if [ -z "$port" ]; then
            port=$(DSCP_FORCE_TAG="$dscp_force_proxy_tag" DSCP_FORCE_TAG_REDIRECT="${dscp_force_proxy_tag}-redirect" DSCP_FORCE_TAG_TPROXY="${dscp_force_proxy_tag}-tproxy" yq '.listeners[] | select(.type == "redir" and (.name // "") != strenv(DSCP_FORCE_TAG) and (.name // "") != strenv(DSCP_FORCE_TAG_REDIRECT) and (.name // "") != strenv(DSCP_FORCE_TAG_TPROXY)) | .port // ""' "$mihomo_config" 2>/dev/null | sed -n '1p')
        fi
        [ -n "$port" ] && echo "$port" && return 0
    else
        return 1
    fi
}

# Получение порта для TProxy
get_port_tproxy() {
    if [ "$name_client" = "xray" ]; then
        port=$(get_xray_port_by_mode "tproxy")
        [ -n "$port" ] && echo "$port" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        port=$(yq '.tproxy-port // ""' "$mihomo_config" 2>/dev/null)
        if [ -z "$port" ]; then
            port=$(DSCP_FORCE_TAG="$dscp_force_proxy_tag" DSCP_FORCE_TAG_REDIRECT="${dscp_force_proxy_tag}-redirect" DSCP_FORCE_TAG_TPROXY="${dscp_force_proxy_tag}-tproxy" yq '.listeners[] | select(.type == "tproxy" and (.name // "") != strenv(DSCP_FORCE_TAG) and (.name // "") != strenv(DSCP_FORCE_TAG_REDIRECT) and (.name // "") != strenv(DSCP_FORCE_TAG_TPROXY)) | .port // ""' "$mihomo_config" 2>/dev/null | sed -n '1p')
        fi
        [ -n "$port" ] && echo "$port" && return 0
    else
        return 1
    fi
}

# Получение сети для Redirect
get_network_redirect() {
    if [ "$name_client" = "xray" ]; then
        network=$(get_xray_network_by_mode "redirect")
        [ -n "$network" ] && echo "$network" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        [ -n "$port_redirect" ] && echo "tcp" && return 0
        echo "" && return 0
    else
        return 1
    fi
}

# Получение сети для TProxy
get_network_tproxy() {
    if [ "$name_client" = "xray" ]; then
        network=$(get_xray_network_by_mode "tproxy")
        [ -n "$network" ] && echo "$network" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            echo "udp"
        elif [ -z "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            echo "tcp udp"
        else
            echo ""
        fi
        return 0
    else
        return 1
    fi
}

is_valid_single_port() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
    esac

    [ "$1" -ge 1 ] && [ "$1" -le 65535 ]
}

normalize_network_list() {
    printf '%s\n' "$1" | tr ',' ' ' | tr -s ' ' '\n' | awk '
        $0 == "tcp" || $0 == "udp" {
            if (!seen[$0]++) {
                order[++count] = $0
            }
        }
        END {
            for (i = 1; i <= count; i++) {
                printf "%s%s", order[i], (i < count ? " " : "")
            }
        }
    '
}

resolve_dscp_force_proxy() {
    dscp_force_proxy_status="inactive"
    dscp_force_proxy_reason=""
    port_dscp_force_proxy=""
    mode_dscp_force_proxy=""
    network_dscp_force_proxy=""
    port_dscp_force_proxy_redirect=""
    network_dscp_force_proxy_redirect=""
    port_dscp_force_proxy_tproxy=""
    network_dscp_force_proxy_tproxy=""

    # Регрессия a889bf3: тут был name_policy_full (константа "xkeen_full",
    # никогда не пустая) вместо policy_mark_full (реальный runtime-mark
    # политики) — условие было математически недостижимо.
    # Известное ограничение: в ветке `case "$1" in dscp)` (команда
    # `xkeen -dscp`) policy_mark_full не вычисляется (там нет api_cache_init
    # и get_policy_mark, они есть только внутри proxy_start) — в редком
    # сценарии dscp_enable=on + dscp_force_proxy вручную обнулён в конфиге +
    # активна политика xkeen_full статус в этой ветке CLI может быть
    # неточным. Это существующее ограничение, а не новая регрессия.
    if [ -z "$dscp_force_proxy" ] && [ -z "$policy_mark_full" ]; then
        dscp_force_proxy_status="disabled"
        dscp_force_proxy_reason="метка и политика отключены в конфиге XKeen"
        return 1
    fi

    if [ "$mode_proxy" != "TProxy" ] && [ "$mode_proxy" != "Hybrid" ]; then
        dscp_force_proxy_reason="текущий режим ${mode_proxy:-Other} не поддерживается"
        return 1
    fi

    _refresh_modules_cache
    if ! is_module_loaded xt_dscp; then
        dscp_force_proxy_reason="не загружен модуль xt_dscp"
        return 1
    fi

    find_dscp_force_listener() {
        listener_names="$1"

        dscp_force_found_tag=""
        dscp_force_found_port=""
        dscp_force_found_mode=""
        dscp_force_found_network=""
        dscp_force_found_proxy=""

        for listener_name in $listener_names; do
            port_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "port")
            mode_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "type")
            proxy_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "proxy")
            network_lookup=$(normalize_network_list "$(get_mihomo_listener_network_by_name "$listener_name" "$mode_lookup")")
            if [ -n "$port_lookup" ] || [ -n "$mode_lookup" ] || [ -n "$proxy_lookup" ]; then
                dscp_force_found_tag="$listener_name"
                dscp_force_found_port="$port_lookup"
                dscp_force_found_mode="$mode_lookup"
                dscp_force_found_network="$network_lookup"
                dscp_force_found_proxy="$proxy_lookup"
                return 0
            fi
        done

        return 1
    }

    find_dscp_force_inbound() {
        mode_lookup="$1"
        tags_lookup="$2"

        dscp_force_found_tag=""
        dscp_force_found_port=""
        dscp_force_found_network=""

        for tag_lookup in $tags_lookup; do
            port_lookup=$(get_xray_port_by_tag_mode "$tag_lookup" "$mode_lookup")
            network_lookup=$(normalize_network_list "$(get_xray_network_by_tag_mode "$tag_lookup" "$mode_lookup")")
            if [ -n "$port_lookup" ] || [ -n "$network_lookup" ]; then
                dscp_force_found_tag="$tag_lookup"
                dscp_force_found_port="$port_lookup"
                dscp_force_found_network="$network_lookup"
                return 0
            fi
        done

        return 1
    }

    validate_dscp_force_listener() {
        validate_mode="$1"
        validate_required_network="$2"
        validate_names="$3"
        validate_label="$4"

        if ! find_dscp_force_listener "$validate_names"; then
            dscp_force_proxy_reason="не найден ${validate_label} listener для DSCP 61 (ожидается name '${dscp_force_proxy_tag}'"
            case "$validate_mode" in
                redir) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-redirect'" ;;
                tproxy) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-tproxy'" ;;
            esac
            dscp_force_proxy_reason="${dscp_force_proxy_reason}, protocol ${validate_required_network})"
            return 1
        fi

        if [ "$dscp_force_found_mode" != "$validate_mode" ]; then
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' должен иметь type=${validate_mode}"
            return 2
        fi

        if ! is_valid_single_port "$dscp_force_found_port"; then
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' содержит некорректный порт"
            return 2
        fi

        case " $dscp_force_found_network " in
            *" $validate_required_network "*) ;;
            *)
                dscp_force_proxy_reason="listener '${dscp_force_found_tag}' не поддерживает ${validate_required_network}"
                return 2
                ;;
        esac

        if [ -z "$dscp_force_found_proxy" ]; then
            rule_proxy_lookup=$(get_mihomo_listener_rule_proxy_by_name "$dscp_force_found_tag")
            if [ -z "$rule_proxy_lookup" ]; then
                dscp_force_proxy_reason="listener '${dscp_force_found_tag}' должен явно задавать proxy либо иметь правило IN-NAME,${dscp_force_found_tag} в rules"
                return 2
            fi
            dscp_force_found_proxy="$rule_proxy_lookup"
        fi

        return 0
    }

    validate_dscp_force_inbound() {
        validate_mode="$1"
        validate_required_network="$2"
        validate_tags="$3"
        validate_label="$4"

        if ! find_dscp_force_inbound "$validate_mode" "$validate_tags"; then
            dscp_force_proxy_reason="не найден ${validate_label} inbound для DSCP 61 (ожидается tag '${dscp_force_proxy_tag}'"
            case "$validate_mode" in
                redirect) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-redirect'" ;;
                tproxy) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-tproxy'" ;;
            esac
            dscp_force_proxy_reason="${dscp_force_proxy_reason}, protocol ${validate_required_network})"
            return 1
        fi

        if ! is_valid_single_port "$dscp_force_found_port"; then
            dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' содержит некорректный порт"
            return 2
        fi

        case " $dscp_force_found_network " in
            *" $validate_required_network "*) ;;
            *)
                dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' не поддерживает ${validate_required_network}"
                return 2
                ;;
        esac

        return 0
    }

    dscp_force_redirect_names="${dscp_force_proxy_tag}-redirect ${dscp_force_proxy_tag}"
    dscp_force_tproxy_names="${dscp_force_proxy_tag}-tproxy ${dscp_force_proxy_tag}"

    case "$name_client" in
        xray)
            if [ "$mode_proxy" = "Hybrid" ]; then
                validate_dscp_force_inbound "redirect" "tcp" "$dscp_force_redirect_names" "redirect"
                redirect_status=$?
                [ "$redirect_status" -ne 0 ] && return "$redirect_status"

                port_dscp_force_proxy_redirect="$dscp_force_found_port"
                network_dscp_force_proxy_redirect="tcp"

                validate_dscp_force_inbound "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_status=$?
                [ "$tproxy_status" -ne 0 ] && return "$tproxy_status"

                port_dscp_force_proxy_tproxy="$dscp_force_found_port"
                network_dscp_force_proxy_tproxy="udp"

                port_dscp_force_proxy="$port_dscp_force_proxy_tproxy"
                mode_dscp_force_proxy="hybrid"
                network_dscp_force_proxy=$(normalize_network_list "$network_dscp_force_proxy_redirect $network_dscp_force_proxy_tproxy")
                dscp_force_proxy_status="active"
                dscp_force_proxy_reason="Hybrid DSCP 61: tcp -> redirect:${port_dscp_force_proxy_redirect}, udp -> tproxy:${port_dscp_force_proxy_tproxy}"
                return 0
            fi

            validate_dscp_force_inbound "tproxy" "tcp" "$dscp_force_tproxy_names" "tproxy"
            tproxy_tcp_status=$?
            if [ "$tproxy_tcp_status" -ne 0 ]; then
                validate_dscp_force_inbound "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_udp_status=$?
                [ "$tproxy_udp_status" -ne 0 ] && return "$tproxy_udp_status"
            fi

            port_dscp_force_proxy="$dscp_force_found_port"
            mode_dscp_force_proxy="tproxy"
            network_dscp_force_proxy="$dscp_force_found_network"
            port_dscp_force_proxy_tproxy="$dscp_force_found_port"
            network_dscp_force_proxy_tproxy="$dscp_force_found_network"
            dscp_force_proxy_status="active"
            dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' найден: порт ${port_dscp_force_proxy}, network ${network_dscp_force_proxy}"
            return 0
            ;;
        mihomo)
            if [ "$mode_proxy" = "Hybrid" ]; then
                validate_dscp_force_listener "redir" "tcp" "$dscp_force_redirect_names" "redirect"
                redirect_status=$?
                [ "$redirect_status" -ne 0 ] && return "$redirect_status"

                port_dscp_force_proxy_redirect="$dscp_force_found_port"
                network_dscp_force_proxy_redirect="tcp"
                proxy_dscp_force_proxy_redirect="$dscp_force_found_proxy"

                validate_dscp_force_listener "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_status=$?
                [ "$tproxy_status" -ne 0 ] && return "$tproxy_status"

                port_dscp_force_proxy_tproxy="$dscp_force_found_port"
                network_dscp_force_proxy_tproxy="udp"
                proxy_dscp_force_proxy_tproxy="$dscp_force_found_proxy"

                port_dscp_force_proxy="$port_dscp_force_proxy_tproxy"
                mode_dscp_force_proxy="hybrid"
                network_dscp_force_proxy=$(normalize_network_list "$network_dscp_force_proxy_redirect $network_dscp_force_proxy_tproxy")
                dscp_force_proxy_status="active"
                dscp_force_proxy_reason="Hybrid DSCP 61: tcp -> redir:${port_dscp_force_proxy_redirect} (${proxy_dscp_force_proxy_redirect}), udp -> tproxy:${port_dscp_force_proxy_tproxy} (${proxy_dscp_force_proxy_tproxy})"
                return 0
            fi

            validate_dscp_force_listener "tproxy" "tcp" "$dscp_force_tproxy_names" "tproxy"
            tproxy_tcp_status=$?
            if [ "$tproxy_tcp_status" -ne 0 ]; then
                validate_dscp_force_listener "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_udp_status=$?
                [ "$tproxy_udp_status" -ne 0 ] && return "$tproxy_udp_status"
            fi

            port_dscp_force_proxy="$dscp_force_found_port"
            mode_dscp_force_proxy="tproxy"
            network_dscp_force_proxy="$dscp_force_found_network"
            port_dscp_force_proxy_tproxy="$dscp_force_found_port"
            network_dscp_force_proxy_tproxy="$dscp_force_found_network"
            dscp_force_proxy_status="active"
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' найден: порт ${port_dscp_force_proxy}, network ${network_dscp_force_proxy}, proxy ${dscp_force_found_proxy}"
            return 0
            ;;
        *)
            dscp_force_proxy_reason="функция не поддерживается для ${name_client}"
            return 1
            ;;
    esac
}

configure_dscp_force_proxy() {
    resolve_dscp_force_proxy
    status_code=$?

    if [ "$status_code" -eq 2 ]; then
        log_warning_router "$dscp_force_proxy_reason"
        log_warning_terminal "
  DSCP force-proxy '${yellow}${dscp_force_proxy_tag}${reset}' найден, но настроен неверно
  ${light_blue}${dscp_force_proxy_reason}${reset}

  Маршрутизация по DSCP ${green}${dscp_force_proxy}${reset} ${red}отключена${reset}"
    fi

    return 0
}

print_dscp_force_proxy_status() {
    port_redirect=$(get_port_redirect)
    network_redirect=$(get_network_redirect)
    port_tproxy=$(get_port_tproxy)
    network_tproxy=$(get_network_tproxy)
    mode_proxy=$(get_mode_proxy)

    resolve_dscp_force_proxy >/dev/null 2>&1

    # Проверка DSCP 61
    if [ "$dscp_force_proxy_status" = "active" ]; then
        echo -e "  DSCP ${green}${dscp_force_proxy}${reset}: ${green}активно${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    elif [ "$dscp_force_proxy_status" = "disabled" ]; then
        echo -e "  DSCP 61 force proxy: ${yellow}отключено${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    else
        echo -e "  DSCP ${green}${dscp_force_proxy}${reset}: ${red}не активно${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    fi

    # Проверка DSCP 62
    if [ -n "$dscp_exclude" ]; then
        echo -e "  DSCP ${green}$dscp_exclude${reset}: ${green}активно${reset} (${light_blue}исключение из проксирования${reset})"
    else
        echo -e "  DSCP ${green}$dscp_exclude${reset}: ${red}не активно${reset}"
    fi

    # Проверка DSCP 63
    if [ -n "$dscp_proxy" ]; then
        echo -e "  DSCP ${green}$dscp_proxy${reset}: ${green}активно${reset} (${light_blue}проксирование по системым правилам${reset})"
    else
        echo -e "  DSCP ${green}$dscp_proxy${reset}: ${red}не активно${reset}"
    fi
}

# Получение портов исключения из статических пробросов
get_api_exclude_ports() {
    api_redir_result=""

    if [ -n "$api_static_json" ]; then
        api_redir_result=$(echo "$api_static_json" | jq -r '
          [
            .[] | 
            select(.disable != true) | 
            if has("end-port") then 
              "\(.port):\(.["end-port"])" 
            else 
              .port 
            end |
            select(. != "80" and . != "443")
          ] | 
          sort | 
          join(",")')
    fi

    echo "$api_redir_result"
}


# Получение исключенных портов
get_port_exclude() {
    port_exclude_redirect=""
    port_exclude_result=""

    port_exclude_redirect=$(get_api_exclude_ports)

    if [ -n "$port_exclude" ]; then
        if [ -n "$port_exclude_redirect" ]; then
            port_exclude_result="$port_exclude,$port_exclude_redirect"
        else
            port_exclude_result="$port_exclude"
        fi
    else
        port_exclude_result="$port_exclude_redirect"
    fi

    port_exclude_result=$(printf '%s\n' "$port_exclude_result" | tr -dc '0-9,:' | tr -s ',' | sed 's/^,//; s/,$//')
    echo "$port_exclude_result"
}

# Получение исключений IPv4.
get_exclude_ip4() {
    [ "$iptables_supported" != "true" ] && return

    # Получаем провайдерский IPv4
    ipv4_eth=$(ip -o route get 77.88.8.8 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p')
    [ -n "$ipv4_eth" ] && ipv4_eth="${ipv4_eth}/32"
    echo "${ipv4_eth} ${ipv4_exclude}" | tr ' ' '\n' | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/^ //; s/ $//'
}

# Получение исключений IPv6.
get_exclude_ip6() {
    [ "$ip6tables_supported" != "true" ] && return

    # Получаем провайдерский IPv6
    ipv6_eth=$(ip -o -6 route get 2a02:6b8::feed:0ff 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p')
    [ -n "$ipv6_eth" ] && ipv6_eth="${ipv6_eth}/128"
    echo "${ipv6_eth} ${ipv6_exclude}" | tr ' ' '\n' | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/^ //; s/ $//'
}

# Получение метки политики
get_policy_mark() {
    _mark=""
    if [ -n "$api_policy_json" ] && [ -n "$1" ]; then
        _mark=$(echo "$api_policy_json" | jq -r --arg pname "$1" '.[] | select(.description | ascii_downcase == ($pname | ascii_downcase)) | .mark // empty' 2>/dev/null)
    fi

    if [ -n "$_mark" ]; then
        printf '0x%s\n' "$_mark"
    else
        printf '\n'
    fi
}

hex_mark_to_decimal() {
    mark="$1"
    mark="${mark#0x}"
    mark="${mark#0X}"

    case "$mark" in
        ''|*[!0-9a-fA-F]*) return 1 ;;
    esac

    printf '%s\n' "$mark" | awk '
        BEGIN { digits = "0123456789abcdef" }
        {
            value = 0
            mark = tolower($0)
            for (i = 1; i <= length(mark); i++) {
                digit = substr(mark, i, 1)
                pos = index(digits, digit)
                if (pos == 0) {
                    exit 1
                }
                value = value * 16 + pos - 1
            }
            printf "%.0f\n", value
        }
    '
}

# Атомарная синхронизация ipset xkeen_deny_mac с текущим состоянием hotspot API.
# Идемпотентна: создаёт основной набор при первом вызове, в дальнейшем
# наполняет tmp-набор и делает ipset swap. Вызывается на старте XKeen и
# на каждой netfilter.d/schedule.d-инвокации — это даёт динамику без
# `xkeen -restart` при работе Keenetic-расписаний (родительский контроль).
sync_deny_mac_ipset() {
    command -v ipset >/dev/null 2>&1 || return 0
    ipset create "$name_ipset_deny_mac" hash:mac -exist 2>/dev/null || return 0
    _xkeen_deny_tmp="${name_ipset_deny_mac}_tmp"
    ipset create "$_xkeen_deny_tmp" hash:mac -exist 2>/dev/null
    ipset flush "$_xkeen_deny_tmp" >/dev/null 2>&1
    _xkeen_hotspot_json=$(curl_api "${url_server}/${url_hotspot}" 2>/dev/null)
    if [ -z "$_xkeen_hotspot_json" ]; then
        # Сбой RCI/curl: не swap'аем пустой tmp поверх живого набора —
        # иначе родительский контроль «Без интернета» снимается до следующего успеха.
        ipset destroy "$_xkeen_deny_tmp" 2>/dev/null
        unset _xkeen_deny_tmp _xkeen_hotspot_json
        return 0
    fi
    if printf '%s' "$_xkeen_hotspot_json" | jq -r '
        ((.host // . // []) |
         (if type == "array" then .[] else . end)) |
        select((.access // "") == "deny" and (.mac // "") != "") |
        .mac
    ' 2>/dev/null | tr '[:lower:]' '[:upper:]' | \
         awk -v set="$_xkeen_deny_tmp" '/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/ {print "add " set " " $0 " -exist"}' | \
         ipset restore -exist; then
        ipset swap "$_xkeen_deny_tmp" "$name_ipset_deny_mac" 2>/dev/null
    else
        log_warning_router "Не удалось восстановить $name_ipset_deny_mac из hotspot API"
    fi
    ipset destroy "$_xkeen_deny_tmp" 2>/dev/null
    unset _xkeen_deny_tmp _xkeen_hotspot_json
}

# Получаем пользовательские политики
get_user_policies() {
    [ ! -f "$xkeen_config" ] && return
    _xkeen_cached_json | jq -r '.xkeen.policy[]? | "\(.name)|\(.port // "")" ' 2>/dev/null
}

# Проверка на конфликт имен политик
check_policy_name_conflict() {
    if [ -f "$xkeen_config" ]; then
        conflict=$(_xkeen_cached_json | jq -r \
          --arg main "$name_policy" \
          --arg full "$name_policy_full" \
          '[ .xkeen.policy[] | select((.name | ascii_downcase) == ($main | ascii_downcase) or (.name | ascii_downcase) == ($full | ascii_downcase)) | .name ] | join(", ")' 2>/dev/null)

        if [ -n "$conflict" ]; then
            log_error_router "Ошибка конфигурации: Имя политики в xkeen.json совпадает с зарезервированным"
            log_error_terminal "
  Имя пользовательской политики совпадает с зарезервированным: '${light_blue}${conflict}${reset}'
  Устраните конфликт политик в файле '${yellow}xkeen.json${reset}'

  Запуск ${yellow}$name_client${reset} ${red}отменен${reset}
"
        fi
    fi
}

# Получаем порты пользовательских политик
resolve_user_policies() {
    [ -f "$xkeen_config" ] && [ -n "$api_policy_json" ] || return

    api_exclude_ports=$(get_api_exclude_ports)

    # Получаем сопоставленные политики одним вызовом jq
    matched_policies=$(printf '%s' "$api_policy_json" | jq -r --argjson user_cfg "$(_xkeen_cached_json)" '
        ($user_cfg.xkeen.policy // []) as $up |
        .[] as $api |
        $up[] | 
        select(
            (.name // "" | ascii_downcase) == 
            ($api.description // "" | ascii_downcase)
        ) |
        "\(.name)|\($api.mark // "")|\(.port // "")"
    ' 2>/dev/null)

    [ -z "$matched_policies" ] && return

    # Обрабатываем каждую политику в одном цикле
    echo "$matched_policies" | while IFS='|' read -r pname mark pports; do
        if [ -z "$pports" ]; then
            # Порты не указаны -> режим "all" (все порты)
            if [ -n "$api_exclude_ports" ]; then
                echo "${pname}|${mark}|exclude|${api_exclude_ports}"
            else
                echo "${pname}|${mark}|all|"
            fi
        else
            case "$pports" in
                !*) mode="exclude"; ports="${pports#!}"
                    [ -n "$api_exclude_ports" ] && ports="${ports:+$ports,}$api_exclude_ports" ;;
                *) mode="include"; ports="$pports"
                    if [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ]; then
                        case ",$ports," in
                            *,53,*) ;;
                            *) ports="53,$ports" ;;
                        esac
                    fi
                    ;;
            esac

            clean_ports=$(validate_and_clean_ports "$ports")
            [ -n "$clean_ports" ] && echo "${pname}|${mark}|${mode}|${clean_ports}"
        fi
    done
}

# Получение режима прокси-клиента
get_mode_proxy() {
    if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
        mode_proxy="Hybrid"
    elif [ -n "$port_tproxy" ]; then
        mode_proxy="TProxy"
    elif [ -n "$port_redirect" ]; then
        mode_proxy="Redirect"
    else
        mode_proxy="Other"
    fi
    echo "$mode_proxy"
}

# Настройка брандмауэра
configure_firewall() {
    # Пишем во временный файл и атомарно подменяем: иначе DHCP renew
    # посреди генерации вызывает пустой/обрезанный proxy.sh.
    _hook_live="$file_netfilter_hook"
    _hook_tmp="${_hook_live}.tmp.$$"
    rm -f "$_hook_tmp"
    file_netfilter_hook="$_hook_tmp"

    # Pre-evaluate dynamic variables
    val_exclude_ip6="$(get_exclude_ip6)"
    val_exclude_ip4="$(get_exclude_ip4)"

    cat > "$file_netfilter_hook" <<'EOL'
#!/bin/sh
# XKeen: Auto-generated file. DO NOT EDIT!
PATH="/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin"
_xkeen_secure_rundir() {
    d="/tmp/.xkeen"
    if [ -e "$d" ] && [ ! -d "$d" ]; then rm -f "$d" 2>/dev/null; fi
    if [ -d "$d" ]; then
        set -- $(ls -ld "$d" 2>/dev/null)
        if [ "$3" = "root" ] && [ "$1" = "drwx------" ]; then
            printf '%s' "$d"
            return 0
        fi
        rm -rf "$d" 2>/dev/null
    fi
    [ -d "$d" ] || mkdir -m 700 "$d" 2>/dev/null || return 1
    chmod 700 "$d" 2>/dev/null || return 1
    printf '%s' "$d"
}
_xkeen_rundir=$(_xkeen_secure_rundir) || exit 1
[ -f "$_xkeen_rundir/ready" ] || exit 0
case "${table:-}" in filter|raw) exit 0 ;; esac
EOL

    # Securely inject variables into the script
    # ${val//\'/...} — намеренная bash-совместимая экспансия: busybox ash по умолчанию собран с CONFIG_ASH_BASH_COMPAT=y и в upstream (shell/ash.c), и в Entware (Config-defaults.in).
    # POSIX-замена printf|sed уже пробовалась и дважды откатывалась апстримом (e3c0d54→c28e73d, PR #44): лишний форк на каждый из ~40 вызовов за генерацию хука (KN-3812: 5.01s→4.78s без него), плюс command substitution обрезает trailing \n, чего parameter expansion не делает.
    # Не переоткрывать без багрепорта с реального устройства, где expansion фактически не работает.
    inject_var() {
        local name="$1"
        local val="$2"
        local safe_val
        safe_val="${val//\'/\'\\\'\'}"
        printf "%s='%s'\n" "$name" "$safe_val" >> "$file_netfilter_hook"
    }

    inject_var name_client "$name_client"
    inject_var name_profile "$name_profile"
    inject_var mode_proxy "$mode_proxy"
    inject_var network_redirect "$network_redirect"
    inject_var network_tproxy "$network_tproxy"
    inject_var networks "$networks"
    inject_var name_chain "$name_chain"
    inject_var port_redirect "$port_redirect"
    inject_var port_tproxy "$port_tproxy"
    inject_var port_dscp_force_proxy "$port_dscp_force_proxy"
    inject_var port_dscp_force_proxy_redirect "$port_dscp_force_proxy_redirect"
    inject_var port_dscp_force_proxy_tproxy "$port_dscp_force_proxy_tproxy"
    inject_var port_donor "$port_donor"
    inject_var port_exclude "$port_exclude"
    inject_var policy_mark "$policy_mark"
    inject_var policy_mark_full "$policy_mark_full"
    inject_var comment_tag "$comment_tag"
    inject_var comment "$comment"
    inject_var custom_mark "$custom_mark"
    inject_var nfqws_mark "$nfqws_mark"
    inject_var dscp_exclude "$dscp_exclude"
    inject_var dscp_proxy "$dscp_proxy"
    inject_var dscp_force_proxy "$dscp_force_proxy"
    inject_var dscp_force_proxy_tag "$dscp_force_proxy_tag"
    inject_var mode_dscp_force_proxy "$mode_dscp_force_proxy"
    inject_var network_dscp_force_proxy "$network_dscp_force_proxy"
    inject_var network_dscp_force_proxy_redirect "$network_dscp_force_proxy_redirect"
    inject_var network_dscp_force_proxy_tproxy "$network_dscp_force_proxy_tproxy"
    inject_var user_policies "$user_policies"
    inject_var table_redirect "$table_redirect"
    inject_var table_tproxy "$table_tproxy"
    inject_var table_mark "$table_mark"
    inject_var table_id "$table_id"
    inject_var file_dns "$file_dns"
    inject_var arm_cpu "$arm_cpu"
    inject_var file_ca "$file_ca"
    inject_var proxy_dns "$proxy_dns"
    inject_var proxy_router "$proxy_router"
    inject_var directory_configs_app "$directory_configs_app"
    inject_var directory_xray_config "$directory_xray_config"
    inject_var directory_xray_asset "$directory_xray_asset"
    inject_var iptables_supported "$iptables_supported"
    inject_var ip6tables_supported "$ip6tables_supported"
    inject_var arm64_fd "$arm64_fd"
    inject_var other_fd "$other_fd"
    inject_var aghfix "$aghfix"
    
    inject_var ipv6_proxy "$ipv6_proxy"
    inject_var ipv4_proxy "$ipv4_proxy"
    inject_var val_exclude_ip6 "$val_exclude_ip6"
    inject_var val_exclude_ip4 "$val_exclude_ip4"
    inject_var name_ipset_deny_mac "$name_ipset_deny_mac"
    inject_var url_server "$url_server"
    inject_var url_hotspot "$url_hotspot"
    inject_var rci_token "$rci_token"
    inject_var ru_exclude_ipv4 "$ru_exclude_ipv4"
    inject_var ru_exclude_ipv6 "$ru_exclude_ipv6"
    # GOMEMLIMIT для respawn mihomo внутри хука (вычислен при генерации)
    apply_gomemlimit
    inject_var gomemlimit_value "$gomemlimit_value"
    inject_var killswitch "$killswitch"

    cat >> "$file_netfilter_hook" <<'EOL'

# Перезапуск скрипта
restart_script() {
    exec /bin/sh "$0" "$@"
}

# Дубль функции: см. также top-level копию (~316) в 04_register_init.sh и
# 01_info_common.sh:curl_api — правь все три места синхронно.
curl_api() {
    if [ -n "$rci_token" ]; then
        curl --noproxy '*' --connect-timeout 2 -m 5 -kfsS -H "X-Ndma-Tkn: $rci_token" "$@"
    else
        curl --noproxy '*' --connect-timeout 2 -m 5 -kfsS "$@"
    fi
}

# Весь сгенерированный netfilter-хук (proxy.sh) — один compound-оператор
# if/then/else/fi (открытие здесь, `else` и `fi` на нулевом уровне
# вложенности ниже, обе ветки целиком, все функции внутри). ash обязан
# полностью разобрать его на каждое событие netfilter.d/schedule.d,
# прежде чем начать что-либо исполнять — в т.ч. fast-path выход
# _xkeen_rules_intact ниже: он экономит только исполнение, не разбор.
if pidof "$name_client" >/dev/null; then

    # Сериализация прогонов хука. NDM вызывает netfilter.d конкурентно —
    # по событию на каждую пересобранную (type, table) пару, плюс schedule.d.
    # Два параллельных прогона опасны: delete-list строится по снапшоту
    # iptables-save, и restore соседа может отвергнуть весь блоб целиком.
    # mkdir — единственный атомарный lock в busybox-ash. Не дождались за
    # ~5 с — держатель уже применил актуальное состояние, выходим; если
    # правила всё же не целы, следующее событие NDM их доставит.
    _xkeen_nf_lock="$_xkeen_rundir/netfilter.lock.d"
    _xkeen_lock_owned=""
    _lock_try=0
    while [ "$_lock_try" -lt 50 ]; do
        if mkdir "$_xkeen_nf_lock" 2>/dev/null; then
            _xkeen_lock_owned=1
            printf '%s' "$$" > "$_xkeen_nf_lock/pid"
            trap 'rm -rf "$_xkeen_nf_lock"' EXIT INT TERM
            break
        fi
        _lock_pid=$(cat "$_xkeen_nf_lock/pid" 2>/dev/null)
        if [ -n "$_lock_pid" ] && ! kill -0 "$_lock_pid" 2>/dev/null; then
            rm -rf "$_xkeen_nf_lock" 2>/dev/null
            continue
        fi
        _lock_try=$((_lock_try + 1))
        usleep 100000 2>/dev/null || sleep 1
    done
    [ -n "$_xkeen_lock_owned" ] || exit 0

    # Динамическая синхронизация ipset с deny-MAC из hotspot API.
    # Закрывает обход built-in политики «Без доступа в интернет» при включенном
    # проксировании: PREROUTING на эти MAC делает RETURN до TPROXY, пакет идёт
    # в FORWARD, где штатно дропается NDM-цепочкой _NDM_HOTSPOT_FWD.
    # Хук перезапускается NDM при netfilter rewrite, schedule.d дёргает этот же
    # скрипт на start/stop расписаний — список MAC всегда актуален.
    # Вызывается ПОСЛЕ _xkeen_apply: NDM к моменту вызова хука уже снёс
    # xkeen-цепочки, и каждая миллисекунда до их восстановления — окно, в
    # котором проксируемый трафик идёт мимо политики. curl к hotspot API
    # (до 2+5 c таймаутов) в этом окне недопустим; правилам достаточно,
    # чтобы ipset существовал — членство синхронизируется после.
    _xkeen_sync_deny_mac_ipset() {
        command -v ipset >/dev/null 2>&1 || return 0
        ipset create "$name_ipset_deny_mac" hash:mac -exist 2>/dev/null || return 0
        _tmp="${name_ipset_deny_mac}_tmp"
        ipset create "$_tmp" hash:mac -exist 2>/dev/null
        ipset flush "$_tmp" >/dev/null 2>&1
        _hjson=$(curl_api "${url_server}/${url_hotspot}" 2>/dev/null)
        if [ -z "$_hjson" ]; then
            # Сбой curl/RCI: не затираем живой deny-MAC пустым набором.
            ipset destroy "$_tmp" 2>/dev/null
            return 0
        fi
        if printf '%s' "$_hjson" | jq -r '
            ((.host // . // []) |
             (if type == "array" then .[] else . end)) |
            select((.access // "") == "deny" and (.mac // "") != "") |
            .mac
        ' 2>/dev/null | tr '[:lower:]' '[:upper:]' | \
             awk -v set="$_tmp" '/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/ {print "add " set " " $0 " -exist"}' | \
             ipset restore -exist; then
            ipset swap "$_tmp" "$name_ipset_deny_mac" 2>/dev/null
        else
            logger -p warning -t XKeen "Не удалось восстановить $name_ipset_deny_mac из hotspot API"
        fi
        ipset destroy "$_tmp" 2>/dev/null
    }
    command -v ipset >/dev/null 2>&1 && ipset create "$name_ipset_deny_mac" hash:mac -exist 2>/dev/null

    # Снять nf-lock до медленного curl (deny-MAC) / exit: иначе соседние
    # события NDM ждут ~5 с и уходят с exit 0, не восстановив цепочки.
    _xkeen_release_nf_lock() {
        if [ -n "$_xkeen_lock_owned" ]; then
            rm -rf "$_xkeen_nf_lock" 2>/dev/null
            _xkeen_lock_owned=""
            trap - EXIT INT TERM
        fi
    }

    # Аккумулируем правила в строки, применяем атомарно одним
    # iptables-restore --noflush на (family, table) в _xkeen_apply.
    # Сохраняем семантику старого ipt() для всех существующих helper'ов.
    _xkeen_v4_nat_rules=""
    _xkeen_v4_mangle_rules=""
    _xkeen_v6_nat_rules=""
    _xkeen_v6_mangle_rules=""

    ipt() {
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && return 0
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && return 0

        case "$1" in
            -A|-I|-D)
                _line=$*
                case "${family}_${table}" in
                    iptables_nat)     _xkeen_v4_nat_rules="${_xkeen_v4_nat_rules}${_line}
" ;;
                    iptables_mangle)  _xkeen_v4_mangle_rules="${_xkeen_v4_mangle_rules}${_line}
" ;;
                    ip6tables_nat)    _xkeen_v6_nat_rules="${_xkeen_v6_nat_rules}${_line}
" ;;
                    ip6tables_mangle) _xkeen_v6_mangle_rules="${_xkeen_v6_mangle_rules}${_line}
" ;;
                esac
                return 0
                ;;
            *)
                # Прочие операции (-F, -X) - в реальный iptables.
                if [ "$family" = "iptables" ]; then
                    iptables -w -t "$table" "$@"
                else
                    ip6tables -w -t "$table" "$@"
                fi
                return $?
                ;;
        esac
    }

    _xkeen_use_divert() {
        [ "$1" = "$table_tproxy" ] || return 1
        [ -n "$port_tproxy" ] || return 1
        case "$network_tproxy" in
            *tcp*) return 0 ;;
        esac
        return 1
    }

    # Применяет аккумулированные правила одной таблицы атомарно через
    # iptables-restore --noflush. Custom chain $name_chain flush'ится
    # объявлением ":$name_chain -" перед добавлением новых правил.
    _xkeen_apply_table() {
        _family="$1"
        _table="$2"
        _rules_var="$3"

        eval "_rules=\${$_rules_var}"
        [ -z "$_rules" ] && return 0

        # Удаляем устаревшие xkeen-tagged правила из built-in/system chain'ов
        # (PREROUTING, OUTPUT, _NDM_HOTSPOT_DNSREDIR), правила из самой $name_chain
        # игнорируются - там ":chain -" в blob их сам flush'ит.
        save_cmd=""
        [ "$_family" = "iptables" ] && [ "$iptables_supported" = "true" ] && save_cmd="iptables-save"
        [ "$_family" = "ip6tables" ] && [ "$ip6tables_supported" = "true" ] && save_cmd="ip6tables-save"
        [ -z "$save_cmd" ] && { _deletes=""; return; }

        _deletes=$($save_cmd -t "$_table" 2>/dev/null | awk \
            -v tag="$comment_tag" \
            -v c1="$name_chain" \
            -v c2="${name_chain}_out" \
            -v c3="${name_chain}_force" \
            -v c4="${name_chain}_divert" '
            index($0, tag) &&
            $1 == "-A" &&
            $2 != c1 &&
            $2 != c2 &&
            $2 != c3 &&
            $2 != c4 {
                sub(/^-A /, "-D ")
                print
            }
        ')

        _blob=$( {
            printf '*%s\n' "$_table"
            printf ':%s -\n' "$name_chain"
            { [ -n "$port_dscp_force_proxy" ] || [ -n "$policy_mark_full" ]; } && printf ':%s_force -\n' "$name_chain"
            [ "$proxy_router" = "on" ] && printf ':%s_out -\n' "$name_chain"
            _xkeen_use_divert "$_table" && printf ':%s_divert -\n' "$name_chain"
            [ -n "$_deletes" ] && printf '%s\n' "$_deletes"
            printf '%s' "$_rules"
            printf 'COMMIT'
        } )

        _restore_cmd="iptables-restore"
        [ "$_family" = "ip6tables" ] && _restore_cmd="ip6tables-restore"

        # Отказ restore = таблица осталась без правил xkeen до следующего
        # события netfilter, молча. До двух повторных попыток с нарастающей
        # паузой закрывают гонку с параллельной модификацией таблицы
        # (delete-list строится по снапшоту iptables-save); стойкий отказ
        # уходит в syslog — иначе диагностировать «прокси молча перестал
        # перехватывать» нечем.
        _attempt=1
        _max_attempts=3
        while :; do
            _restore_err=$(printf '%s\n' "$_blob" | "$_restore_cmd" --noflush 2>&1) && {
                [ "$_attempt" -gt 1 ] && \
                logger -p notice -t XKeen "$_restore_cmd $_table: applied on retry $_attempt"
                break
            }
            if [ "$_attempt" -ge "$_max_attempts" ]; then
                logger -p error -t XKeen \
                "$_restore_cmd --noflush failed for $_table after $_attempt attempts: $(printf '%s' "$_restore_err" | head -n1)"
                return 1
            fi
            usleep $((200000 * _attempt)) 2>/dev/null || sleep "$_attempt"
            _attempt=$((_attempt + 1))
        done
        return 0
    }

    _xkeen_apply() {
        [ "$iptables_supported" = "true" ] && _xkeen_apply_table iptables nat _xkeen_v4_nat_rules || true
        [ "$iptables_supported" = "true" ] && _xkeen_apply_table iptables mangle _xkeen_v4_mangle_rules || true
        [ "$ip6tables_supported" = "true" ] && _xkeen_apply_table ip6tables nat _xkeen_v6_nat_rules || true
        [ "$ip6tables_supported" = "true" ] && _xkeen_apply_table ip6tables mangle _xkeen_v6_mangle_rules || true
    }

    # Пока NDM держит цепочки снесёнными, пакет установленного UDP-потока
    # может уйти по FORWARD, и его забрать сетевой ускоритель (PPE): дальше
    # поток идёт мимо netfilter и после возврата правил не восстанавливается.
    # Удаление conntrack-записи заставляет следующий пакет пройти через
    # xkeen-цепочку заново и снимает offload-запись.
    # TPROXY-потоки помечены в conntrack меткой $table_mark (CONNMARK --save-mark
    # в xkeen-цепочке), поэтому удаляем записи именно по ней: NAT-нутые
    # DIRECT-потоки (метки NDM) и собственные потоки роутера (mark 0) не
    # затрагиваются. Только UDP: для TCP это привело бы к RST.
    _xkeen_flush_udp_conntrack() {
        case "$mode_proxy" in TProxy|Hybrid) ;; *) return 0 ;; esac
        command -v conntrack >/dev/null 2>&1 || return 0
        conntrack -D -p udp -m "$(( table_mark ))" >/dev/null 2>&1
    }

    # Добавление правил-исключений
    add_exclude_rules() {
        chain="$1"
        for exclude in $exclude_list; do
            if [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && [ "$chain" != "${name_chain}_out" ]; then
                case "$exclude" in
                    10.0.0.0/8|172.16.0.0/12|192.168.0.0/16|fd00::/8|fe80::/10)
                        if [ "$table" = "mangle" ] && [ "$mode_proxy" = "Hybrid" ]; then
                            ipt -A "$chain" -d "$exclude" -p tcp --dport 53 $comment -j RETURN >/dev/null 2>&1
                            ipt -A "$chain" -d "$exclude" -p udp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                        elif [ "$table" = "nat" ] && [ "$mode_proxy" = "Hybrid" ]; then
                            ipt -A "$chain" -d "$exclude" -p tcp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                            ipt -A "$chain" -d "$exclude" -p udp --dport 53 $comment -j RETURN >/dev/null 2>&1
                        elif [ "$table" = "mangle" ] && [ "$mode_proxy" = "TProxy" ]; then
                            ipt -A "$chain" -d "$exclude" -p tcp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                            ipt -A "$chain" -d "$exclude" -p udp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                        fi
                        ;;
                    *)
                        # Остальные исключения (WAN роутера, 224.0.0.0/4, 100.64.0.0/10,
                        # 255.255.255.255, IPv6 ff00::/8 и пользовательские адреса) ставятся
                        # как без перехвата DNS: без ветки *) case молча их отбрасывал.
                        ipt -A "$chain" -d "$exclude" $comment -j RETURN >/dev/null 2>&1
                        ;;
                esac
            else
                ipt -A "$chain" -d "$exclude" $comment -j RETURN >/dev/null 2>&1
            fi
        done
    }

    add_ipset_exclude() {
        base_set="$1"
        set_type="${2:-hash:net}"

        if [ "$family" = "ip6tables" ]; then
            set_name="${base_set}6"
            ipset_family="inet6"
        else
            set_name="$base_set"
            ipset_family="inet"
        fi

        ipset create "$set_name" "$set_type" family "$ipset_family" -exist || return

        ipt -I "$chain" 1 -m set --match-set "$set_name" dst $comment -j RETURN >/dev/null 2>&1

        if [ "$base_set" = "user_exclude" ]; then
            ipt -I "$chain" 1 -m set --match-set "$set_name" src $comment -j RETURN >/dev/null 2>&1
        fi
    }

    add_geo_exclude() {
        if [ "$family" = "ip6tables" ]; then
            geo_set="geo_exclude6"
            override_set="geo_override6"
            ipset_family="inet6"
        else
            geo_set="geo_exclude"
            override_set="geo_override"
            ipset_family="inet"
        fi

        ipset create "$geo_set" hash:net family "$ipset_family" -exist
        ipset create "$override_set" hash:net family "$ipset_family" -exist

        ipt -I "$chain" 1 -m set --match-set "$geo_set" dst -m set ! --match-set "$override_set" dst $comment -j RETURN >/dev/null 2>&1
    }

    # Добавление правил iptables
    add_ipt_rule() {
        family="$1"
        table="$2"
        chain="$3"
        shift 3
        [ "$family" = "iptables" ] && [ "$iptables_supported" = "false" ] && return
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" = "false" ] && return

        # Custom chain создаётся/flush'ится одной строкой ":$name_chain -" в blob,
        # поэтому ни -nL guard, ни -N не нужны - всегда заполняем body.
        add_exclude_rules "$chain"

        if [ "$table" = "$table_tproxy" ]; then
            if [ "$mode_proxy" = "Hybrid" ]; then
                set -- -p udp -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark
            else
                set -- -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark
            fi
            ipt -I "$chain" 1 "$@" >/dev/null 2>&1
        fi

        case "$mode_proxy" in
            Hybrid)
                if [ "$table" = "$table_redirect" ]; then
                    ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                    add_ipset_exclude ext_exclude hash:ip
                    add_ipset_exclude user_exclude hash:net
                    add_geo_exclude
                    ipt -A "$chain" -p tcp $comment -j REDIRECT --to-port "$port_redirect" >/dev/null 2>&1
                else
                    ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                    ipt -I "$chain" 1 -m conntrack --ctstate INVALID $comment -j RETURN >/dev/null 2>&1
                    add_ipset_exclude ext_exclude hash:ip
                    add_ipset_exclude user_exclude hash:net
                    add_geo_exclude
                    ipt -A "$chain" -p udp -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                    ipt -A "$chain" -p udp -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                    ipt -A "$chain" -p udp $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
                fi
                ;;
            TProxy)
                ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                ipt -I "$chain" 1 -m conntrack --ctstate INVALID $comment -j RETURN >/dev/null 2>&1
                add_ipset_exclude ext_exclude hash:ip
                add_ipset_exclude user_exclude hash:net
                add_geo_exclude
                for net in $network_tproxy; do
                    ipt -A "$chain" -p "$net" -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                    ipt -A "$chain" -p "$net" -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                    ipt -A "$chain" -p "$net" $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
                done
                ;;
            Redirect)
                ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                add_ipset_exclude ext_exclude hash:ip
                add_ipset_exclude user_exclude hash:net
                add_geo_exclude
                for net in $network_redirect; do
                    ipt -A "$chain" -p "$net" $comment -j REDIRECT --to-port "$port_redirect" >/dev/null 2>&1
                done
                ;;
            *) exit 0 ;;
        esac

        if [ -n "$dscp_exclude" ]; then
            for dscp in $dscp_exclude; do
                ipt -I "$chain" -m dscp --dscp "$dscp" $comment -j RETURN >/dev/null 2>&1
            done
        fi

        # DSCP force-proxy обрабатывается отдельной chain'ой xkeen_force в
        # dedicated PREROUTING path'е соответствующей таблицы. Если не выйти
        # здесь из обычной chain для тех же протоколов, пакет позже попадёт в
        # штатный REDIRECT/TPROXY path и потеряет original dst.
        if [ "$table" = "$table_redirect" ] && [ -n "$port_dscp_force_proxy_redirect" ] && [ -n "$dscp_force_proxy" ]; then
            for net in $network_dscp_force_proxy_redirect; do
                ipt -I "$chain" 1 -p "$net" -m dscp --dscp "$dscp_force_proxy" $comment -j RETURN >/dev/null 2>&1
            done
        fi

        if [ "$table" = "$table_tproxy" ] && [ -n "$port_dscp_force_proxy_tproxy" ] && [ -n "$dscp_force_proxy" ]; then
            for net in $network_dscp_force_proxy_tproxy; do
                ipt -I "$chain" 1 -p "$net" -m dscp --dscp "$dscp_force_proxy" $comment -j RETURN >/dev/null 2>&1
            done
        fi
    }

    add_force_ipt_rule() {
        family="$1"
        table="$2"
        chain="$3"

        [ "$family" = "iptables" ] && [ "$iptables_supported" = "false" ] && return
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" = "false" ] && return

        if [ "$table" = "$table_redirect" ]; then
            [ -n "$port_dscp_force_proxy_redirect" ] || return
        elif [ "$table" = "$table_tproxy" ]; then
            [ -n "$port_dscp_force_proxy_tproxy" ] || return
        else
            return
        fi

        add_exclude_rules "$chain"

        ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
        ipt -I "$chain" 1 -m conntrack --ctstate INVALID $comment -j RETURN >/dev/null 2>&1

        if [ "$table" = "$table_redirect" ]; then
            for net in $network_dscp_force_proxy_redirect; do
                ipt -A "$chain" -p "$net" $comment -j REDIRECT --to-port "$port_dscp_force_proxy_redirect" >/dev/null 2>&1
            done
        else
            ipt -I "$chain" 1 -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark >/dev/null 2>&1
            for net in $network_dscp_force_proxy_tproxy; do
                ipt -A "$chain" -p "$net" -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                ipt -A "$chain" -p "$net" -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                ipt -A "$chain" -p "$net" $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_dscp_force_proxy_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
            done
        fi

        # Расскомментируйте блок если необходимо
        # учитывать DSCP 62 в политике xkeen_full
        # if [ -n "$dscp_exclude" ]; then
            # for dscp in $dscp_exclude; do
                # ipt -I "$chain" -m dscp --dscp "$dscp" $comment -j RETURN
            # done
        # fi
    }

    # Настройка таблицы маршрутов
    configure_route() {
        ip_version="$1"

        # Определяем таблицу маршрутизации
        if [ -n "$policy_mark" ]; then
            policy_table=$(ip rule show | awk -v policy="$policy_mark" '$0 ~ policy && /lookup/ && !/blackhole/ {print $(NF); exit}')
        fi
        source_table="${policy_table:-main}"

        # Проверяем есть ли default маршрут
        check_default() {
            if [ "$ip_version" = "6" ] && ! ip -6 route show default 2>/dev/null | grep -q .; then
                return 0
            fi
            if [ "$source_table" = "main" ]; then
                ip -"$ip_version" route show default 2>/dev/null | grep -q '^default'
            else
                ip -"$ip_version" route show table "$policy_table" 2>/dev/null | grep -E '^default ' | grep -vq 'unreachable'
            fi
        }

        attempts=0
        max_attempts=4
        until check_default; do
            attempts=$((attempts + 1))
            if [ "$attempts" -ge "$max_attempts" ]; then
                [ "$ip_version" = "4" ] && touch "/tmp/noinet"
                return 1
            fi
            sleep 1
        done
        [ "$ip_version" = "4" ] && rm -f "/tmp/noinet"

        # NDM при netfilter rewrite (в т.ч. на каждый DHCP renew) не трогает
        # ни ip rule, ни table $table_id — безусловный flush ниже рвал
        # установленные TProxy-потоки без причины. Если целевое состояние
        # (local default + копия non-default маршрутов source_table + fwmark
        # rule) уже действует — не трогаем. Любое расхождение -> полная
        # пересборка, как раньше.
        _cur_routes=$(ip -"$ip_version" route show table "$table_id" 2>/dev/null)
        _want_routes=$(ip -"$ip_version" route show table "$source_table" 2>/dev/null | \
            grep -v '^default\|^unreachable\|^blackhole')
        if [ -n "$_cur_routes" ] && \
           printf '%s\n' "$_cur_routes" | grep -q '^local default dev lo' && \
           [ "$(printf '%s\n' "$_cur_routes" | grep -v '^local default dev lo' | sort)" = \
             "$(printf '%s\n' "$_want_routes" | sort)" ] && \
           ip -"$ip_version" rule show 2>/dev/null | grep -q "fwmark $table_mark lookup $table_id"; then
            return 0
        fi

        ip -"$ip_version" rule del fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" route flush table "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" route add local default dev lo table "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" rule add fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1 || true

        # Копируем маршруты
        ip -"$ip_version" route show table "$source_table" 2>/dev/null | while read -r route_line; do
            case "$route_line" in
                default*|unreachable*|blackhole*) continue ;;
                *) ip -"$ip_version" route add table "$table_id" $route_line >/dev/null 2>&1 || true ;;
            esac
        done
        return 0
    }

    # Создание множественных правил multiport
    add_multiport_rules() {
        family="$1"
        table="$2"
        net="$3"
        mark="$4"
        ports="$5"
        target="$6"

        [ -z "$ports" ] && return

        remaining="$ports"
        while [ -n "$remaining" ]; do
            chunk=""
            chunk_len=0
            while [ "$chunk_len" -lt 7 ] && [ -n "$remaining" ]; do
                port="${remaining%%,*}"
                case "$remaining" in
                    *,*) remaining="${remaining#*,}" ;;
                    *) remaining="" ;;
                esac
                chunk="${chunk:+$chunk,}$port"
                chunk_len=$((chunk_len + 1))
            done
            [ -z "$chunk" ] && break
            if [ -n "$mark" ]; then
                set -- -m connmark --mark "$mark" -m conntrack ! --ctstate INVALID -p "$net" -m multiport --dports "$chunk" $comment -j "$target"
            else
                set -- -m conntrack ! --ctstate INVALID -p "$net" -m multiport --dports "$chunk" $comment -j "$target"
            fi
            ipt -A PREROUTING "$@" >/dev/null 2>&1
        done
    }

    # Добавление цепочек PREROUTING
    add_prerouting() {
        family="$1"
        table="$2"

        # MAC-bypass для built-in «Без доступа в интернет»: RETURN из PREROUTING
        # до xkeen-jumps, пакет минует TPROXY/REDIRECT/MARK и попадает в FORWARD,
        # где NDM-цепочка _NDM_HOTSPOT_FWD его дропнет штатно. -m mac --mac-source
        # видит L2-MAC только для устройств в одном broadcast-домене с роутером
        # (LAN/Wi-Fi/guest-bridge); за L3-VLAN правило безвредно неактивно.
        ipt -I PREROUTING 1 -m set --match-set "$name_ipset_deny_mac" src $comment -j RETURN >/dev/null 2>&1

        if _xkeen_use_divert "$table"; then
            divert_chain="${name_chain}_divert"
            ipt -A "$divert_chain" $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
            ipt -A "$divert_chain" $comment -j ACCEPT >/dev/null 2>&1
            ipt -A PREROUTING -p tcp -m socket --transparent $comment -j "$divert_chain" >/dev/null 2>&1
        fi

        if [ "$table" = "$table_redirect" ] && [ -n "$port_dscp_force_proxy_redirect" ] && [ -n "$dscp_force_proxy" ]; then
            for force_net in $network_dscp_force_proxy_redirect; do
                set -- -m conntrack ! --ctstate INVALID -p "$force_net" -m dscp --dscp "$dscp_force_proxy" $comment -j "${name_chain}_force"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done
        fi

        if [ "$table" = "$table_tproxy" ] && [ -n "$port_dscp_force_proxy_tproxy" ] && [ -n "$dscp_force_proxy" ]; then
            for force_net in $network_dscp_force_proxy_tproxy; do
                set -- -m conntrack ! --ctstate INVALID -p "$force_net" -m dscp --dscp "$dscp_force_proxy" $comment -j "${name_chain}_force"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done
        fi

        for net in $networks; do
            if [ "$mode_proxy" = "Hybrid" ]; then
                [ "$table" = "nat"    ] && [ "$net" != "tcp" ] && continue
                [ "$table" = "mangle" ] && [ "$net" != "udp" ] && continue
            fi

            proto_match="-p $net"
            all_ports_proto_match=""
            [ "$mode_proxy" = "TProxy" ] && all_ports_proto_match="$proto_match"

            for dscp in $dscp_proxy; do
                set -- -m conntrack ! --ctstate INVALID $proto_match -m dscp --dscp "$dscp" $comment -j "$name_chain"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done

            if [ "$proxy_router" = "on" ]; then
                set -- -i lo -m mark --mark "$table_mark" $proto_match $comment -j "$name_chain"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            fi

            # Пользовательские политики из xkeen.json
            # Heredoc вместо echo|while - while должен исполниться в parent shell,
            # чтобы аккумуляторы _xkeen_*_rules в ipt() модифицировались в нужном scope.
            while IFS='|' read -r pname pmark pmode pports; do
                [ -z "$pmark" ] && continue

                pmark=$(echo "$pmark" | tr -d ' \r\n')
                pmode=$(echo "$pmode" | tr -d ' \r\n')
                pports=$(echo "$pports" | tr -d ' \r\n')

                if [ "$pmode" = "all" ]; then
                    set -- -m connmark --mark 0x"$pmark" -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                elif [ "$pmode" = "include" ]; then
                    add_multiport_rules "$family" "$table" "$net" "0x$pmark" "$pports" "$name_chain"
                elif [ "$pmode" = "exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "0x$pmark" "$pports" "RETURN"
                    set -- -m connmark --mark 0x"$pmark" -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            done <<USER_POLICIES_EOF
$user_policies
USER_POLICIES_EOF

            # Политика xkeen_full (принудительное проксирование)
            if [ -n "$policy_mark_full" ]; then
                set -- -m connmark --mark "$policy_mark_full" -m conntrack ! --ctstate INVALID -p "$net" $comment -j "${name_chain}_force"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            fi

            # Политика xkeen (стандартная)
            if [ -n "$policy_mark" ]; then
                # заданы порты проксирования
                if [ -n "$port_donor" ]; then
                    add_multiport_rules "$family" "$table" "$net" "$policy_mark" "$port_donor" "$name_chain"
                # заданы порты исключения
                elif [ -n "$port_exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "$policy_mark" "$port_exclude" "RETURN"
                    set -- -m connmark --mark "$policy_mark" -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                else
                    # Политика xkeen, когда порты не указаны (проксирование на всех портах)
                    set -- -m connmark --mark "$policy_mark" -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            # НЕТ политики xkeen
            else
                # заданы порты проксирования
                if [ -n "$port_donor" ]; then
                    add_multiport_rules "$family" "$table" "$net" "" "$port_donor" "$name_chain"
                # заданы порты исключения
                elif [ -n "$port_exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "" "$port_exclude" "RETURN"
                    set -- -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                # Если нет ни xkeen, ни пользовательских политик -> перехватываем всё
                else
                    set -- -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            fi
        done
    }

    # Добавление цепочек для проксирования трафика Entware
    add_output() {
        family="$1"
        table="$2"

        [ "$proxy_router" != "on" ] && return

        out_chain="${name_chain}_out"

        # ":${name_chain}_out -" в blob создаст/flush'ит chain атомарно,
        # body заполняется всегда.
        orig_chain="$chain"
        chain="$out_chain"

        # Разрешаем traceroute 
        ipt -A "$out_chain" -p udp --dport 33434:33534 $comment -j RETURN >/dev/null 2>&1

        ipt -A "$out_chain" -o lo $comment -j RETURN >/dev/null 2>&1
        ipt -A "$out_chain" -m mark --mark 255 $comment -j RETURN >/dev/null 2>&1
        policy_bypass_marks="$policy_mark"

        if [ -n "$user_policies" ]; then
            user_policy_marks=$(printf '%s\n' "$user_policies" | awk -F'|' '$2 != "" {print "0x"$2}')
            policy_bypass_marks="$policy_bypass_marks $user_policy_marks"
        fi

        for bypass_mark in $policy_bypass_marks; do
            [ -n "$bypass_mark" ] && ipt -A "$out_chain" -m mark --mark "$bypass_mark" $comment -j RETURN >/dev/null 2>&1
        done

        for nfqws_bypass_mark in $nfqws_mark; do
            [ -n "$nfqws_bypass_mark" ] || continue
            case "$nfqws_bypass_mark" in
                */*) ;;
                *) nfqws_bypass_mark="$nfqws_bypass_mark/$nfqws_bypass_mark" ;;
            esac
            ipt -A "$out_chain" -m mark --mark "$nfqws_bypass_mark" $comment -j RETURN >/dev/null 2>&1
        done

        add_exclude_rules "$out_chain"

        add_ipset_exclude ext_exclude hash:ip
        add_ipset_exclude user_exclude hash:net
        add_geo_exclude

        chain="$orig_chain"

        for net in $networks; do
            if [ "$mode_proxy" = "Hybrid" ]; then
                [ "$table" = "nat"    ] && [ "$net" != "tcp" ] && continue
                [ "$table" = "mangle" ] && [ "$net" != "udp" ] && continue
            fi

            proto_match="-p $net"

            set -- -m conntrack ! --ctstate INVALID $proto_match $comment -j "$out_chain"
            ipt -A OUTPUT "$@" >/dev/null 2>&1

            if [ "$table" = "$table_redirect" ]; then
                set -- -p "$net" $comment -j REDIRECT --to-port "$port_redirect"
                ipt -A "$out_chain" "$@" >/dev/null 2>&1
            elif [ "$table" = "$table_tproxy" ]; then
                set -- -p "$net" $comment -j MARK --set-mark "$table_mark"
                ipt -A "$out_chain" "$@" >/dev/null 2>&1
            fi
        done
    }

    dns_redir() {
        family="$1"
        table="nat"

        [ "$aghfix" != "on" ] && return
        [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && return

        all_marks=""
        [ -n "$policy_mark" ] && all_marks="$policy_mark"
        [ -n "$policy_mark_full" ] && all_marks="$policy_mark_full $all_marks"
        [ -n "$custom_mark" ] && all_marks="$custom_mark $all_marks"

        if [ -n "$user_policies" ]; then
            user_marks=$(echo "$user_policies" | awk -F'|' '{if ($2 != "") print "0x"$2}')
            all_marks="$all_marks $user_marks"
        fi

        for mark in $all_marks; do
            mark=$(echo "$mark" | tr -d ' \r\n')
            [ -z "$mark" ] && continue

            for proto in udp tcp; do
                set -- -p "$proto" -m mark --mark "$mark" -m pkttype --pkt-type unicast -m "$proto" --dport 53 $comment -j REDIRECT --to-ports 53
                ipt -I _NDM_HOTSPOT_DNSREDIR "$@" >/dev/null 2>&1
            done
        done
    }

    # Лёгкий путь. NDM зовёт netfilter.d на каждую пересобранную (type, table)
    # пару, schedule.d дёргает хук ради deny-MAC ipset — в этих вызовах наши
    # правила часто уже на месте. Если все xkeen-цепочки и tagged-правила
    # уцелели, полная пересборка не нужна: только идемпотентные маршруты и
    # ре-синхронизация deny-MAC. Любое сомнение -> полная пересборка.
    _xkeen_hook_tables=""
    [ -n "$port_tproxy" ] && _xkeen_hook_tables="$table_tproxy"
    [ -n "$port_redirect" ] && [ "$table_redirect" != "$table_tproxy" ] && \
        _xkeen_hook_tables="$_xkeen_hook_tables $table_redirect"

    _xkeen_family_intact() {
        _bin="$1"
        for _tbl in $_xkeen_hook_tables; do
            [ "$("$_bin" -w -t "$_tbl" -S "$name_chain" 2>/dev/null | wc -l)" -gt 1 ] || return 1
            "$_bin" -w -t "$_tbl" -S PREROUTING 2>/dev/null | grep -q "$comment_tag" || return 1
            if [ "$proxy_router" = "on" ]; then
                "$_bin" -w -t "$_tbl" -S OUTPUT 2>/dev/null | grep -q "$comment_tag" || return 1
            fi
        done
        if [ "$aghfix" = "on" ] && ! { [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ]; }; then
            "$_bin" -w -t nat -S _NDM_HOTSPOT_DNSREDIR 2>/dev/null | grep -q "$comment_tag" || return 1
        fi
        return 0
    }

    # Этот fast-path сокращает только время выполнения ниже по коду —
    # к моменту вызова ash уже полностью разобрал весь if/fi выше
    # (см. комментарий у открывающего `if pidof`), включая ~700 строк
    # full-rebuild-функций, определённых раньше этой точки.
    _xkeen_rules_intact() {
        [ -n "$_xkeen_hook_tables" ] || return 1
        if [ "$iptables_supported" = "true" ]; then
            _xkeen_family_intact iptables || return 1
        fi
        if [ "$ip6tables_supported" = "true" ]; then
            _xkeen_family_intact ip6tables || return 1
        fi
        return 0
    }

    # OOM can leave an existing geo set empty even though its list is valid.
    # Refill only the broken state, keeping ordinary renews inexpensive.
    _xkeen_refill_geo_if_empty() {
        _rg_set="$1"
        _rg_file="$2"
        _rg_family="$3"
        [ -s "$_rg_file" ] || return 0
        ipset save "$_rg_set" 2>/dev/null | grep -q '^add ' && return 0
        _rg_tmp="${_rg_set}_renew_tmp"
        ipset create "$_rg_tmp" hash:net family "$_rg_family" -exist 2>/dev/null || return 1
        ipset flush "$_rg_tmp" 2>/dev/null
        if sed -e 's/\r$//' -e 's/#.*//' -e '/^[[:space:]]*$/d' "$_rg_file" | \
             awk '{print "add '"$_rg_tmp"' "$1}' | ipset restore -exist; then
            ipset swap "$_rg_set" "$_rg_tmp" 2>/dev/null || return 1
        else
            logger -p warning -t XKeen "Не удалось восстановить $_rg_set из $_rg_file"
        fi
        ipset destroy "$_rg_tmp" 2>/dev/null
    }

    # Текущий WAN IPv4 (тот же способ, что get_exclude_ip4 при генерации).
    # На коротком DHCP lease (MGTS ~300 с) renew приходит каждые ~150 с
    # с тем же IP: NDM всё равно зовёт netfilter.d. Если IP не сменился
    # и цепочки на месте — не трогаем даже configure_route (он и так
    # идемпотентен, но лишние ip route show на каждом renew не нужны).
    _xkeen_wan_state="$_xkeen_rundir/wan_ip"
    _xkeen_cur_wan=$(ip -o route get 77.88.8.8 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p')
    _xkeen_prev_wan=$(cat "$_xkeen_wan_state" 2>/dev/null)

    if [ -n "$_xkeen_cur_wan" ] && [ "$_xkeen_cur_wan" = "$_xkeen_prev_wan" ] && _xkeen_rules_intact; then
        # IP тот же, цепочки целы: deny-MAC обновляет schedule.d —
        # здесь curl под lock только мешает соседним событиям NDM.
        [ "$iptables_supported" = "true" ] && _xkeen_refill_geo_if_empty geo_exclude "$ru_exclude_ipv4" inet
        [ "$ip6tables_supported" = "true" ] && _xkeen_refill_geo_if_empty geo_exclude6 "$ru_exclude_ipv6" inet6
        _xkeen_release_nf_lock
        exit 0
    fi

    if _xkeen_rules_intact; then
        [ "$iptables_supported" = "true" ] && configure_route 4
        [ "$ip6tables_supported" = "true" ] && configure_route 6
        [ -n "$_xkeen_cur_wan" ] && printf '%s' "$_xkeen_cur_wan" > "$_xkeen_wan_state"
        _xkeen_release_nf_lock
        _xkeen_sync_deny_mac_ipset
        exit 0
    fi

    # Кэш готовых restore-блобов. Набор правил полностью детерминирован
    # конфигурацией, запечённой в этот файл при генерации, — на каждом
    # прогоне пересобирать его сотнями shell-вызовов незачем. После полной
    # сборки блобы сохраняются в /tmp с ключом = md5 самого хука: любое
    # изменение конфигурации перегенерирует хук и инвалидирует кэш,
    # перезагрузка очищает /tmp. При попадании в кэш хук сразу применяет
    # блобы — окно «NDM снёс цепочки, правил нет» сокращается до
    # длительности самих iptables-restore.
    _xkeen_cache_dir="$_xkeen_rundir/rules_cache"

    _xkeen_ensure_ipsets() {
        command -v ipset >/dev/null 2>&1 || return 0
        if [ "$iptables_supported" = "true" ]; then
            ipset create ext_exclude hash:ip family inet -exist 2>/dev/null
            ipset create user_exclude hash:net family inet -exist 2>/dev/null
            ipset create geo_exclude hash:net family inet -exist 2>/dev/null
            ipset create geo_override hash:net family inet -exist 2>/dev/null
        fi
        if [ "$ip6tables_supported" = "true" ]; then
            ipset create ext_exclude6 hash:ip family inet6 -exist 2>/dev/null
            ipset create user_exclude6 hash:net family inet6 -exist 2>/dev/null
            ipset create geo_exclude6 hash:net family inet6 -exist 2>/dev/null
            ipset create geo_override6 hash:net family inet6 -exist 2>/dev/null
        fi
    }

    _xkeen_cache_valid() {
        [ -s "$_xkeen_cache_dir/key" ] || return 1
        [ "$(cat "$_xkeen_cache_dir/key" 2>/dev/null)" = "$(md5sum "$0" 2>/dev/null | awk '{print $1}')" ]
    }

    # Восстанавливает хвостовой перевод строки, съеденный $(cat ...):
    # _xkeen_apply_table печатает блоб через printf '%s' и рассчитывает,
    # что каждая строка правил завершена.
    _xkeen_cache_load() {
        for _cn in v4_nat v4_mangle v6_nat v6_mangle; do
            _cb=$(cat "$_xkeen_cache_dir/$_cn" 2>/dev/null)
            [ -n "$_cb" ] || continue
            case "$_cn" in
                v4_nat) _xkeen_v4_nat_rules="$_cb
" ;;
                v4_mangle) _xkeen_v4_mangle_rules="$_cb
" ;;
                v6_nat) _xkeen_v6_nat_rules="$_cb
" ;;
                v6_mangle) _xkeen_v6_mangle_rules="$_cb
" ;;
            esac
        done
    }

    _xkeen_cache_save() {
        rm -rf "${_xkeen_cache_dir}.new" 2>/dev/null
        mkdir -p "${_xkeen_cache_dir}.new" 2>/dev/null || return 0
        printf '%s' "$_xkeen_v4_nat_rules"    > "${_xkeen_cache_dir}.new/v4_nat"
        printf '%s' "$_xkeen_v4_mangle_rules" > "${_xkeen_cache_dir}.new/v4_mangle"
        printf '%s' "$_xkeen_v6_nat_rules"    > "${_xkeen_cache_dir}.new/v6_nat"
        printf '%s' "$_xkeen_v6_mangle_rules" > "${_xkeen_cache_dir}.new/v6_mangle"
        md5sum "$0" 2>/dev/null | awk '{print $1}' > "${_xkeen_cache_dir}.new/key"
        rm -rf "${_xkeen_cache_dir}.old" 2>/dev/null
        [ -d "$_xkeen_cache_dir" ] && mv "$_xkeen_cache_dir" "${_xkeen_cache_dir}.old" 2>/dev/null
        if mv "${_xkeen_cache_dir}.new" "$_xkeen_cache_dir" 2>/dev/null; then
            rm -rf "${_xkeen_cache_dir}.old" 2>/dev/null
        else
            [ -d "${_xkeen_cache_dir}.old" ] && mv "${_xkeen_cache_dir}.old" "$_xkeen_cache_dir" 2>/dev/null
        fi
    }

    if _xkeen_cache_valid; then
        _xkeen_ensure_ipsets
        [ "$iptables_supported" = "true" ] && _xkeen_refill_geo_if_empty geo_exclude "$ru_exclude_ipv4" inet
        [ "$ip6tables_supported" = "true" ] && _xkeen_refill_geo_if_empty geo_exclude6 "$ru_exclude_ipv6" inet6
        _xkeen_cache_load
        [ "$iptables_supported" = "true" ] && configure_route 4
        [ "$ip6tables_supported" = "true" ] && configure_route 6
        _xkeen_apply
        [ -n "$_xkeen_cur_wan" ] && printf '%s' "$_xkeen_cur_wan" > "$_xkeen_wan_state"
        _xkeen_release_nf_lock
        _xkeen_flush_udp_conntrack
        _xkeen_sync_deny_mac_ipset
        exit 0
    fi

    if [ -n "$port_donor" ] || [ -n "$port_exclude" ]; then
        [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && [ -n "$port_donor" ] && port_donor="53,$port_donor"
    fi
    for family in iptables ip6tables; do

        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && continue
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && continue

        if [ "$family" = "ip6tables" ]; then
            exclude_list="$val_exclude_ip6"
            proxy_ip="$ipv6_proxy"
            configure_route 6
        else
            exclude_list="$val_exclude_ip4"
            proxy_ip="$ipv4_proxy"
            configure_route 4
        fi
        if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            for table in "$table_tproxy" "$table_redirect"; do
                add_ipt_rule "$family" "$table" "$name_chain"
                add_force_ipt_rule "$family" "$table" "${name_chain}_force"
                add_prerouting "$family" "$table"
                add_output "$family" "$table"
            done
        elif [ -z "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            table="$table_tproxy"
            add_ipt_rule "$family" "$table" "$name_chain"
            add_force_ipt_rule "$family" "$table" "${name_chain}_force"
            add_prerouting "$family" "$table"
            add_output "$family" "$table"
        elif [ -n "$port_redirect" ] && [ -z "$port_tproxy" ]; then
            table="$table_redirect"
            add_ipt_rule "$family" "$table" "$name_chain"
            add_prerouting "$family" "$table"
            add_output "$family" "$table"
        fi

        dns_redir "$family"
    done

    # Атомарно применяем все аккумулированные правила одним
    # iptables-restore --noflush per (family, table).
    _xkeen_apply

    # Блобы детерминированы конфигурацией — сохраняем для быстрых
    # последующих прогонов (см. _xkeen_cache_* выше).
    _xkeen_cache_save

    # Медленная часть (curl к hotspot API) — строго после восстановления
    # правил и после снятия nf-lock: см. комментарий у _xkeen_sync_deny_mac_ipset.
    [ -n "$_xkeen_cur_wan" ] && printf '%s' "$_xkeen_cur_wan" > "$_xkeen_wan_state"
    _xkeen_release_nf_lock
    _xkeen_flush_udp_conntrack
    _xkeen_sync_deny_mac_ipset
else
    # mkdir-lock с PID: обычный touch-файл залипал навсегда после OOM
    # посреди respawn mihomo из хука — следующие события NDM тихо no-op.
    _xkeen_start_lock="$_xkeen_rundir/starting.lock.d"
    if ! mkdir "$_xkeen_start_lock" 2>/dev/null; then
        _sl_pid=$(cat "$_xkeen_start_lock/pid" 2>/dev/null)
        if [ -n "$_sl_pid" ] && kill -0 "$_sl_pid" 2>/dev/null; then
            exit 0
        fi
        rm -rf "$_xkeen_start_lock" 2>/dev/null
        mkdir "$_xkeen_start_lock" 2>/dev/null || exit 0
    fi
    printf '%s' "$$" > "$_xkeen_start_lock/pid"
    trap 'rm -rf "$_xkeen_start_lock"' EXIT INT TERM

    fd_limit="$other_fd"
    [ "$arm_cpu" = "true" ] && fd_limit="$arm64_fd"
    ulimit -SHn "$fd_limit"

    export SSL_CERT_FILE="$file_ca"
    case "$name_client" in
        xray)
            export XRAY_LOCATION_CONFDIR="$directory_xray_config"
            export XRAY_LOCATION_ASSET="$directory_xray_asset"
            "$name_client" run >/dev/null 2>&1 &
        ;;
        mihomo)
            export CLASH_HOME_DIR="$directory_configs_app"
            # Мягкий лимит памяти для Go GC. Значение запекается при
            # configure_firewall из xkeen.json (gomemlimit_percent /
            # gomemlimit_mb) или внешнего GOMEMLIMIT.
            if [ -z "$GOMEMLIMIT" ] && [ -n "$gomemlimit_value" ]; then
                export GOMEMLIMIT="$gomemlimit_value"
            fi
            "$name_client" >/dev/null 2>&1 &
        ;;
    esac
    _probe=0
    while [ "$_probe" -lt 60 ]; do
        pidof "$name_client" >/dev/null 2>&1 && break
        _probe=$((_probe + 1))
        usleep 100000
    done
    unset _probe
    rm -rf "$_xkeen_start_lock"
    trap - EXIT INT TERM
    if pidof "$name_client" >/dev/null; then
        restart_script "$@"
    else
        exit 1
    fi
fi
EOL
    sed -i '1,2!{/^[[:space:]]*#/d; /^[[:space:]]*$/d}' "$file_netfilter_hook"
    chmod 700 "$file_netfilter_hook"
    # Пропускаем перезапись, если итоговое содержимое не отличается от live:
    # экономим запись на flash при повторных S05xkeen start от NDM.
    if [ -f "$_hook_live" ] && [ "$(cat "$file_netfilter_hook")" = "$(cat "$_hook_live")" ]; then
        rm -f "$file_netfilter_hook"
    else
        mv -f "$file_netfilter_hook" "$_hook_live" || {
            rm -f "$file_netfilter_hook"
            file_netfilter_hook="$_hook_live"
            log_error_router "Не удалось атомарно обновить netfilter-хук"
            return 1
        }
    fi
    file_netfilter_hook="$_hook_live"

    # Schedule.d-хук: NDM вызывает scripts/schedule.d при start/stop расписаний
    # (родительский контроль). Хук дёргает netfilter.d/proxy.sh, который
    # ре-синхронизирует ipset deny-MAC из актуального hotspot API.
    # Тот же tmp+сравнение+atomic-mv паттерн, что и у proxy.sh выше: heredoc
    # статичен, но голый exists-check "застынет" на старом содержимом после
    # апгрейда XKeen, поэтому сравниваем содержимое, а не факт наличия файла.
    mkdir -p "$(dirname "$file_schedule_hook")" 2>/dev/null
    _schedule_hook_tmp="${file_schedule_hook}.tmp.$$"
    rm -f "$_schedule_hook_tmp"
    cat > "$_schedule_hook_tmp" <<'SCHEDULE_EOL'
#!/bin/sh
# XKeen: re-sync deny MAC ipset on schedule start/stop. Auto-generated. DO NOT EDIT!
[ "$1" = "start" ] || [ "$1" = "stop" ] || exit 0
[ -x /opt/etc/ndm/netfilter.d/proxy.sh ] && /opt/etc/ndm/netfilter.d/proxy.sh
SCHEDULE_EOL
    if [ -f "$file_schedule_hook" ] && [ "$(cat "$_schedule_hook_tmp")" = "$(cat "$file_schedule_hook")" ]; then
        rm -f "$_schedule_hook_tmp"
    else
        chmod 755 "$_schedule_hook_tmp"
        mv -f "$_schedule_hook_tmp" "$file_schedule_hook"
    fi

    return 0
}

# Удаление правил iptables
clean_firewall() {
    _acquire_nf_lock
    _cf_nf_rc=$?

    # Атомарно гасим хук: truncate live mid-renew больше не оставляем.
    if [ -f "$file_netfilter_hook" ] || [ -e "$file_netfilter_hook" ]; then
        _cf_hook_tmp="${file_netfilter_hook}.clean.$$"
        : > "$_cf_hook_tmp"
        mv -f "$_cf_hook_tmp" "$file_netfilter_hook" 2>/dev/null || : > "$file_netfilter_hook"
    fi

    get_ipver_support

    for family in iptables ip6tables; do
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && continue
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && continue

        if "$family" -w -t nat -nL _NDM_HOTSPOT_DNSREDIR >/dev/null 2>&1; then
            "$family" -w -t nat -S _NDM_HOTSPOT_DNSREDIR | grep -E -- "$comment_tag" | sed 's/^-A /-D /' | while IFS= read -r rule; do
                [ -n "$rule" ] && "$family" -w -t nat $rule >/dev/null 2>&1
            done
        fi
    done

    clean_run() {
        family="$1"
        table="$2"
        name_chain="$3"

        for sys_chain in PREROUTING OUTPUT; do
            "$family" -w -t "$table" -S "$sys_chain" 2>/dev/null | grep -E -- "$comment_tag" | sed 's/^-A /-D /' | while IFS= read -r rule; do
                [ -n "$rule" ] && "$family" -w -t "$table" $rule >/dev/null 2>&1
            done
        done

        if "$family" -w -t "$table" -nL "$name_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$name_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$name_chain" >/dev/null 2>&1
        fi

        out_chain="${name_chain}_out"
        if "$family" -w -t "$table" -nL "$out_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$out_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$out_chain" >/dev/null 2>&1
        fi

        force_chain="${name_chain}_force"
        if "$family" -w -t "$table" -nL "$force_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$force_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$force_chain" >/dev/null 2>&1
        fi

        divert_chain="${name_chain}_divert"
        if "$family" -w -t "$table" -nL "$divert_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$divert_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$divert_chain" >/dev/null 2>&1
        fi

        killswitch_chain="${name_chain}_killswitch"
        if "$family" -w -t "$table" -nL "$killswitch_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$killswitch_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$killswitch_chain" >/dev/null 2>&1
        fi
    }

    for family in iptables ip6tables; do
        for chain in nat mangle; do
            clean_run "$family" "$chain" "$name_chain"
        done
    done

    if command -v ip >/dev/null 2>&1; then
        for family in 4 6; do
            while ip -"$family" rule del fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1; do :; done
            ip -"$family" route flush table "$table_id" >/dev/null 2>&1 || true
        done
    fi

    # Очистка и удаление списков ipset
    if command -v ipset >/dev/null 2>&1; then
        for set in geo_override geo_override6 geo_exclude geo_exclude6 user_exclude user_exclude6 "$name_ipset_deny_mac"; do
            ipset flush "$set" >/dev/null 2>&1
            ipset destroy "$set" >/dev/null 2>&1
        done
    fi

    # Schedule.d-hook идемпотентно перегенерируется в configure_firewall,
    # на остановке убираем чтобы NDM не дёргал мёртвый netfilter.d/proxy.sh.
    [ -f "$file_schedule_hook" ] && rm -f "$file_schedule_hook"

    # rc=2 — re-entrant (тот же PID уже держал lock), чужой замок не снимаем.
    [ "$_cf_nf_rc" -ne 2 ] && _release_nf_lock
}

# Мониторинг файловых дескрипторов
monitor_fd() {
    while true; do
        client_pid=$(pidof "$name_client" | awk '{print $1}')
        if [ -n "$client_pid" ] && [ -d "/proc/$client_pid/fd" ]; then
            limit=$(awk '/Max open files/ {print $4}' "/proc/$client_pid/limits")
            case "$limit" in
                ''|*[!0-9]*) ;;
                *)
                    set -- /proc/$client_pid/fd/*
                    [ -e "$1" ] || set --
                    current=$#
                    if [ "$limit" -gt 0 ] && [ "$current" -gt $((limit * 90 / 100)) ]; then
                        log_warning_router "$name_client открыл $current из $limit файловых дескрипторов, инициирован перезапуск"
                        rm -f "$file_pid_fd"
                        fd_out=true
                        proxy_stop
                        proxy_start "on"
                        exit 0
                    fi
                    ;;
            esac
        fi
        sleep "$delay_fd"
    done
}

load_ipset() {
    set="$1"
    file="$2"
    family="$3"
    tmp="${set}_tmp"

    # Тот же паттерн, что и в load_user_ipset_family
    if [ "$family" = "inet6" ]; then
        addr_regex='([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(/[0-9]{1,3})?'
    else
        addr_regex='([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?'
    fi

    # Заполняем tmp; основной набор подменяется только после успешного restore
    ipset create "$set" hash:net family "$family" -exist
    ipset create "$tmp" hash:net family "$family" -exist
    ipset flush "$tmp"

    if [ -f "$file" ] && sed -e 's/\r$//' -e 's/#.*//' -e '/^[[:space:]]*$/d' "$file" |
       grep -Eo "$addr_regex" |
       awk -v s="$tmp" '{print "add "s" "$1}' | ipset restore -exist; then
        ipset swap "$set" "$tmp"
    fi
    ipset destroy "$tmp"
}

cleanup_fd_monitor() {
    [ -f "$file_pid_fd" ] || return 0
    kill "$(cat "$file_pid_fd")" 2>/dev/null
    rm -f "$file_pid_fd"
}

missing_files_template='
  '"${light_blue}"'Отсутствуют исполняемые файлы:'"${reset}"'
  '"${yellow}"'%b'"${reset}"'

  '"${green}"'Возможные причины:'"${reset}"'
  • XKeen установлен во внутреннюю память и на ней недостаточно места
  • У файла отсутствуют права на выполнение

  '"${green}"'Рекомендуемые действия:'"${reset}"'
  • Переустановите XKeen на внешний накопитель
  • Скопируйте недостающий файл вручную и сделайте исполняемым
'

check_binary() {
    file="$1"
    path="$install_dir/$file"

    if [ ! -f "$path" ] || [ ! -x "$path" ]; then
        return 1
    fi

    check_cmd="version"
    [ "$file" = "xray" ] && check_cmd="version"
    [ "$file" = "yq" ] && check_cmd="--version"
    [ "$file" = "mihomo" ] && check_cmd="-v"

    if ! "$file" $check_cmd >/dev/null 2>&1; then
        log_error_router "Бинарный файл $file аварийно остановлен"
        log_error_terminal "
  Бинарный файл ${yellow}$file${reset} аварийно остановлен
  ${red}Файл повреждён или несовместим с процессором${reset} вашего роутера
  Установите другую версию ${yellow}$file${reset}
"
    fi

    return 0
}

info_health_binary() {
    missing_files=""

    add_to_missing() {
        file_name="$1"
        prefix="  - " 
        
        if [ -z "$missing_files" ]; then
            missing_files="${prefix}${yellow}${file_name}${reset}"
        else
            missing_files="${missing_files}\n  ${prefix}${yellow}${file_name}${reset}"
        fi
    }

    case "$name_client" in
        xray)
            if ! check_binary xray; then add_to_missing "xray"; fi
            ;;
       mihomo)
            for file in mihomo yq; do
                if ! check_binary "$file"; then add_to_missing "$file"; fi
            done
            ;;
        esac

    if [ -n "$missing_files" ]; then
        log_error_terminal "$(printf "$missing_files_template" "$missing_files")"
    fi
}

# Атомарный single-instance guard на cold_start. mkdir — POSIX-атомарен,
# единственный надёжный lock в busybox-ash без flock. Закрывает гонку
# повторного S05xkeen start от NDM (fs.d + init.d + reconnect-триггеры).
# Flag-файл xkeen_coldstart.lock сохранён для совместимости с условиями
# подавления логов в proxy_start/proxy_stop ("[ -f lock ] || log_info_router").
# PID владельца записывает _set_coldstart_pid после `nohup cold_start &` —
# текущий $$ это caller (S05xkeen start), который завершается сразу;
# проверка живости должна идти по PID фонового cold_start ($!).
_acquire_coldstart_guard() {
    if mkdir "$xkeen_rundir/coldstart.lock.d" 2>/dev/null; then
        printf '%s\n' "$$" > "$xkeen_rundir/coldstart.lock.d/pid"
        : > "$xkeen_rundir/coldstart.lock"
        return 0
    fi
    _gpid=$(cat "$xkeen_rundir/coldstart.lock.d/pid" 2>/dev/null)
    if [ -n "$_gpid" ] && kill -0 "$_gpid" 2>/dev/null; then
        return 1
    fi
    # PID is written together with mkdir.  A guard without it is stale, not a
    # permanent denial of service.
    # PID exists but its process died → reclaim stale guard.
    # Реcheck перед rm -rf: между чтением протухшего pid выше и этой строкой
    # другой процесс мог успеть сделать свой mkdir+printf — не сносим чужой
    # свежий lock.
    [ "$(cat "$xkeen_rundir/coldstart.lock.d/pid" 2>/dev/null)" = "$_gpid" ] || return 1
    rm -rf "$xkeen_rundir/coldstart.lock.d"
    mkdir "$xkeen_rundir/coldstart.lock.d" 2>/dev/null || return 1
    printf '%s\n' "$$" > "$xkeen_rundir/coldstart.lock.d/pid"
    : > "$xkeen_rundir/coldstart.lock"
    return 0
}

_set_coldstart_pid() {
    [ -d "$xkeen_rundir/coldstart.lock.d" ] || return 0
    printf '%s\n' "$1" > "$xkeen_rundir/coldstart.lock.d/pid"
}

_release_coldstart_guard() {
    _gpid=$(cat "$xkeen_rundir/coldstart.lock.d/pid" 2>/dev/null)
    [ -z "$_gpid" ] || [ "$_gpid" = "$$" ] || return 0
    rm -rf "$xkeen_rundir/coldstart.lock.d"
    rm -f "$xkeen_rundir/coldstart.lock"
}

# Защита от параллельного входа в proxy_start/proxy_stop из двух
# триггеров (cold_start vs xkeen -restart, два S05xkeen start
# подряд от NDM и т.п.). Второй конкурент тихо выходит.
# rc=0  — захватили; rc=1 — реальный конкурент; rc=2 — re-entrant
# (тот же процесс уже владеет mutex'ом, например proxy_start вложенно
# вызывает proxy_stop при TProxy 443-конфликте — не релизим).
_acquire_proxy_mutex() {
    if mkdir "$xkeen_rundir/proxy.mutex.d" 2>/dev/null; then
        printf '%s\n' "$$" > "$xkeen_rundir/proxy.mutex.d/pid"
        return 0
    fi
    _mpid=$(cat "$xkeen_rundir/proxy.mutex.d/pid" 2>/dev/null)
    if [ "$_mpid" = "$$" ]; then
        return 2
    fi
    if [ -n "$_mpid" ] && kill -0 "$_mpid" 2>/dev/null; then
        return 1
    fi
    # Реcheck перед rm -rf: между чтением протухшего pid выше и этой строкой
    # другой процесс мог успеть сделать свой mkdir+printf — не сносим чужой
    # свежий lock.
    [ "$(cat "$xkeen_rundir/proxy.mutex.d/pid" 2>/dev/null)" = "$_mpid" ] || return 1
    rm -rf "$xkeen_rundir/proxy.mutex.d"
    mkdir "$xkeen_rundir/proxy.mutex.d" 2>/dev/null || return 1
    printf '%s\n' "$$" > "$xkeen_rundir/proxy.mutex.d/pid"
    return 0
}

_release_proxy_mutex() {
    rm -rf "$xkeen_rundir/proxy.mutex.d"
}

# Тот же mkdir-lock, что у netfilter-хука. Нужен stop/emergency_clear,
# чтобы не сносить цепочки посреди iptables-restore на DHCP renew.
_acquire_nf_lock() {
    _xkeen_nf_lock="$xkeen_rundir/netfilter.lock.d"
    _xkeen_lock_owned=""
    _lock_try=0
    while [ "$_lock_try" -lt 50 ]; do
        if mkdir "$_xkeen_nf_lock" 2>/dev/null; then
            _xkeen_lock_owned=1
            printf '%s' "$$" > "$_xkeen_nf_lock/pid"
            return 0
        fi
        _lock_pid=$(cat "$_xkeen_nf_lock/pid" 2>/dev/null)
        if [ "$_lock_pid" = "$$" ]; then
            return 2
        fi
        if [ -n "$_lock_pid" ] && ! kill -0 "$_lock_pid" 2>/dev/null; then
            rm -rf "$_xkeen_nf_lock" 2>/dev/null
            continue
        fi
        _lock_try=$((_lock_try + 1))
        usleep 100000 2>/dev/null || sleep 1
    done
    # Stop/emergency важнее застрявшего хука: забираем замок силой.
    rm -rf "$_xkeen_nf_lock" 2>/dev/null
    if mkdir "$_xkeen_nf_lock" 2>/dev/null; then
        _xkeen_lock_owned=1
        printf '%s' "$$" > "$_xkeen_nf_lock/pid"
        return 0
    fi
    return 1
}

_release_nf_lock() {
    if [ "$_xkeen_lock_owned" = "1" ]; then
        rm -rf "$xkeen_rundir/netfilter.lock.d" 2>/dev/null
        _xkeen_lock_owned=""
    fi
}

# Install an explicit fail-closed policy only after an unintentional core
# failure.  Only traffic already selected by xkeen policy marks is dropped;
# LAN/management and all unmarked traffic remain untouched.  The restore blob
# is atomic and uses the same netfilter lock as normal cleanup.
enable_killswitch() {
    [ "$killswitch" = "on" ] || return 0
    _ks_marks="$policy_mark $policy_mark_full"
    if [ -n "$user_policies" ]; then
        _ks_user_marks=$(printf '%s\n' "$user_policies" | awk -F'|' '$2 != "" {print "0x"$2}')
        _ks_marks="$_ks_marks $_ks_user_marks"
    fi
    [ -n "$(printf '%s' "$_ks_marks" | tr -d ' ')" ] || {
        log_warning_router "Kill-switch не установлен: нет policy-mark для безопасной выборки трафика"
        return 1
    }

    _acquire_nf_lock || return 1
    for _ks_family in iptables ip6tables; do
        if [ "$_ks_family" = "iptables" ] && [ "$iptables_supported" != "true" ]; then continue; fi
        if [ "$_ks_family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ]; then continue; fi
        _ks_restore="${_ks_family}-restore"
        _ks_blob=$( {
            printf '*mangle\n'
            printf ':%s_killswitch -\n' "$name_chain"
            for _ks_mark in $_ks_marks; do
                [ -n "$_ks_mark" ] || continue
                printf '%s\n' "-A ${name_chain}_killswitch -m conntrack ! --ctstate INVALID -m mark --mark ${_ks_mark} $comment -j DROP"
            done
            printf '%s\n' "-A PREROUTING $comment -j ${name_chain}_killswitch"
            printf 'COMMIT\n'
        } )
        printf '%s' "$_ks_blob" | "$_ks_restore" --noflush || {
            _release_nf_lock
            return 1
        }
    done
    _release_nf_lock
    log_warning_router "Kill-switch включён: трафик политики xkeen заблокирован до явного stop/start"
}

# Очистка при аварийной остановке прокси-клиента
emergency_clear() {
    _acquire_proxy_mutex
    _ec_mutex_rc=$?
    # Идёт нормальный start/stop/restart — не сносим чужие правила.
    if [ "$_ec_mutex_rc" -eq 1 ]; then
        return 0
    fi
    rm -f "$xkeen_rundir/ready"
    _release_coldstart_guard
    cleanup_fd_monitor
    clean_firewall
    enable_killswitch
    if [ "$_ec_mutex_rc" -eq 0 ]; then
        _release_proxy_mutex
    fi
}

# Запуск прокси-клиента
proxy_start() {
    _acquire_proxy_mutex
    _ps_mutex_rc=$?
    if [ "$_ps_mutex_rc" -eq 1 ]; then
        _ps_wait=0
        while [ "$_ps_wait" -lt 5 ]; do
            sleep 1
            _acquire_proxy_mutex
            _ps_mutex_rc=$?
            [ "$_ps_mutex_rc" -ne 1 ] && break
            _ps_wait=$((_ps_wait + 1))
        done
        if [ "$_ps_mutex_rc" -eq 1 ]; then
            log_warning_terminal "Запуск занят другим процессом, повторите команду"
            return 1
        fi
    fi
    if [ "$_ps_mutex_rc" -eq 0 ]; then
        trap '_release_proxy_mutex; trap - INT TERM HUP' INT TERM HUP
    fi
    start_manual="$1"
    if [ "$start_manual" = "on" ] || [ "$start_auto" = "on" ]; then
        _invalidate_inbounds_cache
        _invalidate_mihomo_config_cache
        apply_ipv6_state
        get_ipver_support
        info_health_binary
        validate_xkeen_json
        check_policy_name_conflict
        check_xray_backups
        api_cache_init
        policy_mark=$(get_policy_mark "$name_policy")
        policy_mark_cache="$xkeen_cfg/.last_policy_mark"
        if [ -n "$policy_mark" ]; then
            _pm_tmp="${policy_mark_cache}.tmp.$$"
            (umask 077; printf '%s\n' "$policy_mark" > "$_pm_tmp") &&
                chmod 600 "$_pm_tmp" && mv -f "$_pm_tmp" "$policy_mark_cache"
        elif [ -n "$api_policy_json" ] && \
             printf '%s' "$api_policy_json" | jq -e 'type == "array" or type == "object"' >/dev/null 2>&1; then
            # RCI ответил корректно, но политики xkeen в ответе нет:
            # её удалили вручную. Кеш недействителен, режим "для всех клиентов".
            if [ -e "$policy_mark_cache" ]; then
                rm -f "$policy_mark_cache"
                log_info_router "Политика $name_policy отсутствует в RCI; кеш mark сброшен, прокси будет запущен для всех клиентов"
            fi
        elif [ -s "$policy_mark_cache" ]; then
            _cached_mark=$(cat "$policy_mark_cache" 2>/dev/null)
            case "$_cached_mark" in
                0x[0-9A-Fa-f]*) policy_mark="$_cached_mark"; log_warning_router "RCI не вернул mark xkeen; используется последний успешный mark" ;;
            esac
        else
            log_warning_router "RCI не вернул mark xkeen; без policy-mark будет применён явный режим проксирования всех"
        fi
        policy_mark_full=$(get_policy_mark "$name_policy_full")
        user_policies=$(resolve_user_policies)
        validate_entware_proxy_mark
        validate_pbr_routing_mark
        log_clean
        sync_deny_mac_ipset
        process_user_ports
        process_mark_var custom_mark
        process_mark_var nfqws_mark
        detect_architecture
        port_redirect=$(get_port_redirect)
        network_redirect=$(get_network_redirect)
        port_tproxy=$(get_port_tproxy)
        network_tproxy=$(get_network_tproxy)
        mode_proxy=$(get_mode_proxy)
        if [ "$mode_proxy" != "Other" ]; then

            if [ -n "$policy_mark" ]; then
                if [ -n "$user_policies" ]; then
                    print_policy_info "yes" "yes"
                else
                    print_policy_info "yes" "no"
                fi
            else
                raw_user_policies=$(get_user_policies)
                ignored_custom="no"

                if [ -n "$raw_user_policies" ]; then
                    ignored_custom="yes"
                fi

                print_policy_info "no" "no" "$ignored_custom"

                user_policies=""
            fi

            networks=$(printf '%s\n' $network_redirect $network_tproxy | tr ',' ' ' | tr -s ' ' '\n' | sort -u | tr '\n' ' ')
            networks=${networks% }

            if [ -n "$policy_mark" ] && [ -z "$port_donor" ]; then
                port_exclude=$(get_port_exclude)
            fi
            if ! proxy_status && { [ -n "$port_donor" ] || [ -n "$port_exclude" ] || [ "$mode_proxy" = "TProxy" ] || [ "$mode_proxy" = "Hybrid" ]; }; then
                get_modules
            fi
            configure_dscp_force_proxy
            if [ "$mode_proxy" = "TProxy" ]; then
                get_keenetic_port >/dev/null || {
                    proxy_stop
                    log_error_router "Порт 443 занят сервисами Keenetic. Запуск в режиме TProxy невозможен"
                    log_error_terminal "
  Необходимый для режима ${light_blue}TProxy${reset} ${red}443 порт занят${reset} сервисами Keenetic

  Освободите его на странице 'Пользователи и доступ' веб-интерфейса роутера
"
                }
            fi
        fi
        flush_warn_gap
        if proxy_status; then
            echo -e "  Прокси-клиент уже ${green}запущен${reset}"
            if [ "$mode_proxy" != "Other" ] && ! configure_firewall; then
                rm -f "$xkeen_rundir/ready"
                log_error_terminal "Не удалось записать netfilter-хук"
                _release_coldstart_guard
                if [ "$_ps_mutex_rc" -eq 0 ]; then
                    _release_proxy_mutex
                    trap - INT TERM HUP
                fi
                return 1
            fi
            : > "$xkeen_rundir/ready"
            if [ "$mode_proxy" != "Other" ] && ! sh "$file_netfilter_hook"; then
                rm -f "$xkeen_rundir/ready"
                log_error_terminal "Не удалось применить netfilter-хук"
                _release_coldstart_guard
                if [ "$_ps_mutex_rc" -eq 0 ]; then
                    _release_proxy_mutex
                    trap - INT TERM HUP
                fi
                return 1
            fi
            if [ "$start_manual" = "on" ]; then
                log_error_terminal "Не удалось запустить ${yellow}$name_client${reset}, так как он уже запущен"
            else
                log_info_router "Прокси-клиент успешно запущен в режиме $mode_proxy"
                _release_coldstart_guard
            fi
        else
            log_info_router "Инициирован запуск прокси-клиента"
            attempt=1

            fd_limit="$other_fd"
            [ "$arm_cpu" = "true" ] && fd_limit="$arm64_fd"
            ulimit -SHn "$fd_limit"

            export SSL_CERT_FILE="$file_ca"
            while [ "$attempt" -le "$start_attempts" ]; do
                case "$name_client" in
                    xray)
                        export XRAY_LOCATION_CONFDIR="$directory_xray_config"
                        export XRAY_LOCATION_ASSET="$directory_xray_asset"
                        find "$directory_xray_config" -maxdepth 1 -name '._*.json' -type f -delete
                        if [ -n "$fd_out" ]; then
                            nohup "$name_client" run >/dev/null 2>&1 &
                            unset fd_out
                        else
                            if [ "$start_verbose" = "on" ]; then
                                "$name_client" run &
                            else
                                "$name_client" run >/dev/null 2>&1 &
                            fi
                        fi
                    ;;
                    mihomo)
                        export CLASH_HOME_DIR="$directory_configs_app"
                        # См. apply_gomemlimit: доля/лимит из xkeen.json,
                        # минимум 64MiB, внешний GOMEMLIMIT не игнорируется.
                        apply_gomemlimit
                        if [ -n "$fd_out" ]; then
                            nohup "$name_client" >/dev/null 2>&1 &
                            unset fd_out
                        else
                            if [ "$start_verbose" = "on" ]; then
                                "$name_client" &
                            else
                                "$name_client" >/dev/null 2>&1 &
                            fi
                        fi
                        ;;
                    *) log_error_terminal "Неизвестный прокси-клиент: ${yellow}$name_client${reset}" ;;
                esac
                _probe_attempt=0
                while [ "$_probe_attempt" -lt 60 ]; do
                    proxy_status && break
                    _probe_attempt=$((_probe_attempt + 1))
                    usleep 50000
                done
                unset _probe_attempt
                if proxy_status; then
                    if [ "$mode_proxy" != "Other" ] && ! configure_firewall; then
                        rm -f "$xkeen_rundir/ready"
                        log_error_terminal "Не удалось записать netfilter-хук"
                        _release_coldstart_guard
                        if [ "$_ps_mutex_rc" -eq 0 ]; then
                            _release_proxy_mutex
                            trap - INT TERM HUP
                        fi
                        return 1
                    fi
                    : > "$xkeen_rundir/ready"
                    if [ "$mode_proxy" != "Other" ] && ! sh "$file_netfilter_hook"; then
                        rm -f "$xkeen_rundir/ready"
                        log_error_terminal "Не удалось применить netfilter-хук"
                        _release_coldstart_guard
                        if [ "$_ps_mutex_rc" -eq 0 ]; then
                            _release_proxy_mutex
                            trap - INT TERM HUP
                        fi
                        return 1
                    fi
                    # Последовательно: параллельный ipset restore больших RU-списков
                    # сразу после fork mihomo даёт пик RAM / OOM на слабых роутерах.
                    [ "$iptables_supported" = "true" ] && [ -f "$ru_exclude_ipv4" ] && load_ipset geo_exclude "$ru_exclude_ipv4" inet
                    [ "$ip6tables_supported" = "true" ] && [ -f "$ru_exclude_ipv6" ] && load_ipset geo_exclude6 "$ru_exclude_ipv6" inet6
                    load_user_ipset
                    echo -e "  Прокси-клиент ${green}запущен${reset} в режиме ${light_blue}${mode_proxy}${reset}"
                    (
                        # Даём ядру прокси время полностью инициализироваться
                        # Это защищает от ситуаций, когда xray/mihomo
                        # успевает создать PID, но затем аварийно завершается,
                        # например, из-за битой конфигурации
                        _crash_pid=$(pidof "$name_client" 2>/dev/null | awk '{print $1}')
                        sleep 3

                        if [ -n "$_crash_pid" ] && ! kill -0 "$_crash_pid" 2>/dev/null \
                           && ! proxy_status; then
                            echo
                            echo -e "  Прокси-клиент ${red}аварийно завершился${reset}"
                            echo -e "  ${green}Выполняется очистка${reset} правил прозрачного проксирования"
                            log_error_router "Прокси-клиент аварийно завершился после запуска"
                            emergency_clear
                            printf '\n~ # '
                        fi
                    ) &
                    if [ -n "$api_policy_json" ]; then
                        if echo "$api_policy_json" | jq --arg policy "$name_policy" -e 'any(.[]; .description | ascii_downcase == $policy)' > /dev/null; then
                            if [ -e "/tmp/noinet" ]; then
                                echo
                                echo -e "  У политики ${yellow}$name_policy${reset} ${red}нет доступа в интернет${reset}"
                                echo "  Проверьте, установлена ли галка на подключении к провайдеру"
                            fi
                        fi
                    fi
                    [ "$mode_proxy" = "Other" ] && echo -e "  Функция прозрачного прокси ${red}не активна${reset}. Направляйте соединения на ${yellow}${name_client}${reset} вручную"
                    log_info_router "Прокси-клиент успешно запущен в режиме $mode_proxy"
                    _release_coldstart_guard
                    if [ "$check_fd" = "on" ]; then
                        cleanup_fd_monitor
                        monitor_fd &
                        echo $! > "$file_pid_fd"
                        log_info_router "Запущен контроль файловых дескрипторов $name_client"
                    fi
                    if [ "$_ps_mutex_rc" -eq 0 ]; then
                        _release_proxy_mutex
                        trap - INT TERM HUP
                    fi
                    return 0
                fi
                attempt=$((attempt + 1))
            done
            echo -e "  ${red}Не удалось запустить${reset} прокси-клиент"
            clean_firewall
            enable_killswitch
            log_error_terminal "Не удалось запустить прокси-клиент"
            _release_coldstart_guard
        fi
    else
        clean_firewall
    fi
    if [ "$_ps_mutex_rc" -eq 0 ]; then
        _release_proxy_mutex
        trap - INT TERM HUP
    fi
}

# Активная проба готовности окружения вместо sleep $start_delay.
# Ждём ndmc, default route и insmod-ability xt_TPROXY (deps ndm
# подгружает асинхронно уже после ndmc-ready). $start_delay сохранён
# как safety cap (FAQ #12).
wait_for_ready() {
    # Срезаем ведущий ноль в $start_delay ("08"/"09")
    # иначе трактуется как восьмеричный разбор и валит арифметику
    val=${start_delay:-60}
    val=${val#"${val%%[!0]*}"}
    val=${val:-0}
    _max=$(( val * 2 ))
    _attempt=0
    _probe_ko=$(find_module_path "xt_TPROXY.ko")

    while [ "$_attempt" -lt "$_max" ]; do
        if ip route show default 2>/dev/null | grep -q '^default'; then
            # Проверка готовности API политик и модуля xt_TPROXY
            api_policy_json=$(curl_api "${url_server}/${url_policy}" 2>/dev/null)
            case "$api_policy_json" in
                ""|"{}"|"[]") return 0 ;;
                \{*|\[*)
                    if [ -z "$_probe_ko" ] \
                       || grep -q '^xt_TPROXY ' /proc/modules 2>/dev/null \
                       || insmod "$_probe_ko" >/dev/null 2>&1
                    then
                        return 0
                    fi
                    ;;
            esac
        fi
        usleep 500000
        _attempt=$((_attempt + 1))
    done
    return 0
}

# Остановка прокси-клиента
proxy_stop() {
    _acquire_proxy_mutex
    _pstop_mutex_rc=$?
    if [ "$_pstop_mutex_rc" -eq 1 ]; then
        _pstop_wait=0
        while [ "$_pstop_wait" -lt 5 ]; do
            sleep 1
            _acquire_proxy_mutex
            _pstop_mutex_rc=$?
            [ "$_pstop_mutex_rc" -ne 1 ] && break
            _pstop_wait=$((_pstop_wait + 1))
        done
        if [ "$_pstop_mutex_rc" -eq 1 ]; then
            log_warning_terminal "Остановка занята другим процессом, повторите команду"
            return 1
        fi
    fi
    if [ "$_pstop_mutex_rc" -eq 0 ]; then
        trap '_release_proxy_mutex; trap - INT TERM HUP' INT TERM HUP
    fi
    rm -f "$xkeen_rundir/ready"
    if ! proxy_status; then
        echo -e "  Прокси-клиент ${red}не запущен${reset}"
        cleanup_fd_monitor
    else
        [ -f "$xkeen_rundir/coldstart.lock" ] || log_info_router "Инициирована остановка прокси-клиента"
        cleanup_fd_monitor
        attempt=1
        while [ "$attempt" -le "$start_attempts" ]; do
            clean_firewall
            killall -q "$name_client" 2>/dev/null
            _stop_attempt=0
            while [ "$_stop_attempt" -lt 30 ]; do
                pidof "$name_client" >/dev/null 2>&1 || break
                _stop_attempt=$((_stop_attempt + 1))
                usleep 50000
            done
            unset _stop_attempt
            if pidof "$name_client" >/dev/null 2>&1; then
                killall -q -9 "$name_client" 2>/dev/null
                usleep 200000
            fi
            if ! proxy_status; then
                echo -e "  Прокси-клиент ${red}остановлен${reset}"
                [ -f "$xkeen_rundir/coldstart.lock" ] || log_info_router "Прокси-клиент успешно остановлен"
                _release_coldstart_guard
                if [ "$_pstop_mutex_rc" -eq 0 ]; then
                    _release_proxy_mutex
                    trap - INT TERM HUP
                fi
                return 0
            fi
            attempt=$((attempt + 1))
        done
        echo -e "  Прокси-клиент ${red}не удалось остановить${reset}"
        log_error_terminal "Не удалось остановить прокси-клиент"
    fi
    if [ "$_pstop_mutex_rc" -eq 0 ]; then
        _release_proxy_mutex
        trap - INT TERM HUP
    fi
}

# Менеджер команд
_cmd_rc=0
case "$1" in
    start)
        ipset create ext_exclude hash:ip family inet -exist
        ipset create ext_exclude6 hash:ip family inet6 -exist
        if [ -z "$2" ]; then
            [ "$start_auto" != "on" ] && exit 0
            # Атомарный guard ДО spawn — повторный S05xkeen start от
            # NDM (fs.d / init.d / reconnect) увидит каталог и выйдет.
            _acquire_coldstart_guard || exit 0
            log_info_router "Подготовка к запуску прокси-клиента"
            nohup "$0" cold_start >/dev/null 2>&1 &
            # PID фонового cold_start — caller ($$) умрёт через exit 0,
            # а живость guard'а проверяется именно по этому PID.
            _set_coldstart_pid "$!"
            exit 0
        fi
        proxy_start "$2"
        _cmd_rc=$?
    ;;
    stop) proxy_stop; _cmd_rc=$? ;;
    status)
        if proxy_status; then
            mode_proxy=""
            if [ -f "$file_netfilter_hook" ]; then
                mode_proxy=$(grep '^mode_proxy=' "$file_netfilter_hook" | awk -F"=" '{print $2}' | tr -d "'" 2>/dev/null)
            fi
            [ -z "$mode_proxy" ] && mode_proxy="Other"
            echo -e "  Прокси-клиент ${yellow}$name_client${reset} ${green}запущен${reset} в режиме ${light_blue}$mode_proxy${reset}"
            _cmd_rc=0
        else
            echo -e "  Прокси-клиент ${red}не запущен${reset}"
            _cmd_rc=1
        fi
        ;;
    dscp)
        if [ "$dscp_enable" != "off" ]; then
            echo
            print_dscp_force_proxy_status
        fi
        ;;
    restart) proxy_stop; proxy_start "$2"; _cmd_rc=$? ;;
    cold_start)
        # Подстраховка: переписываем PID guard'а на свой ($$) на случай,
        # если caller-S05xkeen умер до того, как успел _set_coldstart_pid "$!".
        _set_coldstart_pid "$$"
        # Гарантированная задержка перед попыткой запуска прокси-клиента
        if [ -n "$init_delay" ] && [ "$init_delay" -gt 0 ] 2>/dev/null; then
            log_info_router "Ожидание перед проверкой готовности к запуску XKeen (${init_delay} сек...)"
            sleep "$init_delay"
        fi
        # Re-spawn в чистый S05xkeen: sh-функции (wait_for_ready) не
        # наследуются через nohup sh -c, поэтому пробу зовём отсюда.
        wait_for_ready
        proxy_start ""
        ;;
    *)
        echo -e "  Команды: ${green}start on${reset} | ${red}stop${reset} | ${yellow}restart on${reset} | status"
        _cmd_rc=1
        ;;
esac

exit "$_cmd_rc"
