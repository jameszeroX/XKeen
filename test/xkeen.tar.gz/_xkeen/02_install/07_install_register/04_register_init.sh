#!/bin/sh

# Информация о службе: Запуск / Остановка XKeen
# Версия: 2.30

# Окружение
PATH="/opt/bin:/opt/sbin:/sbin:/bin:/usr/sbin:/usr/bin"

# Цвета
green="\033[92m"
red="\033[91m"
yellow="\033[93m"
light_blue="\033[96m"
reset="\033[0m"

# Имена
name_client="xray"
name_app="XKeen"
name_policy="xkeen"
name_profile="xkeen"
name_chain="xkeen"
name_ipset_deny_mac="xkeen_deny_mac"

# Директории
directory_os_modules="/lib/modules/$(uname -r)"
directory_user_modules="/opt/lib/modules"
directory_opkg_modules="/opt/lib/system-modules/$(uname -r)"
directory_system_modules="/lib/system-modules/$(uname -r)"
directory_configs_app="/opt/etc/$name_client"
directory_xray_config="$directory_configs_app/configs"
directory_xray_asset="$directory_configs_app/dat"
log_dir="/opt/var/log"
xkeen_cfg="/opt/etc/xkeen"
ipset_cfg="$xkeen_cfg/ipset"
install_dir="/opt/sbin"

# Файлы
file_netfilter_hook="/opt/etc/ndm/netfilter.d/proxy.sh"
file_schedule_hook="/opt/etc/ndm/schedule.d/00-xkeen-hotspot-sync.sh"
log_access="$log_dir/$name_client/access.log"
log_error="$log_dir/$name_client/error.log"
mihomo_config="$directory_configs_app/config.yaml"
file_port_proxying="$xkeen_cfg/port_proxying.lst"
file_port_exclude="$xkeen_cfg/port_exclude.lst"
file_ip_exclude="$xkeen_cfg/ip_exclude.lst"
xkeen_config="$xkeen_cfg/xkeen.json"
status_file="/opt/lib/opkg/status"
file_pid_fd="/var/run/xkeen_fd.pid"
file_cpu="/opt/sbin/.xkeen/01_info/08_info_router.sh"
file_ca="/opt/etc/ssl/certs/ca-certificates.crt"
ru_exclude_ipv4="$ipset_cfg/ru_exclude_ipv4.lst"
ru_exclude_ipv6="$ipset_cfg/ru_exclude_ipv6.lst"
ru_override="$ipset_cfg/ru_exclude_override.lst"

# URL
url_server="localhost:79"
url_policy="rci/show/ip/policy"
url_keenetic_port="rci/ip/http"
url_redirect_port="rci/ip/static"
url_hotspot="rci/show/ip/hotspot"

# Настройки правил iptables
table_id="111"
table_mark="0x111"
table_redirect="nat"
table_tproxy="mangle"
comment_tag="xkeen_rule"
comment="-m comment --comment $comment_tag"
custom_mark=""

# DSCP-метки
dscp_enable="on"
dscp_force_proxy="61"
dscp_force_proxy_tag="dscp-force-proxy"
dscp_exclude="62"
dscp_proxy="63"

ipv4_proxy="127.0.0.1"
ipv4_exclude="0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 255.255.255.255 78.47.125.180"
ipv6_proxy="::1"
ipv6_exclude="::/128 ::1/128 64:ff9b::/96 2001::/32 2002::/16 fd00::/8 ff00::/8 fe80::/10"

# Перехват DNS в прокси
proxy_dns="off"

# Проксирование трафика Entware
proxy_router="off"

# Строгая PBR-проверка mark / routing-mark
pbr_strict="off"

# Настройки запуска
start_verbose="on"
start_attempts=10
start_auto="on"
start_delay=20
init_delay=0

# Контроль файловых дескрипторов
check_fd="off"
arm64_fd=40000
other_fd=10000
delay_fd=60

# Поддержка IPv6
ipv6_support="on"

## Расширенные сообщения запуска
extended_msg="off"

## Резервное копирование XKeen при обновлении
backup="on"

## Клиенты XKeen под своими IP в журнале AdGuard Home
aghfix="off"

# Функции журналирования
log_info_router() { logger -p notice -t "$name_app" "$1"; }
log_warning_router() { logger -p warning -t "$name_app" "$1"; }
log_error_router() { logger -p error -t "$name_app" "$1"; }

log_info_terminal() { echo -e "\n${green}Информация${reset}: $1" >&2; }
log_warning_terminal() { echo -e "\n${yellow}Предупреждение${reset}: $1" >&2; }
log_error_terminal() { echo -e "\n${red}Ошибка${reset}: $1" >&2; exit 1; }

if [ "$dscp_enable" = "off" ]; then
    dscp_force_proxy=""
    dscp_exclude=""
    dscp_proxy=""
    port_dscp_force_proxy=""
    mode_dscp_force_proxy=""
    network_dscp_force_proxy=""
fi

print_policy_info() {
    found="$1"
    has_custom="$2"
    ignored_custom="$3"

    ignore_line=""
    if [ "$ignored_custom" = "yes" ]; then
        ignore_line="
  Пользовательские политики из '${yellow}xkeen.json${reset}' будут проигнорированы"
    fi

    if [ "$extended_msg" != "on" ]; then
        if [ "$found" = "no" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Прокси будет запущен для всех клиентов устройства"
        fi
        return
    fi

    if [ "$found" = "yes" ]; then

        if [ "$has_custom" = "yes" ]; then
            custom_names=$(echo "$user_policies" | cut -d'|' -f1 | tr '\n' ',' | sed 's/,$//; s/,/, /g')
            policies="${name_policy}, ${custom_names}"

            detail_list=""
            if [ -n "$port_donor" ]; then
                detail_list="  - ${yellow}$name_policy${reset} на портах ${green}${port_donor}${reset}"
            elif [ -n "$port_exclude" ]; then
                detail_list="  - ${yellow}$name_policy${reset} на всех портах кроме ${green}${port_exclude}${reset}"
            else
                detail_list="  - ${yellow}$name_policy${reset} на всех портах"
            fi

            custom_details=$(echo "$user_policies" | while IFS='|' read -r p_name p_mark p_mode p_ports; do
                if [ "$p_mode" = "include" ]; then
                    echo "  - ${yellow}$p_name${reset} на портах ${green}${p_ports}${reset}"
                elif [ "$p_mode" = "exclude" ]; then
                    echo "  - ${yellow}$p_name${reset} на всех портах кроме ${green}${p_ports}${reset}"
                else
                    echo "  - ${yellow}$p_name${reset} на всех портах"
                fi
            done)

            log_info_terminal "
  Найдены политики '${yellow}${policies}${reset}'
  Прокси будет запущен для клиентов политик:
${detail_list}
${custom_details}"
        else
            if [ -z "$port_donor" ] && [ -z "$port_exclude" ]; then
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Не определены целевые порты для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}' на всех портах"
            elif [ -n "$port_donor" ]; then
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Определены целевые порты для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}'
  на портах ${green}${port_donor}${reset}"
            else
                log_info_terminal "
  Найдена политика '${yellow}$name_policy${reset}'
  Определены порты исключения для XKeen
  Прокси будет запущен для клиентов политики '${yellow}$name_policy${reset}'
  на всех портах кроме ${green}${port_exclude}${reset}"
            fi
        fi
    else
        if [ -n "$port_donor" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Определены целевые порты для XKeen
  Прокси будет запущен для всех клиентов
  на портах ${green}${port_donor}${reset}"
        elif [ -n "$port_exclude" ]; then
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Определены порты исключения для XKeen
  Прокси будет запущен для всех клиентов
  на всех портах кроме ${green}${port_exclude}${reset}"
        else
            log_info_terminal "
  Политика '${yellow}$name_policy${reset}' не найдена в веб-интерфейсе роутера${ignore_line}
  Не определены целевые порты для XKeen
  Прокси будет запущен для всех клиентов на всех портах"
        fi
    fi
}

utils="jq curl grep awk sed ipset"
[ "$name_client" = "mihomo" ] && utils="$utils yq"
for cmd in $utils; do
    command -v "$cmd" >/dev/null 2>&1 || log_error_terminal "Не найдена необходимая утилита: ${yellow}$cmd${reset}"
done

log_clean() { [ "$name_client" = "xray" ] && : > "$log_access" && : > "$log_error"; }

curl_api() { curl --connect-timeout 2 -m 5 -kfsS "$@"; }

api_cache_init() {
    api_policy_json=$(curl_api "${url_server}/${url_policy}" 2>/dev/null)
    api_port_json=$(curl_api "${url_server}/${url_keenetic_port}" 2>/dev/null)
    api_static_json=$(curl_api "${url_server}/${url_redirect_port}" 2>/dev/null)
}

refresh_port_cache() { api_port_json=$(curl_api "${url_server}/${url_keenetic_port}" 2>/dev/null); }

json_get_ports() { [ -n "$api_port_json" ] && printf '%s' "$api_port_json" | jq -r '.port, (.ssl.port // empty)' 2>/dev/null; }

# Получение портов Keenetic
get_keenetic_port() {
    ports=""
    ports=$(json_get_ports)

    case " $ports " in
        *" 443 "*) return 1 ;;
    esac

    if [ -z "$ports" ]; then
        ndmc -c 'ip http port 8080' >/dev/null 2>&1
        ndmc -c 'ip http port 80' >/dev/null 2>&1
        ndmc -c 'system configuration save' >/dev/null 2>&1
        sleep 2
        refresh_port_cache
        ports=$(json_get_ports)
    fi

    [ -n "$ports" ] || return 1

    echo "$ports"
    return 0
}

wait_for_webui() {
    max_wait=10
    i=0

    while [ "$i" -lt "$max_wait" ]; do
        pidof nginx >/dev/null 2>&1 && return 0
        sleep 1
        i=$((i + 1))
    done

    return 1
}

apply_ipv6_state() {
    ipv6_disabled=
    ipv6_disabled=$(sysctl -n net.ipv6.conf.default.disable_ipv6 2>/dev/null || echo "0")

    [ "$ipv6_disabled" -eq 1 ] && return 0

    [ "$ipv6_support" != "off" ] && return 0

    ip -6 addr show 2>/dev/null | grep -q "inet6 fe80::" || return 0

    wait_for_webui || { log_error_router "Веб-интерфейс недоступен"; return 1; }

    sleep 5

    sysctl -w net.ipv6.conf.default.disable_ipv6=1 >/dev/null 2>&1

    for dir in /proc/sys/net/ipv6/conf/*; do
        [ -d "$dir" ] || continue
        iface="${dir##*/}"

        case "$iface" in
            all|ezcfg0|t2s*)
                continue
                ;;
            *)
                [ -f "$dir/disable_ipv6" ] && echo "1" > "$dir/disable_ipv6" 2>/dev/null
                ;;
        esac
    done

    sleep 2

    if [ "$(sysctl -n net.ipv6.conf.default.disable_ipv6 2>/dev/null)" -eq 1 ]; then
        log_info_router "Отключение IPv6 выполнено"
        return 0
    fi
}

get_ipver_support() {
    ip4_supported=$(ip -4 addr show 2>/dev/null | grep -q "inet " && echo true || echo false)
    ip6_supported=$(ip -6 addr show 2>/dev/null | grep -q "inet6 fe80::" && echo true || echo false)

    iptables_supported=$([ "$ip4_supported" = "true" ] && command -v iptables >/dev/null 2>&1 && echo true || echo false)
    ip6tables_supported=$([ "$ip6_supported" = "true" ] && command -v ip6tables >/dev/null 2>&1 && echo true || echo false)
}

strip_json_comments() {
    sed -e ':a; s:/\*[^*]*\*[^/]*\*/::g; ta' \
        -e 's/^[[:space:]]*\/\/.*$//' \
        -e 's/[[:space:]]\{1,\}\/\/.*$//' "$@"
}

append_multiline() {
    current_value="$1"
    new_value="$2"

    if [ -n "$current_value" ]; then
        printf '%s\n%s' "$current_value" "$new_value"
    else
        printf '%s' "$new_value"
    fi
}

format_routing_mark_items() {
    item_label="$1"
    mark_label="$2"
    raw_items="$3"

    printf '%b\n' "$raw_items" | awk -F '\t' -v item_label="$item_label" -v mark_label="$mark_label" '
        NF == 0 || seen[$0]++ { next }
        {
            status = ($2 == "" ? mark_label " отсутствует" : "найден " mark_label " " $2)
            print "  - " item_label " " $1 ": " status
        }
    '
}

# Функция валидации xkeen.json
validate_xkeen_json() {
    [ ! -f "$xkeen_config" ] && return 0
    if ! jq -e . "$xkeen_config" >/dev/null 2>&1; then
            log_error_terminal "
  Валидация JSON: файл '${yellow}xkeen.json${reset}' содержит синтаксические ошибки
  Запуск прокси невозможен
"
    fi

    if ! jq -e '.xkeen.policy[]? | .name' "$xkeen_config" >/dev/null 2>&1; then
        if jq -e '.xkeen' "$xkeen_config" >/dev/null 2>&1; then
            log_error_terminal "
  Файл '${yellow}xkeen.json${reset}' имеет неверную структуру
  Запуск прокси невозможен
"
        fi
    fi

    return 0
}

# Функция поиска резервных копий конфигурационных файлов Xray
check_xray_backups() {
    [ "$name_client" != "xray" ] && return 0

    # Ищем json-файлы с типичными признаками копий
    bad_files=$(find "$directory_xray_config" -maxdepth 1 -type f \( -iname "*bak*.json" -o -iname "*old*.json" -o -iname "*copy*.json" -o -iname "*копия*.json" -o -iname "*orig*.json" -o -iname "*save*.json" -o -iname "*temp*.json" -o -iname "*tmp*.json" -o -name "*(*).json" \))

    if [ -n "$bad_files" ]; then
        bad_list=$(printf '%s\n' "$bad_files" | awk -F/ '{print "  - " $NF}')
        
        log_error_terminal "
  В директории конфигурации Xray найдены резервные копии:
${light_blue}${bad_list}${reset}

  Измените расширение резервных копий, например, на ${yellow}.bak${reset}
  Либо переместите их в поддиректорию
  Запуск ${yellow}$name_client${reset} ${red}отменен${reset}
"
    fi
    return 0
}

build_allowed_policy_marks() {
    include_service_mark="$1"
    allowed_marks=""
    policy_hex_marks="$policy_mark"

    if [ "$include_service_mark" = "yes" ]; then
        allowed_marks="255"
    fi

    if [ -n "$user_policies" ]; then
        user_policy_hex_marks=$(printf '%s\n' "$user_policies" | awk -F'|' '$2 != "" {print "0x"$2}')
        policy_hex_marks="$policy_hex_marks $user_policy_hex_marks"
    fi

    for policy_hex_mark in $policy_hex_marks; do
        policy_mark_dec=$(hex_mark_to_decimal "$policy_hex_mark" 2>/dev/null)
        [ -n "$policy_mark_dec" ] && allowed_marks="$allowed_marks $policy_mark_dec"
    done

    if [ -n "$allowed_marks" ]; then
        allowed_marks=$(printf '%s\n' $allowed_marks | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/ $//')
    fi

    printf '%s\n' "$allowed_marks"
}

format_allowed_marks_display() {
    printf '%s\n' "$1" | tr ' ' '\n' | awk '
        NF && !seen[$0]++ {
            if (out != "") {
                out = out ", " $0
            } else {
                out = $0
            }
        }
        END {
            print out
        }
    '
}

format_single_line_error() {
    printf '%s' "$1" | tr '\n' ' ' | sed 's/[[:space:]]\{1,\}/ /g; s/^ //; s/ $//'
}

convert_mihomo_yaml_to_json() {
    config_file="$1"
    tmp_base="${TMPDIR:-/tmp}/xkeen_mihomo_json.$$"
    out_file="${tmp_base}.out"
    err_file="${tmp_base}.err"
    last_stderr=""

    rm -f "$out_file" "$err_file"

    for yq_variant in \
        "dash_o_json" \
        "dash_o_space_json" \
        "eval_dash_o_json" \
        "eval_dash_o_space_json"
    do
        : > "$out_file"
        : > "$err_file"

        case "$yq_variant" in
            dash_o_json)
                if yq -o=json '.' "$config_file" >"$out_file" 2>"$err_file" \
                    && jq -e . <"$out_file" >/dev/null 2>&1; then
                    cat "$out_file"
                    rm -f "$out_file" "$err_file"
                    return 0
                fi
                ;;
            dash_o_space_json)
                if yq -o json '.' "$config_file" >"$out_file" 2>"$err_file" \
                    && jq -e . <"$out_file" >/dev/null 2>&1; then
                    cat "$out_file"
                    rm -f "$out_file" "$err_file"
                    return 0
                fi
                ;;
            eval_dash_o_json)
                if yq eval -o=json '.' "$config_file" >"$out_file" 2>"$err_file" \
                    && jq -e . <"$out_file" >/dev/null 2>&1; then
                    cat "$out_file"
                    rm -f "$out_file" "$err_file"
                    return 0
                fi
                ;;
            eval_dash_o_space_json)
                if yq eval -o json '.' "$config_file" >"$out_file" 2>"$err_file" \
                    && jq -e . <"$out_file" >/dev/null 2>&1; then
                    cat "$out_file"
                    rm -f "$out_file" "$err_file"
                    return 0
                fi
                ;;
        esac

        candidate_stderr=$(format_single_line_error "$(cat "$err_file" 2>/dev/null)")
        [ -n "$candidate_stderr" ] && last_stderr="$candidate_stderr"
    done

    rm -f "$out_file" "$err_file"

    if [ -n "$last_stderr" ]; then
        printf '%s' "не удалось преобразовать YAML в JSON через yq: $last_stderr"
    else
        printf '%s' "yq не вернул валидный JSON"
    fi

    return 1
}

validate_client_routing_mark() {
    validation_mode="$1"
    include_service_mark="$2"

    bad_items=""
    has_items="false"
    allowed_marks=$(build_allowed_policy_marks "$include_service_mark")
    validation_errors=""
    mark_msg=""
    item_label=""
    item_label_plural=""
    config_hint=""
    needs_attention="false"
    allowed_marks_display=""
    global_mark_valid="false"
    provider_mark_valid="false"

    allowed_marks_display=$(format_allowed_marks_display "$allowed_marks")
    if [ "$name_client" = "xray" ]; then
        mark_msg="mark"
        item_label="outbound"
        item_label_plural="outbounds"
        config_hint="  Для Xray задайте ${green}mark${reset} в ${yellow}streamSettings.sockopt${reset} у всех реальных outbounds, кроме служебных (${yellow}blackhole${reset}, ${yellow}dns${reset}, ${yellow}loopback${reset})"

        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue

            outbounds_state=$(strip_json_comments "$file" | jq -r '
                if .outbounds == null then
                    "missing"
                elif (.outbounds | type) == "array" then
                    "array"
                else
                    "invalid"
                end
            ' 2>&1)
            outbounds_state_rc=$?

            if [ "$outbounds_state_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): $outbounds_state")
                continue
            fi

            case "$outbounds_state" in
                missing)
                    continue
                    ;;
                invalid)
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): поле .outbounds должно быть массивом")
                    continue
                    ;;
                array)
                    has_items="true"
                    ;;
            esac

            current_bad=$(strip_json_comments "$file" | jq -r --arg allowed "$allowed_marks" '
                def flatten_nested_arrays:
                    if type == "array" then
                        .[] | flatten_nested_arrays
                    else
                        .
                    end;

                (.outbounds // [])
                | .[]?
                | flatten_nested_arrays
                | select(type == "object")
                | select((.protocol // "") != "blackhole" and (.protocol // "") != "dns" and (.protocol // "") != "loopback")
                | (.streamSettings? | if type == "object" then . else {} end) as $stream
                | ($stream.sockopt? | if type == "object" then . else {} end) as $sockopt
                | ($sockopt.mark? // null) as $mark
                | select(($allowed | split(" ") | index((if $mark == null or $mark == "" then "" else ($mark | tostring) end))) | not)
                | [(.tag // .protocol // "<unnamed>"), (if $mark == null or $mark == "" then "" else ($mark | tostring) end)] | @tsv
            ' 2>&1)
            current_bad_rc=$?

            if [ "$current_bad_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$file"): $current_bad")
                continue
            fi

            if [ -n "$current_bad" ]; then
                bad_items=$(append_multiline "$bad_items" "$current_bad")
            fi
        done

    elif [ "$name_client" = "mihomo" ]; then
        mark_msg="routing-mark"
        item_label="proxy"
        item_label_plural="proxies"
        config_hint="  Для Mihomo задайте ${green}routing-mark${reset} глобально либо у нужных ${yellow}proxies${reset}/${yellow}proxy-providers${reset}"

        if [ -f "$mihomo_config" ]; then
            mihomo_json=$(convert_mihomo_yaml_to_json "$mihomo_config")
            mihomo_json_rc=$?

            if [ "$mihomo_json_rc" -ne 0 ]; then
                validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $mihomo_json")
            else
                if ! printf '%s' "$mihomo_json" | jq -e . >/dev/null 2>&1; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): yq не вернул валидный JSON")
                else
                root_kind=$(printf '%s' "$mihomo_json" | jq -r 'type' 2>&1)
                root_kind_rc=$?

                if [ "$root_kind_rc" -ne 0 ]; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $root_kind")
                elif [ "$root_kind" != "object" ]; then
                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): корень config.yaml должен быть map/object")
                else
                    global_mark_valid=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" '
                        .["routing-mark"] as $mark
                        | if $mark != null and (($allowed | split(" ") | index($mark | tostring)) != null) then
                            "true"
                        else
                            "false"
                        end
                    ' 2>&1)
                    global_mark_valid_rc=$?
                    [ "$global_mark_valid_rc" -ne 0 ] && validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $global_mark_valid")

                    provider_mark_valid=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" '
                        def values_or_items:
                            if type == "object" or type == "array" then
                                .[]?
                            else
                                empty
                            end;

                        [
                            (.["proxy-providers"] // empty)
                            | values_or_items
                            | select(type == "object")
                            | (.override? | if type == "object" then . else {} end)
                            | .["routing-mark"]? as $mark
                            | select($mark != null)
                            | (($allowed | split(" ") | index($mark | tostring)) != null)
                        ] | any
                    ' 2>&1)
                    provider_mark_valid_rc=$?
                    [ "$provider_mark_valid_rc" -ne 0 ] && validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $provider_mark_valid")

                    proxies_state=$(printf '%s' "$mihomo_json" | jq -r '
                        if .proxies == null then
                            "missing"
                        elif (.proxies | type) == "array" then
                            "array"
                        else
                            "invalid"
                        end
                    ' 2>&1)
                    proxies_state_rc=$?

                    if [ "$proxies_state_rc" -ne 0 ]; then
                        validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $proxies_state")
                    else
                        case "$proxies_state" in
                            missing)
                                if [ "$global_mark_valid" != "true" ] && [ "$provider_mark_valid" != "true" ]; then
                                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): не найдены proxies и нет глобального/provider routing-mark для проверки")
                                fi
                                ;;
                            invalid)
                                validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): поле .proxies должно быть массивом")
                                ;;
                            array)
                                has_items="true"
                                current_bad=$(printf '%s' "$mihomo_json" | jq -r --arg allowed "$allowed_marks" --arg global_valid "$global_mark_valid" '
                                    def flatten_nested_arrays:
                                        if type == "array" then
                                            .[] | flatten_nested_arrays
                                        else
                                            .
                                        end;

                                    (.proxies // [])
                                    | .[]?
                                    | flatten_nested_arrays
                                    | select(type == "object")
                                    | (.["routing-mark"]? // null) as $mark
                                    | select(
                                        if $mark == null or $mark == "" then
                                            $global_valid != "true"
                                        else
                                            (($allowed | split(" ") | index($mark | tostring)) == null)
                                        end
                                    )
                                    | [(.name // .type // "<unnamed>"), (if $mark == null or $mark == "" then "" else ($mark | tostring) end)] | @tsv
                                ' 2>&1)
                                current_bad_rc=$?

                                if [ "$current_bad_rc" -ne 0 ]; then
                                    validation_errors=$(append_multiline "$validation_errors" "$(basename "$mihomo_config"): $current_bad")
                                elif [ -n "$current_bad" ]; then
                                    bad_items=$(append_multiline "$bad_items" "$current_bad")
                                fi
                                ;;
                        esac
                    fi
                fi
                fi
            fi
        else
            validation_errors=$(append_multiline "$validation_errors" "config.yaml: файл не найден")
        fi
    fi

    if [ -n "$validation_errors" ] || [ -n "$bad_items" ] || { [ "$name_client" = "xray" ] && [ "$has_items" != "true" ]; }; then
        needs_attention="true"
    fi

    [ "$needs_attention" != "true" ] && return 0

    error_details=""

    if [ "$name_client" = "xray" ] && [ "$has_items" != "true" ] && [ -z "$validation_errors" ]; then
        validation_errors=$(append_multiline "$validation_errors" "Не найдены реальные outbounds для проверки")
    fi

    if [ -n "$validation_errors" ]; then
        validation_list=$(printf "%b\n" "$validation_errors" | awk '!seen[$0]++ {print "  - " $0}')
        error_details="${error_details}

  Не удалось полностью проверить конфигурацию:
${light_blue}${validation_list}${reset}"
    fi

    if [ -n "$bad_items" ]; then
        bad_list=$(format_routing_mark_items "$item_label" "$mark_msg" "$bad_items")
        error_details="${error_details}

  Проблемные ${item_label_plural}:
${light_blue}${bad_list}${reset}"
    fi

    if [ -n "$bad_items" ] || { [ "$name_client" = "xray" ] && [ "$has_items" != "true" ] && [ -z "$validation_errors" ]; }; then
        validation_summary="не найден"
        pbr_validation_summary="не найден корректный"
    else
        validation_summary="не удалось проверить"
        pbr_validation_summary="не удалось проверить корректный"
    fi

    if [ "$validation_mode" = "pbr" ]; then
        log_error_terminal "
  Включена strict PBR-проверка, но у исходящих подключений ${yellow}${name_client}${reset} ${pbr_validation_summary} ${yellow}mark/routing-mark${reset} политики Keenetic$error_details

  Разрешённые policy marks Keenetic: ${yellow}${allowed_marks_display}${reset}
$config_hint
  Служебная метка ${yellow}255${reset} не является policy mark и не подходит для PBR
  Получите код политики командой ${yellow}xkeen -pbr codes${reset} и укажите его в конфигурации
  Управление режимом: ${yellow}xkeen -pbr on${reset} | ${yellow}xkeen -pbr off${reset} | ${yellow}xkeen -pbr status${reset}
"
    else
        log_warning_terminal "
  Проксирование Entware включено, но у исходящих подключений ${yellow}${name_client}${reset} ${validation_summary} ${yellow}mark/routing-mark${reset} для bypass$error_details

  Для обычного Entware proxy можно использовать служебную метку ${yellow}255${reset}
  Разрешённые bypass marks: ${yellow}${allowed_marks_display}${reset}
$config_hint
  Если нужно направить сам ${yellow}${name_client}${reset} через конкретную политику Keenetic, используйте код из ${yellow}xkeen -pbr codes${reset}
"
    fi

    return 0
}

validate_entware_proxy_mark() {
    [ "$proxy_router" != "on" ] && return 0
    validate_client_routing_mark "entware" "yes"
}

validate_pbr_routing_mark() {
    [ "$pbr_strict" != "on" ] && return 0

    allowed_policy_marks=$(build_allowed_policy_marks "no")
    if [ -z "$allowed_policy_marks" ]; then
        log_error_terminal "
  Не удалось получить коды политик Keenetic для PBR
  Создайте или проверьте политику в веб-интерфейсе Keenetic и повторите ${yellow}xkeen -pbr codes${reset}
  Служебная метка ${yellow}255${reset} не является policy mark и не подходит для PBR
"
    fi

    validate_client_routing_mark "pbr" "no"
}

load_user_ipset_family() {
    set_name="$1"
    family="$2"
    addr_regex="$3"
    source_file="$4"
    tmp="${set_name}_tmp"

    # Заполняем tmp; основной набор подменяется только после успешного pipeline
    ipset create "$set_name" hash:net family "$family" -exist
    ipset create "$tmp" hash:net family "$family" -exist
    ipset flush "$tmp"

    if sed -e 's/\r$//' -e 's/#.*//' -e '/^[[:space:]]*$/d' "$source_file" |
       grep -Eo "$addr_regex" |
       awk -v s="$tmp" '{print "add "s" "$1}' | ipset restore -exist; then
        ipset swap "$set_name" "$tmp"
    fi
    ipset destroy "$tmp"
}

# Функция загрузки пользовательских исключений в ipset
load_user_ipset() {
    [ ! -f "$file_ip_exclude" ] && return
    [ "$iptables_supported" = "true" ] && load_user_ipset_family user_exclude inet '([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?' "$file_ip_exclude"
    [ "$ip6tables_supported" = "true" ] && load_user_ipset_family user_exclude6 inet6 '([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(/[0-9]{1,3})?' "$file_ip_exclude"

    # Обработка списка исключений из geo_exclude
    if [ -f "$ru_override" ]; then
        [ "$iptables_supported" = "true" ] && load_user_ipset_family geo_override inet '([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?' "$ru_override"
        [ "$ip6tables_supported" = "true" ] && load_user_ipset_family geo_override6 inet6 '([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(/[0-9]{1,3})?' "$ru_override"
    else
        # Если файла исключений нет, создаем пустые сеты, чтобы iptables не ругался на их отсутствие
        [ "$iptables_supported" = "true" ] && ipset create geo_override hash:net family inet -exist
        [ "$ip6tables_supported" = "true" ] && ipset create geo_override6 hash:net family inet6 -exist
    fi
}

# Функция чтения пользовательских портов из файлов
read_ports_from_file() {
    file_ports="$1"
    [ -f "$file_ports" ] || return

    sed -e 's/\r$//' -e 's/#.*//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e '/^$/d' "$file_ports"
}

# Функция обработки, валидации и нормализации списка портов
validate_and_clean_ports() {
    input_ports="$1"
    mandatory_ports="$2"
    [ -z "$input_ports" ] && [ -z "$mandatory_ports" ] && return 1

    echo "${mandatory_ports}${mandatory_ports:+,}${input_ports}" | tr ',' '\n' | awk '
        function is_valid(p) {
            return p ~ /^[0-9]+$/ && p > 0 && p <= 65535
        }
        {
            gsub(/[[:space:]]/, "", $0)
            gsub(/-/, ":", $0)
            if ($0 == "") next

            n = split($0, a, ":")

            if (n == 1) {
                if (is_valid(a[1])) {
                    print a[1]
                }
            }

            else if (n == 2) {
                if (is_valid(a[1]) && is_valid(a[2])) {
                    start = a[1]
                    end   = a[2]

                    if (start > end) {
                        tmp = start
                        start = end
                        end = tmp
                    }

                    if (start <= end) {
                        print start ":" end
                    }
                }
            }
        }
    ' | sort -n -u | tr '\n' ',' | sed 's/,$//'
}

# Функция обработки пользовательских портов
process_user_ports() {
    raw_donor=$(read_ports_from_file "$file_port_proxying")
    [ -n "$raw_donor" ] && port_donor=$(validate_and_clean_ports "$raw_donor" "80,443") || port_donor=""
    port_exclude=$(validate_and_clean_ports "$(read_ports_from_file "$file_port_exclude")")

    if [ -n "$port_donor" ] && [ -n "$port_exclude" ]; then
        log_warning_terminal "
  Заданы и порты проксирования, и порты исключения
  Прокси будет запущен на портах проксирования, порты исключения игнорируются
"
        port_exclude=""
    fi
}

# Функция нормализации сторонних политик
process_custom_mark() {
    [ -n "$custom_mark" ] || return

    local clean_mark=""
    local val
    local mark
    local IFS=', '

    for mark in $custom_mark; do
        [ -n "$mark" ] || continue

        val=${mark#0x}
        val=${val#0X}

        case "$val" in
            ''|*[!0-9a-fA-F]*)
                ;;
            *)
                clean_mark="$clean_mark 0x$val"
                ;;
        esac
    done

    custom_mark=${clean_mark# }
}

# Проверка статуса прокси-клиента
proxy_status() { pidof "$name_client" >/dev/null; }

# Поиск конфигураций DNS
check_dns_config() {
    [ "$proxy_dns" != "on" ] && echo "false" && return

    if [ "$name_client" = "xray" ]; then
        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue
            strip_json_comments "$file" | jq -e '.dns.servers? != null' >/dev/null 2>&1 && { echo "true"; return; }
        done
    elif [ "$name_client" = "mihomo" ]; then
        [ -f "$mihomo_config" ] && yq -e '.dns.enable == true' "$mihomo_config" >/dev/null 2>&1 && { echo "true"; return; }
    fi

    echo "false"
}
file_dns=$(check_dns_config)

# Кэш списка загруженных модулей; is_module_loaded читает его без форков
_loaded_modules=""
_refresh_modules_cache() { _loaded_modules=" $(lsmod 2>/dev/null | awk '{print $1}' | tr '\n' ' ') "; }

is_module_loaded() {
    case "$_loaded_modules" in
        *" $1 "*) return 0 ;;
        *) return 1 ;;
    esac
}

# Определение пути к модулям
find_module_path() {
    module_name="$1"

    for dir in "$directory_os_modules" "$directory_user_modules" "$directory_opkg_modules" "$directory_system_modules"; do
        if [ -f "$dir/$module_name" ]; then
            echo "$dir/$module_name"
            return 0
        fi
    done
    return 1
}

# Загрузка модулей
load_modules() {
    name="${1%.ko}"

    if ! is_module_loaded "$name"; then
        module_path=$(find_module_path "$1")
        if [ -n "$module_path" ]; then
            insmod "$module_path" >/dev/null 2>&1
        fi
    fi
}

# Обработка модулей и портов
get_modules() {
    _refresh_modules_cache
    load_modules xt_comment.ko
    load_modules xt_TPROXY.ko
    load_modules xt_socket.ko
    load_modules xt_multiport.ko
    load_modules xt_dscp.ko
    _refresh_modules_cache  # подхватить только что insmod-нутые модули

    if ! is_module_loaded xt_comment; then
        log_error_router "Модуль xt_comment не загружен"
        log_error_terminal "
  Модуль '${light_blue}xt_comment${reset}' не загружен
  Невозможно запустить XKeen без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'
"
    fi

    if [ "$mode_proxy" = "TProxy" ] || [ "$mode_proxy" = "Hybrid" ]; then
        for module in xt_TPROXY.ko xt_socket.ko; do
            if ! is_module_loaded "${module%.ko}"; then
                proxy_stop
                log_error_router "Модуль ${module} не загружен"
                log_error_terminal "
  Модуль '${light_blue}${module}${reset}' не загружен
  Невозможно запустить XKeen в режиме ${mode_proxy} без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'
"
            fi
        done
    fi

    if [ -n "$port_donor" ] || [ -n "$port_exclude" ]; then
        if ! is_module_loaded xt_multiport; then
            log_warning_router "Модуль xt_multiport не загружен"
            log_warning_terminal "
  Модуль '${light_blue}xt_multiport${reset}' не загружен
  Невозможно использовать выбранные порты без него
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'

  Прокси будет запущен на всех портах
"
            port_donor=""
            port_exclude=""
        fi
    fi

    if [ -n "$dscp_force_proxy" ] || [ -n "$dscp_exclude" ] || [ -n "$dscp_proxy" ]; then
        if ! is_module_loaded xt_dscp; then
            log_warning_router "Модуль xt_dscp не загружен"
            log_warning_terminal "
  Модуль '${light_blue}xt_dscp${reset}' не загружен
  Работа с DSCP-метками невозможна
  Установите компонент роутера '${yellow}Модули ядра подсистемы Netfilter${reset}'
"
            dscp_force_proxy=""
            dscp_exclude=""
            dscp_proxy=""
            port_dscp_force_proxy=""
            mode_dscp_force_proxy=""
            network_dscp_force_proxy=""
        fi
    fi
}

# Получение transparent inbound'ов Xray
_invalidate_inbounds_cache() { rm -f /tmp/xkeen-inbounds-cache; }

get_xray_transparent_inbounds() {
    cache_file="/tmp/xkeen-inbounds-cache"
    cache_valid=0
    if [ -f "$cache_file" ]; then
        newer=$(find "$directory_xray_config" -maxdepth 1 -name '*.json' -newer "$cache_file" 2>/dev/null | head -n 1)
        [ -z "$newer" ] && cache_valid=1
    fi
    if [ "$cache_valid" = "1" ]; then
        cat "$cache_file"
        return 0
    fi
    cache_tmp="${cache_file}.tmp.$$"
    {
        for file in "$directory_xray_config"/*.json; do
            [ -f "$file" ] || continue

            strip_json_comments "$file" |
            jq -r --arg file "$file" '
                .inbounds[]? |
                select(
                    (.protocol == "dokodemo-door" or .protocol == "tunnel") and
                    ((.settings.followRedirect? // false) == true)
                ) |
                (.streamSettings.sockopt.tproxy? // "") as $tproxy |
                select($tproxy == "" or $tproxy == "redirect" or $tproxy == "tproxy") |
                [
                    (if $tproxy == "tproxy" then "tproxy" else "redirect" end),
                    (.port // ""),
                    (.settings.network // ""),
                    (.tag // ""),
                    $file
                ] | @tsv
            ' 2>/dev/null
        done
    } > "$cache_tmp"
    mv "$cache_tmp" "$cache_file"
    cat "$cache_file"
}

get_xray_port_by_mode() {
    mode="$1"
    # Отдельный DSCP force-inbound не должен подменять штатный transparent inbound.
    ignore_tag="$dscp_force_proxy_tag"
    ignore_tag_redirect="${dscp_force_proxy_tag}-redirect"
    ignore_tag_tproxy="${dscp_force_proxy_tag}-tproxy"
    port=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v mode="$mode" -v ignore_tag="$ignore_tag" -v ignore_tag_redirect="$ignore_tag_redirect" -v ignore_tag_tproxy="$ignore_tag_tproxy" '
            $1 == mode && $4 != ignore_tag && $4 != ignore_tag_redirect && $4 != ignore_tag_tproxy && $2 != "" {
                print $2
                exit
            }
        '
    )

    echo "$port"
}

get_xray_network_by_mode() {
    mode="$1"
    ignore_tag="$dscp_force_proxy_tag"
    ignore_tag_redirect="${dscp_force_proxy_tag}-redirect"
    ignore_tag_tproxy="${dscp_force_proxy_tag}-tproxy"
    network=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v mode="$mode" -v ignore_tag="$ignore_tag" -v ignore_tag_redirect="$ignore_tag_redirect" -v ignore_tag_tproxy="$ignore_tag_tproxy" '
            function add_networks(value, count, i, item) {
                gsub(/,/, " ", value)
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
                if (value == "") {
                    return
                }

                count = split(value, items, /[[:space:]]+/)
                for (i = 1; i <= count; i++) {
                    item = items[i]
                    if (item != "" && !seen[item]++) {
                        order[++order_count] = item
                    }
                }
            }

            $1 == mode && $4 != ignore_tag && $4 != ignore_tag_redirect && $4 != ignore_tag_tproxy {
                add_networks($3)
            }

            END {
                for (i = 1; i <= order_count; i++) {
                    printf "%s%s", order[i], (i < order_count ? " " : "")
                }
            }
        '
    )

    echo "$network"
}

get_xray_port_by_tag() {
    tag="$1"
    port=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" '
            $4 == tag && $2 != "" {
                print $2
                exit
            }
        '
    )

    echo "$port"
}

get_xray_port_by_tag_mode() {
    tag="$1"
    mode="$2"
    port=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" -v mode="$mode" '
            $4 == tag && $1 == mode && $2 != "" {
                print $2
                exit
            }
        '
    )

    echo "$port"
}

get_xray_mode_by_tag() {
    tag="$1"
    mode=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" '
            $4 == tag && $1 != "" {
                print $1
                exit
            }
        '
    )

    echo "$mode"
}

get_xray_network_by_tag_mode() {
    tag="$1"
    mode="$2"
    network=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" -v mode="$mode" '
            function add_networks(value, count, i, item) {
                gsub(/,/, " ", value)
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
                if (value == "") {
                    return
                }

                count = split(value, items, /[[:space:]]+/)
                for (i = 1; i <= count; i++) {
                    item = items[i]
                    if (item != "" && !seen[item]++) {
                        order[++order_count] = item
                    }
                }
            }

            $4 == tag && $1 == mode {
                add_networks($3)
            }

            END {
                for (i = 1; i <= order_count; i++) {
                    printf "%s%s", order[i], (i < order_count ? " " : "")
                }
            }
        '
    )

    echo "$network"
}

get_xray_network_by_tag() {
    tag="$1"
    network=$(
        get_xray_transparent_inbounds |
        awk -F '\t' -v tag="$tag" '
            function add_networks(value, count, i, item) {
                gsub(/,/, " ", value)
                gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
                if (value == "") {
                    return
                }

                count = split(value, items, /[[:space:]]+/)
                for (i = 1; i <= count; i++) {
                    item = items[i]
                    if (item != "" && !seen[item]++) {
                        order[++order_count] = item
                    }
                }
            }

            $4 == tag {
                add_networks($3)
            }

            END {
                for (i = 1; i <= order_count; i++) {
                    printf "%s%s", order[i], (i < order_count ? " " : "")
                }
            }
        '
    )

    echo "$network"
}

get_mihomo_listener_field_by_name() {
    listener_name="$1"
    field_name="$2"

    DSCP_FORCE_LISTENER="$listener_name" yq eval ".listeners[] | select(.name == strenv(DSCP_FORCE_LISTENER)) | .$field_name // \"\"" "$mihomo_config" 2>/dev/null | sed -n '1p'
}

get_mihomo_listener_rule_proxy_by_name() {
    listener_name="$1"

    yq eval '.rules[] // ""' "$mihomo_config" 2>/dev/null | awk -F',' -v tag="$listener_name" '
        {
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", $3)
        }
        $1 == "IN-NAME" && $2 == tag { print $3; exit }
    '
}

get_mihomo_listener_network_by_name() {
    listener_name="$1"
    listener_type=$(get_mihomo_listener_field_by_name "$listener_name" "type")

    case "$listener_type" in
        redir)
            echo "tcp"
            ;;
        tproxy)
            udp_enabled=$(get_mihomo_listener_field_by_name "$listener_name" "udp")
            if [ "$udp_enabled" = "true" ]; then
                echo "tcp udp"
            else
                echo "tcp"
            fi
            ;;
        *)
            echo ""
            ;;
    esac
}

# Получение порта для Redirect
get_port_redirect() {
    if [ "$name_client" = "xray" ]; then
        port=$(get_xray_port_by_mode "redirect")
        [ -n "$port" ] && echo "$port" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        port=$(yq eval '.redir-port // ""' "$mihomo_config" 2>/dev/null)
        if [ -z "$port" ]; then
            port=$(DSCP_FORCE_TAG="$dscp_force_proxy_tag" DSCP_FORCE_TAG_REDIRECT="${dscp_force_proxy_tag}-redirect" DSCP_FORCE_TAG_TPROXY="${dscp_force_proxy_tag}-tproxy" yq eval '.listeners[] | select(.type == "redir" and (.name // "") != strenv(DSCP_FORCE_TAG) and (.name // "") != strenv(DSCP_FORCE_TAG_REDIRECT) and (.name // "") != strenv(DSCP_FORCE_TAG_TPROXY)) | .port // ""' "$mihomo_config" 2>/dev/null | sed -n '1p')
        fi
        [ -n "$port" ] && echo "$port" && return 0
    else
        return 1
    fi
}

# Получение порта для TProxy
get_port_tproxy() {
    if [ "$name_client" = "xray" ]; then
        port=$(get_xray_port_by_mode "tproxy")
        [ -n "$port" ] && echo "$port" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        port=$(yq eval '.tproxy-port // ""' "$mihomo_config" 2>/dev/null)
        if [ -z "$port" ]; then
            port=$(DSCP_FORCE_TAG="$dscp_force_proxy_tag" DSCP_FORCE_TAG_REDIRECT="${dscp_force_proxy_tag}-redirect" DSCP_FORCE_TAG_TPROXY="${dscp_force_proxy_tag}-tproxy" yq eval '.listeners[] | select(.type == "tproxy" and (.name // "") != strenv(DSCP_FORCE_TAG) and (.name // "") != strenv(DSCP_FORCE_TAG_REDIRECT) and (.name // "") != strenv(DSCP_FORCE_TAG_TPROXY)) | .port // ""' "$mihomo_config" 2>/dev/null | sed -n '1p')
        fi
        [ -n "$port" ] && echo "$port" && return 0
    else
        return 1
    fi
}

# Получение сети для Redirect
get_network_redirect() {
    if [ "$name_client" = "xray" ]; then
        network=$(get_xray_network_by_mode "redirect")
        [ -n "$network" ] && echo "$network" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        [ -n "$port_redirect" ] && echo "tcp" && return 0
        echo "" && return 0
    else
        return 1
    fi
}

# Получение сети для TProxy
get_network_tproxy() {
    if [ "$name_client" = "xray" ]; then
        network=$(get_xray_network_by_mode "tproxy")
        [ -n "$network" ] && echo "$network" && return 0
    elif [ "$name_client" = "mihomo" ]; then
        if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            echo "udp"
        elif [ -z "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            echo "tcp udp"
        else
            echo ""
        fi
        return 0
    else
        return 1
    fi
}

is_valid_single_port() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
    esac

    [ "$1" -ge 1 ] && [ "$1" -le 65535 ]
}

normalize_network_list() {
    printf '%s\n' "$1" | tr ',' ' ' | tr -s ' ' '\n' | awk '
        $0 == "tcp" || $0 == "udp" {
            if (!seen[$0]++) {
                order[++count] = $0
            }
        }
        END {
            for (i = 1; i <= count; i++) {
                printf "%s%s", order[i], (i < count ? " " : "")
            }
        }
    '
}

resolve_dscp_force_proxy() {
    dscp_force_proxy_status="inactive"
    dscp_force_proxy_reason=""
    port_dscp_force_proxy=""
    mode_dscp_force_proxy=""
    network_dscp_force_proxy=""
    port_dscp_force_proxy_redirect=""
    network_dscp_force_proxy_redirect=""
    port_dscp_force_proxy_tproxy=""
    network_dscp_force_proxy_tproxy=""

    [ -n "$dscp_force_proxy" ] || {
        dscp_force_proxy_status="disabled"
        dscp_force_proxy_reason="метка отключена в конфиге XKeen"
        return 1
    }

    if [ "$mode_proxy" != "TProxy" ] && [ "$mode_proxy" != "Hybrid" ]; then
        dscp_force_proxy_reason="текущий режим ${mode_proxy:-Other} не поддерживается"
        return 1
    fi

    _refresh_modules_cache
    if ! is_module_loaded xt_dscp; then
        dscp_force_proxy_reason="не загружен модуль xt_dscp"
        return 1
    fi

    find_dscp_force_listener() {
        listener_names="$1"

        dscp_force_found_tag=""
        dscp_force_found_port=""
        dscp_force_found_mode=""
        dscp_force_found_network=""
        dscp_force_found_proxy=""

        for listener_name in $listener_names; do
            port_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "port")
            mode_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "type")
            proxy_lookup=$(get_mihomo_listener_field_by_name "$listener_name" "proxy")
            network_lookup=$(normalize_network_list "$(get_mihomo_listener_network_by_name "$listener_name")")
            if [ -n "$port_lookup" ] || [ -n "$mode_lookup" ] || [ -n "$proxy_lookup" ]; then
                dscp_force_found_tag="$listener_name"
                dscp_force_found_port="$port_lookup"
                dscp_force_found_mode="$mode_lookup"
                dscp_force_found_network="$network_lookup"
                dscp_force_found_proxy="$proxy_lookup"
                return 0
            fi
        done

        return 1
    }

    find_dscp_force_inbound() {
        mode_lookup="$1"
        tags_lookup="$2"

        dscp_force_found_tag=""
        dscp_force_found_port=""
        dscp_force_found_network=""

        for tag_lookup in $tags_lookup; do
            port_lookup=$(get_xray_port_by_tag_mode "$tag_lookup" "$mode_lookup")
            network_lookup=$(normalize_network_list "$(get_xray_network_by_tag_mode "$tag_lookup" "$mode_lookup")")
            if [ -n "$port_lookup" ] || [ -n "$network_lookup" ]; then
                dscp_force_found_tag="$tag_lookup"
                dscp_force_found_port="$port_lookup"
                dscp_force_found_network="$network_lookup"
                return 0
            fi
        done

        return 1
    }

    validate_dscp_force_listener() {
        validate_mode="$1"
        validate_required_network="$2"
        validate_names="$3"
        validate_label="$4"

        if ! find_dscp_force_listener "$validate_names"; then
            dscp_force_proxy_reason="не найден ${validate_label} listener для DSCP 61 (ожидается name '${dscp_force_proxy_tag}'"
            case "$validate_mode" in
                redir) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-redirect'" ;;
                tproxy) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-tproxy'" ;;
            esac
            dscp_force_proxy_reason="${dscp_force_proxy_reason}, protocol ${validate_required_network})"
            return 1
        fi

        if [ "$dscp_force_found_mode" != "$validate_mode" ]; then
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' должен иметь type=${validate_mode}"
            return 2
        fi

        if ! is_valid_single_port "$dscp_force_found_port"; then
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' содержит некорректный порт"
            return 2
        fi

        case " $dscp_force_found_network " in
            *" $validate_required_network "*) ;;
            *)
                dscp_force_proxy_reason="listener '${dscp_force_found_tag}' не поддерживает ${validate_required_network}"
                return 2
                ;;
        esac

        if [ -z "$dscp_force_found_proxy" ]; then
            rule_proxy_lookup=$(get_mihomo_listener_rule_proxy_by_name "$dscp_force_found_tag")
            if [ -z "$rule_proxy_lookup" ]; then
                dscp_force_proxy_reason="listener '${dscp_force_found_tag}' должен явно задавать proxy либо иметь правило IN-NAME,${dscp_force_found_tag} в rules"
                return 2
            fi
            dscp_force_found_proxy="$rule_proxy_lookup"
        fi

        return 0
    }

    validate_dscp_force_inbound() {
        validate_mode="$1"
        validate_required_network="$2"
        validate_tags="$3"
        validate_label="$4"

        if ! find_dscp_force_inbound "$validate_mode" "$validate_tags"; then
            dscp_force_proxy_reason="не найден ${validate_label} inbound для DSCP 61 (ожидается tag '${dscp_force_proxy_tag}'"
            case "$validate_mode" in
                redirect) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-redirect'" ;;
                tproxy) dscp_force_proxy_reason="${dscp_force_proxy_reason} или '${dscp_force_proxy_tag}-tproxy'" ;;
            esac
            dscp_force_proxy_reason="${dscp_force_proxy_reason}, protocol ${validate_required_network})"
            return 1
        fi

        if ! is_valid_single_port "$dscp_force_found_port"; then
            dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' содержит некорректный порт"
            return 2
        fi

        case " $dscp_force_found_network " in
            *" $validate_required_network "*) ;;
            *)
                dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' не поддерживает ${validate_required_network}"
                return 2
                ;;
        esac

        return 0
    }

    dscp_force_redirect_names="${dscp_force_proxy_tag}-redirect ${dscp_force_proxy_tag}"
    dscp_force_tproxy_names="${dscp_force_proxy_tag}-tproxy ${dscp_force_proxy_tag}"

    case "$name_client" in
        xray)
            if [ "$mode_proxy" = "Hybrid" ]; then
                validate_dscp_force_inbound "redirect" "tcp" "$dscp_force_redirect_names" "redirect"
                redirect_status=$?
                [ "$redirect_status" -ne 0 ] && return "$redirect_status"

                port_dscp_force_proxy_redirect="$dscp_force_found_port"
                network_dscp_force_proxy_redirect="tcp"

                validate_dscp_force_inbound "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_status=$?
                [ "$tproxy_status" -ne 0 ] && return "$tproxy_status"

                port_dscp_force_proxy_tproxy="$dscp_force_found_port"
                network_dscp_force_proxy_tproxy="udp"

                port_dscp_force_proxy="$port_dscp_force_proxy_tproxy"
                mode_dscp_force_proxy="hybrid"
                network_dscp_force_proxy=$(normalize_network_list "$network_dscp_force_proxy_redirect $network_dscp_force_proxy_tproxy")
                dscp_force_proxy_status="active"
                dscp_force_proxy_reason="Hybrid DSCP 61: tcp -> redirect:${port_dscp_force_proxy_redirect}, udp -> tproxy:${port_dscp_force_proxy_tproxy}"
                return 0
            fi

            validate_dscp_force_inbound "tproxy" "tcp" "$dscp_force_tproxy_names" "tproxy"
            tproxy_tcp_status=$?
            if [ "$tproxy_tcp_status" -ne 0 ]; then
                validate_dscp_force_inbound "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_udp_status=$?
                [ "$tproxy_udp_status" -ne 0 ] && return "$tproxy_udp_status"
            fi

            port_dscp_force_proxy="$dscp_force_found_port"
            mode_dscp_force_proxy="tproxy"
            network_dscp_force_proxy="$dscp_force_found_network"
            port_dscp_force_proxy_tproxy="$dscp_force_found_port"
            network_dscp_force_proxy_tproxy="$dscp_force_found_network"
            dscp_force_proxy_status="active"
            dscp_force_proxy_reason="inbound '${dscp_force_found_tag}' найден: порт ${port_dscp_force_proxy}, network ${network_dscp_force_proxy}"
            return 0
            ;;
        mihomo)
            if [ "$mode_proxy" = "Hybrid" ]; then
                validate_dscp_force_listener "redir" "tcp" "$dscp_force_redirect_names" "redirect"
                redirect_status=$?
                [ "$redirect_status" -ne 0 ] && return "$redirect_status"

                port_dscp_force_proxy_redirect="$dscp_force_found_port"
                network_dscp_force_proxy_redirect="tcp"
                proxy_dscp_force_proxy_redirect="$dscp_force_found_proxy"

                validate_dscp_force_listener "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_status=$?
                [ "$tproxy_status" -ne 0 ] && return "$tproxy_status"

                port_dscp_force_proxy_tproxy="$dscp_force_found_port"
                network_dscp_force_proxy_tproxy="udp"
                proxy_dscp_force_proxy_tproxy="$dscp_force_found_proxy"

                port_dscp_force_proxy="$port_dscp_force_proxy_tproxy"
                mode_dscp_force_proxy="hybrid"
                network_dscp_force_proxy=$(normalize_network_list "$network_dscp_force_proxy_redirect $network_dscp_force_proxy_tproxy")
                dscp_force_proxy_status="active"
                dscp_force_proxy_reason="Hybrid DSCP 61: tcp -> redir:${port_dscp_force_proxy_redirect} (${proxy_dscp_force_proxy_redirect}), udp -> tproxy:${port_dscp_force_proxy_tproxy} (${proxy_dscp_force_proxy_tproxy})"
                return 0
            fi

            validate_dscp_force_listener "tproxy" "tcp" "$dscp_force_tproxy_names" "tproxy"
            tproxy_tcp_status=$?
            if [ "$tproxy_tcp_status" -ne 0 ]; then
                validate_dscp_force_listener "tproxy" "udp" "$dscp_force_tproxy_names" "tproxy"
                tproxy_udp_status=$?
                [ "$tproxy_udp_status" -ne 0 ] && return "$tproxy_udp_status"
            fi

            port_dscp_force_proxy="$dscp_force_found_port"
            mode_dscp_force_proxy="tproxy"
            network_dscp_force_proxy="$dscp_force_found_network"
            port_dscp_force_proxy_tproxy="$dscp_force_found_port"
            network_dscp_force_proxy_tproxy="$dscp_force_found_network"
            dscp_force_proxy_status="active"
            dscp_force_proxy_reason="listener '${dscp_force_found_tag}' найден: порт ${port_dscp_force_proxy}, network ${network_dscp_force_proxy}, proxy ${dscp_force_found_proxy}"
            return 0
            ;;
        *)
            dscp_force_proxy_reason="функция не поддерживается для ${name_client}"
            return 1
            ;;
    esac
}

configure_dscp_force_proxy() {
    resolve_dscp_force_proxy
    status_code=$?

    if [ "$status_code" -eq 2 ]; then
        log_warning_router "$dscp_force_proxy_reason"
        log_warning_terminal "
  DSCP force-proxy '${yellow}${dscp_force_proxy_tag}${reset}' найден, но настроен неверно
  ${light_blue}${dscp_force_proxy_reason}${reset}

  Маршрутизация по DSCP ${green}${dscp_force_proxy}${reset} ${red}отключена${reset}
"
    fi

    return 0
}

print_dscp_force_proxy_status() {
    port_redirect=$(get_port_redirect)
    network_redirect=$(get_network_redirect)
    port_tproxy=$(get_port_tproxy)
    network_tproxy=$(get_network_tproxy)
    mode_proxy=$(get_mode_proxy)

    resolve_dscp_force_proxy >/dev/null 2>&1

    # Проверка DSCP 61
    if [ "$dscp_force_proxy_status" = "active" ]; then
        echo -e "  DSCP ${green}${dscp_force_proxy}${reset}: ${green}активно${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    elif [ "$dscp_force_proxy_status" = "disabled" ]; then
        echo -e "  DSCP 61 force proxy: ${yellow}отключено${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    else
        echo -e "  DSCP ${green}${dscp_force_proxy}${reset}: ${red}не активно${reset} (${light_blue}${dscp_force_proxy_reason}${reset})"
    fi

    # Проверка DSCP 62
    if [ -n "$dscp_exclude" ]; then
        echo -e "  DSCP ${green}$dscp_exclude${reset}: ${green}активно${reset} (${light_blue}исключение из проксирования${reset})"
    else
        echo -e "  DSCP ${green}$dscp_exclude${reset}: ${red}не активно${reset}"
    fi

    # Проверка DSCP 63
    if [ -n "$dscp_proxy" ]; then
        echo -e "  DSCP ${green}$dscp_proxy${reset}: ${green}активно${reset} (${light_blue}проксирование по системым правилам${reset})"
    else
        echo -e "  DSCP ${green}$dscp_proxy${reset}: ${red}не активно${reset}"
    fi
}

# Получение портов исключения из статических пробросов
get_api_exclude_ports() {
    api_redir_result=""

    if [ -n "$api_static_json" ]; then
        api_redir_result=$(echo "$api_static_json" | jq -r '
          [
            .[] | 
            select(.disable != true) | 
            if has("end-port") then 
              "\(.port):\(.["end-port"])" 
            else 
              .port 
            end |
            select(. != "80" and . != "443")
          ] | 
          sort | 
          join(",")')
    fi

    echo "$api_redir_result"
}


# Получение исключенных портов
get_port_exclude() {
    port_exclude_redirect=""
    port_exclude_result=""

    port_exclude_redirect=$(get_api_exclude_ports)

    if [ -n "$port_exclude" ]; then
        if [ -n "$port_exclude_redirect" ]; then
            port_exclude_result="$port_exclude,$port_exclude_redirect"
        else
            port_exclude_result="$port_exclude"
        fi
    else
        port_exclude_result="$port_exclude_redirect"
    fi

    port_exclude_result=$(printf '%s\n' "$port_exclude_result" | tr -dc '0-9,:' | tr -s ',' | sed 's/^,//; s/,$//')
    echo "$port_exclude_result"
}

# Получение исключений IPv4
get_exclude_ip4() {
    [ "$iptables_supported" != "true" ] && return

    # Получаем провайдерский IPv4
    ipv4_eth=$(ip -o route get 195.208.4.1 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p' || \
               ip -o route get 77.88.8.8 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p')
    [ -n "$ipv4_eth" ] && ipv4_eth="${ipv4_eth}/32"
    echo "${ipv4_eth} ${ipv4_exclude}" | tr ' ' '\n' | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/^ //; s/ $//'
}

# Получение исключений IPv6
get_exclude_ip6() {
    [ "$ip6tables_supported" != "true" ] && return

    # Получаем провайдерский IPv6
    ipv6_eth=$(ip -o -6 route get 2a0c:a9c7:8::1 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p' || \
               ip -o -6 route get 2a02:6b8::feed:0ff 2>/dev/null | sed -n 's/.*src \([^ ]*\).*/\1/p')
    [ -n "$ipv6_eth" ] && ipv6_eth="${ipv6_eth}/128"
    echo "${ipv6_eth} ${ipv6_exclude}" | tr ' ' '\n' | awk '!seen[$0]++' | tr '\n' ' ' | sed 's/^ //; s/ $//'
}

# Получение метки политики
get_policy_mark() {
    if [ -n "$api_policy_json" ]; then
        policy_mark=$(echo "$api_policy_json" | jq -r --arg pname "$name_policy" '.[] | select(.description | ascii_downcase == ($pname | ascii_downcase)) | .mark // empty' 2>/dev/null)
    fi

    if [ -n "$policy_mark" ]; then
        echo "0x${policy_mark}"
    else
        echo ""
    fi
}

hex_mark_to_decimal() {
    mark="$1"
    mark="${mark#0x}"
    mark="${mark#0X}"

    case "$mark" in
        ''|*[!0-9a-fA-F]*) return 1 ;;
    esac

    printf '%s\n' "$mark" | awk '
        BEGIN { digits = "0123456789abcdef" }
        {
            value = 0
            mark = tolower($0)
            for (i = 1; i <= length(mark); i++) {
                digit = substr(mark, i, 1)
                pos = index(digits, digit)
                if (pos == 0) {
                    exit 1
                }
                value = value * 16 + pos - 1
            }
            printf "%.0f\n", value
        }
    '
}

# Атомарная синхронизация ipset xkeen_deny_mac с текущим состоянием hotspot API.
# Идемпотентна: создаёт основной набор при первом вызове, в дальнейшем
# наполняет tmp-набор и делает ipset swap. Вызывается на старте XKeen и
# на каждой netfilter.d/schedule.d-инвокации — это даёт динамику без
# `xkeen -restart` при работе Keenetic-расписаний (родительский контроль).
sync_deny_mac_ipset() {
    command -v ipset >/dev/null 2>&1 || return 0
    ipset create "$name_ipset_deny_mac" hash:mac -exist 2>/dev/null || return 0
    _xkeen_deny_tmp="${name_ipset_deny_mac}_tmp"
    ipset create "$_xkeen_deny_tmp" hash:mac -exist 2>/dev/null
    ipset flush "$_xkeen_deny_tmp" >/dev/null 2>&1
    _xkeen_hotspot_json=$(curl_api "${url_server}/${url_hotspot}" 2>/dev/null)
    if [ -n "$_xkeen_hotspot_json" ]; then
        printf '%s' "$_xkeen_hotspot_json" | jq -r '
            ((.host // . // []) |
             (if type == "array" then .[] else . end)) |
            select((.access // "") == "deny" and (.mac // "") != "") |
            .mac
        ' 2>/dev/null | tr '[:lower:]' '[:upper:]' | while IFS= read -r _xkeen_mac; do
            [ -n "$_xkeen_mac" ] && ipset add "$_xkeen_deny_tmp" "$_xkeen_mac" -exist 2>/dev/null
        done
    fi
    ipset swap "$_xkeen_deny_tmp" "$name_ipset_deny_mac" 2>/dev/null
    ipset destroy "$_xkeen_deny_tmp" 2>/dev/null
    unset _xkeen_deny_tmp _xkeen_hotspot_json _xkeen_mac
}

# Получаем пользовательские политики
get_user_policies() {
    [ ! -f "$xkeen_config" ] && return
    jq -r '.xkeen.policy[]? | "\(.name)|\(.port // "")" ' "$xkeen_config" 2>/dev/null
}

# Проверка на конфликт имен политик
check_policy_name_conflict() {
    if [ -f "$xkeen_config" ]; then
        conflict=$(jq -r --arg main "$name_policy" '.xkeen.policy[] | select((.name | ascii_downcase) == ($main | ascii_downcase)) | .name' "$xkeen_config" 2>/dev/null | head -n 1)

        if [ -n "$conflict" ]; then
            log_error_router "Ошибка конфигурации: Имя политики в xkeen.json совпадает с зарезервированным"
            log_error_terminal "
  В файле '${yellow}xkeen.json${reset}' найдена политика с именем '${red}${conflict}${reset}'
  Это имя зарезервировано основной службой XKeen

  Переименуйте пользовательскую политику в json-файле
  Запуск ${yellow}$name_client${reset} ${red}отменен${reset}
"
        fi
    fi
}

# Получаем порты пользовательских политик
resolve_user_policies() {
    [ -f "$xkeen_config" ] && [ -n "$api_policy_json" ] || return

    api_exclude_ports=$(get_api_exclude_ports)

    # Получаем сопоставленные политики одним вызовом jq
    matched_policies=$(printf '%s' "$api_policy_json" | jq -r --argjson user_cfg "$(cat "$xkeen_config")" '
        ($user_cfg.xkeen.policy // []) as $up |
        .[] as $api |
        $up[] | 
        select(
            (.name // "" | ascii_downcase) == 
            ($api.description // "" | ascii_downcase)
        ) |
        "\(.name)|\($api.mark // "")|\(.port // "")"
    ' 2>/dev/null)

    [ -z "$matched_policies" ] && return

    # Обрабатываем каждую политику в одном цикле
    echo "$matched_policies" | while IFS='|' read -r pname mark pports; do
        if [ -z "$pports" ]; then
            # Порты не указаны -> режим "all" (все порты)
            if [ -n "$api_exclude_ports" ]; then
                echo "${pname}|${mark}|exclude|${api_exclude_ports}"
            else
                echo "${pname}|${mark}|all|"
            fi
        else
            case "$pports" in
                !*) mode="exclude"; ports="${pports#!}"
                    [ -n "$api_exclude_ports" ] && ports="${ports:+$ports,}$api_exclude_ports" ;;
                *) mode="include"; ports="$pports"
                    if [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ]; then
                        case ",$ports," in
                            *,53,*) ;;
                            *) ports="53,$ports" ;;
                        esac
                    fi
                    ;;
            esac

            clean_ports=$(validate_and_clean_ports "$ports")
            [ -n "$clean_ports" ] && echo "${pname}|${mark}|${mode}|${clean_ports}"
        fi
    done
}

# Получение режима прокси-клиента
get_mode_proxy() {
    if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
        mode_proxy="Hybrid"
    elif [ -n "$port_tproxy" ]; then
        mode_proxy="TProxy"
    elif [ -n "$port_redirect" ]; then
        mode_proxy="Redirect"
    else
        mode_proxy="Other"
    fi
    echo "$mode_proxy"
}

# Настройка брандмауэра
configure_firewall() {
    : > "$file_netfilter_hook"

    # Pre-evaluate dynamic variables
    val_exclude_ip6="$(get_exclude_ip6)"
    val_exclude_ip4="$(get_exclude_ip4)"

    cat > "$file_netfilter_hook" <<'EOL'
#!/bin/sh
# XKeen: Auto-generated file. DO NOT EDIT!
[ -f /tmp/xkeen_ready ] || exit 0
EOL

    # Securely inject variables into the script
    inject_var() {
        local name="$1"
        local val="$2"
        local safe_val
        safe_val="${val//\'/\'\\\'\'}"
        printf "%s='%s'\n" "$name" "$safe_val" >> "$file_netfilter_hook"
    }

    inject_var name_client "$name_client"
    inject_var name_profile "$name_profile"
    inject_var mode_proxy "$mode_proxy"
    inject_var network_redirect "$network_redirect"
    inject_var network_tproxy "$network_tproxy"
    inject_var networks "$networks"
    inject_var name_chain "$name_chain"
    inject_var port_redirect "$port_redirect"
    inject_var port_tproxy "$port_tproxy"
    inject_var port_dscp_force_proxy "$port_dscp_force_proxy"
    inject_var port_dscp_force_proxy_redirect "$port_dscp_force_proxy_redirect"
    inject_var port_dscp_force_proxy_tproxy "$port_dscp_force_proxy_tproxy"
    inject_var port_donor "$port_donor"
    inject_var port_exclude "$port_exclude"
    inject_var policy_mark "$policy_mark"
    inject_var comment_tag "$comment_tag"
    inject_var comment "$comment"
    inject_var custom_mark "$custom_mark"
    inject_var dscp_exclude "$dscp_exclude"
    inject_var dscp_proxy "$dscp_proxy"
    inject_var dscp_force_proxy "$dscp_force_proxy"
    inject_var dscp_force_proxy_tag "$dscp_force_proxy_tag"
    inject_var mode_dscp_force_proxy "$mode_dscp_force_proxy"
    inject_var network_dscp_force_proxy "$network_dscp_force_proxy"
    inject_var network_dscp_force_proxy_redirect "$network_dscp_force_proxy_redirect"
    inject_var network_dscp_force_proxy_tproxy "$network_dscp_force_proxy_tproxy"
    inject_var user_policies "$user_policies"
    inject_var table_redirect "$table_redirect"
    inject_var table_tproxy "$table_tproxy"
    inject_var table_mark "$table_mark"
    inject_var table_id "$table_id"
    inject_var status_file "$status_file"
    inject_var file_dns "$file_dns"
    inject_var file_cpu "$file_cpu"
    inject_var file_ca "$file_ca"
    inject_var proxy_dns "$proxy_dns"
    inject_var proxy_router "$proxy_router"
    inject_var directory_configs_app "$directory_configs_app"
    inject_var directory_xray_config "$directory_xray_config"
    inject_var directory_xray_asset "$directory_xray_asset"
    inject_var iptables_supported "$iptables_supported"
    inject_var ip6tables_supported "$ip6tables_supported"
    inject_var arm64_fd "$arm64_fd"
    inject_var other_fd "$other_fd"
    inject_var aghfix "$aghfix"
    
    inject_var ipv6_proxy "$ipv6_proxy"
    inject_var ipv4_proxy "$ipv4_proxy"
    inject_var val_exclude_ip6 "$val_exclude_ip6"
    inject_var val_exclude_ip4 "$val_exclude_ip4"
    inject_var name_ipset_deny_mac "$name_ipset_deny_mac"
    inject_var url_server "$url_server"
    inject_var url_hotspot "$url_hotspot"

    cat >> "$file_netfilter_hook" <<'EOL'

# Перезапуск скрипта
restart_script() {
    exec /bin/sh "$0" "$@"
}

if pidof "$name_client" >/dev/null; then

    # Динамическая синхронизация ipset с deny-MAC из hotspot API.
    # Закрывает обход built-in политики «Без доступа в интернет» при включенном
    # проксировании: PREROUTING на эти MAC делает RETURN до TPROXY, пакет идёт
    # в FORWARD, где штатно дропается NDM-цепочкой _NDM_HOTSPOT_FWD.
    # Хук перезапускается NDM при netfilter rewrite, schedule.d дёргает этот же
    # скрипт на start/stop расписаний — список MAC всегда актуален.
    _xkeen_sync_deny_mac_ipset() {
        command -v ipset >/dev/null 2>&1 || return 0
        ipset create "$name_ipset_deny_mac" hash:mac -exist 2>/dev/null || return 0
        _tmp="${name_ipset_deny_mac}_tmp"
        ipset create "$_tmp" hash:mac -exist 2>/dev/null
        ipset flush "$_tmp" >/dev/null 2>&1
        _hjson=$(curl --connect-timeout 2 -m 5 -kfsS "${url_server}/${url_hotspot}" 2>/dev/null)
        if [ -n "$_hjson" ]; then
            printf '%s' "$_hjson" | jq -r '
                ((.host // . // []) |
                 (if type == "array" then .[] else . end)) |
                select((.access // "") == "deny" and (.mac // "") != "") |
                .mac
            ' 2>/dev/null | tr '[:lower:]' '[:upper:]' | while IFS= read -r _m; do
                [ -n "$_m" ] && ipset add "$_tmp" "$_m" -exist 2>/dev/null
            done
        fi
        ipset swap "$_tmp" "$name_ipset_deny_mac" 2>/dev/null
        ipset destroy "$_tmp" 2>/dev/null
    }
    _xkeen_sync_deny_mac_ipset

    # Аккумулируем правила в строки, применяем атомарно одним
    # iptables-restore --noflush на (family, table) в _xkeen_apply.
    # Сохраняем семантику старого ipt() для всех существующих helper'ов.
    _xkeen_v4_nat_rules=""
    _xkeen_v4_mangle_rules=""
    _xkeen_v6_nat_rules=""
    _xkeen_v6_mangle_rules=""

    ipt() {
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && return 0
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && return 0

        case "$1" in
            -A|-I|-D)
                _line=$*
                case "${family}_${table}" in
                    iptables_nat)     _xkeen_v4_nat_rules="${_xkeen_v4_nat_rules}${_line}
" ;;
                    iptables_mangle)  _xkeen_v4_mangle_rules="${_xkeen_v4_mangle_rules}${_line}
" ;;
                    ip6tables_nat)    _xkeen_v6_nat_rules="${_xkeen_v6_nat_rules}${_line}
" ;;
                    ip6tables_mangle) _xkeen_v6_mangle_rules="${_xkeen_v6_mangle_rules}${_line}
" ;;
                esac
                return 0
                ;;
            *)
                # Прочие операции (-F, -X) - в реальный iptables.
                if [ "$family" = "iptables" ]; then
                    iptables -w -t "$table" "$@"
                else
                    ip6tables -w -t "$table" "$@"
                fi
                return $?
                ;;
        esac
    }

    # Применяет аккумулированные правила одной таблицы атомарно через
    # iptables-restore --noflush. Custom chain $name_chain flush'ится
    # объявлением ":$name_chain -" перед добавлением новых правил.
    _xkeen_apply_table() {
        _family="$1"
        _table="$2"
        _rules_var="$3"

        eval "_rules=\${$_rules_var}"
        [ -z "$_rules" ] && return 0

        # Удаляем устаревшие xkeen-tagged правила из built-in/system chain'ов
        # (PREROUTING, OUTPUT, _NDM_HOTSPOT_DNSREDIR), правила из самой $name_chain
        # игнорируются - там ":chain -" в blob их сам flush'ит.
        save_cmd=""
        [ "$_family" = "iptables" ] && [ "$iptables_supported" = "true" ] && save_cmd="iptables-save"
        [ "$_family" = "ip6tables" ] && [ "$ip6tables_supported" = "true" ] && save_cmd="ip6tables-save"
        [ -z "$save_cmd" ] && { _deletes=""; return; }

        _deletes=$($save_cmd -t "$_table" 2>/dev/null | awk \
            -v tag="$comment_tag" \
            -v c1="$name_chain" \
            -v c2="${name_chain}_out" \
            -v c3="${name_chain}_force" '
            index($0, tag) &&
            $1 == "-A" &&
            $2 != c1 &&
            $2 != c2 &&
            $2 != c3 {
                sub(/^-A /, "-D ")
                print
            }
        ')

        {
            printf '*%s\n' "$_table"
            printf ':%s -\n' "$name_chain"
            [ -n "$port_dscp_force_proxy" ] && printf ':%s_force -\n' "$name_chain"
            [ "$proxy_router" = "on" ] && printf ':%s_out -\n' "$name_chain"
            [ -n "$_deletes" ] && printf '%s\n' "$_deletes"
            printf '%s' "$_rules"
            printf 'COMMIT\n'
        } | if [ "$_family" = "iptables" ]; then
            iptables-restore --noflush 2>/dev/null
        else
            ip6tables-restore --noflush 2>/dev/null
        fi
    }

    _xkeen_apply() {
        [ "$iptables_supported" = "true" ] && _xkeen_apply_table iptables nat _xkeen_v4_nat_rules || true
        [ "$iptables_supported" = "true" ] && _xkeen_apply_table iptables mangle _xkeen_v4_mangle_rules || true
        [ "$ip6tables_supported" = "true" ] && _xkeen_apply_table ip6tables nat _xkeen_v6_nat_rules || true
        [ "$ip6tables_supported" = "true" ] && _xkeen_apply_table ip6tables mangle _xkeen_v6_mangle_rules || true
    }

    # Добавление правил-исключений
    add_exclude_rules() {
        chain="$1"
        for exclude in $exclude_list; do
            if [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && [ "$chain" != "${name_chain}_out" ]; then
                case "$exclude" in
                    10.0.0.0/8|172.16.0.0/12|192.168.0.0/16|fd00::/8|fe80::/10)
                    if [ "$table" = "mangle" ] && [ "$mode_proxy" = "Hybrid" ]; then
                        ipt -A "$chain" -d "$exclude" -p tcp --dport 53 $comment -j RETURN >/dev/null 2>&1
                        ipt -A "$chain" -d "$exclude" -p udp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                    elif [ "$table" = "nat" ] && [ "$mode_proxy" = "Hybrid" ]; then
                        ipt -A "$chain" -d "$exclude" -p tcp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                        ipt -A "$chain" -d "$exclude" -p udp --dport 53 $comment -j RETURN >/dev/null 2>&1
                    elif [ "$table" = "mangle" ] && [ "$mode_proxy" = "TProxy" ]; then
                        ipt -A "$chain" -d "$exclude" -p tcp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                        ipt -A "$chain" -d "$exclude" -p udp ! --dport 53 $comment -j RETURN >/dev/null 2>&1
                    fi
                    ;;
                esac
            else
                ipt -A "$chain" -d "$exclude" $comment -j RETURN >/dev/null 2>&1
            fi
        done
    }

    add_ipset_exclude() {
        base_set="$1"
        set_type="${2:-hash:net}"

        if [ "$family" = "ip6tables" ]; then
            set_name="${base_set}6"
            ipset_family="inet6"
        else
            set_name="$base_set"
            ipset_family="inet"
        fi

        ipset create "$set_name" "$set_type" family "$ipset_family" -exist || return

        ipt -I "$chain" 1 -m set --match-set "$set_name" dst $comment -j RETURN >/dev/null 2>&1
    }

    add_geo_exclude() {
        if [ "$family" = "ip6tables" ]; then
            geo_set="geo_exclude6"
            override_set="geo_override6"
            ipset_family="inet6"
        else
            geo_set="geo_exclude"
            override_set="geo_override"
            ipset_family="inet"
        fi

        ipset create "$geo_set" hash:net family "$ipset_family" -exist
        ipset create "$override_set" hash:net family "$ipset_family" -exist

        ipt -I "$chain" 1 -m set --match-set "$geo_set" dst -m set ! --match-set "$override_set" dst $comment -j RETURN >/dev/null 2>&1
    }

    add_force_exclude_rules() {
        chain="$1"
        for exclude in $exclude_list; do
            ipt -A "$chain" -d "$exclude" $comment -j RETURN >/dev/null 2>&1
        done
    }

    # Добавление правил iptables
    add_ipt_rule() {
        family="$1"
        table="$2"
        chain="$3"
        shift 3
        [ "$family" = "iptables" ] && [ "$iptables_supported" = "false" ] && return
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" = "false" ] && return

        # Custom chain создаётся/flush'ится одной строкой ":$name_chain -" в blob,
        # поэтому ни -nL guard, ни -N не нужны - всегда заполняем body.
        add_exclude_rules "$chain"

        if [ "$table" = "$table_tproxy" ]; then
            if [ "$mode_proxy" = "Hybrid" ]; then
                set -- -p udp -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark
            else
                set -- -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark
            fi
            ipt -I "$chain" 1 "$@" >/dev/null 2>&1
        fi

        case "$mode_proxy" in
            Hybrid)
                if [ "$table" = "$table_redirect" ]; then
                    ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                    add_ipset_exclude ext_exclude hash:ip
                    add_ipset_exclude user_exclude hash:net
                    add_geo_exclude
                    ipt -A "$chain" -p tcp $comment -j REDIRECT --to-port "$port_redirect" >/dev/null 2>&1
                else
                    ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                    add_ipset_exclude ext_exclude hash:ip
                    add_ipset_exclude user_exclude hash:net
                    add_geo_exclude
                    ipt -A "$chain" -p udp -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                    ipt -A "$chain" -p udp -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                    ipt -A "$chain" -p udp $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
                fi
                ;;
            TProxy)
                ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                add_ipset_exclude ext_exclude hash:ip
                add_ipset_exclude user_exclude hash:net
                add_geo_exclude
                for net in $network_tproxy; do
                    ipt -A "$chain" -p "$net" -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                    ipt -A "$chain" -p "$net" -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                    ipt -A "$chain" -p "$net" $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
                done
                ;;
            Redirect)
                ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
                add_ipset_exclude ext_exclude hash:ip
                add_ipset_exclude user_exclude hash:net
                add_geo_exclude
                for net in $network_redirect; do
                    ipt -A "$chain" -p "$net" $comment -j REDIRECT --to-port "$port_redirect" >/dev/null 2>&1
                done
                ;;
            *) exit 0 ;;
        esac

        if [ -n "$dscp_exclude" ]; then
            for dscp in $dscp_exclude; do
                ipt -I "$chain" -m dscp --dscp "$dscp" $comment -j RETURN >/dev/null 2>&1
            done
        fi

        # DSCP force-proxy обрабатывается отдельной chain'ой xkeen_force в
        # dedicated PREROUTING path'е соответствующей таблицы. Если не выйти
        # здесь из обычной chain для тех же протоколов, пакет позже попадёт в
        # штатный REDIRECT/TPROXY path и потеряет original dst.
        if [ "$table" = "$table_redirect" ] && [ -n "$port_dscp_force_proxy_redirect" ]; then
            for net in $network_dscp_force_proxy_redirect; do
                ipt -I "$chain" 1 -p "$net" -m dscp --dscp "$dscp_force_proxy" $comment -j RETURN >/dev/null 2>&1
            done
        fi

        if [ "$table" = "$table_tproxy" ] && [ -n "$port_dscp_force_proxy_tproxy" ]; then
            for net in $network_dscp_force_proxy_tproxy; do
                ipt -I "$chain" 1 -p "$net" -m dscp --dscp "$dscp_force_proxy" $comment -j RETURN >/dev/null 2>&1
            done
        fi
    }

    add_force_ipt_rule() {
        family="$1"
        table="$2"
        chain="$3"

        [ "$family" = "iptables" ] && [ "$iptables_supported" = "false" ] && return
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" = "false" ] && return

        if [ "$table" = "$table_redirect" ]; then
            [ -n "$port_dscp_force_proxy_redirect" ] || return
        elif [ "$table" = "$table_tproxy" ]; then
            [ -n "$port_dscp_force_proxy_tproxy" ] || return
        else
            return
        fi

        add_force_exclude_rules "$chain"

        ipt -I "$chain" 1 -m conntrack --ctstate DNAT $comment -j RETURN >/dev/null 2>&1
        ipt -I "$chain" 1 -m conntrack --ctstate INVALID $comment -j RETURN >/dev/null 2>&1

        if [ "$table" = "$table_redirect" ]; then
            for net in $network_dscp_force_proxy_redirect; do
                ipt -A "$chain" -p "$net" $comment -j REDIRECT --to-port "$port_dscp_force_proxy_redirect" >/dev/null 2>&1
            done
        else
            ipt -I "$chain" 1 -m conntrack --ctstate ESTABLISHED,RELATED $comment -j CONNMARK --restore-mark >/dev/null 2>&1
            for net in $network_dscp_force_proxy_tproxy; do
                ipt -A "$chain" -p "$net" -m socket --transparent $comment -j MARK --set-mark "$table_mark" >/dev/null 2>&1
                ipt -A "$chain" -p "$net" -m mark ! --mark 0 $comment -j CONNMARK --save-mark >/dev/null 2>&1
                ipt -A "$chain" -p "$net" $comment -j TPROXY --on-ip "$proxy_ip" --on-port "$port_dscp_force_proxy_tproxy" --tproxy-mark "$table_mark" >/dev/null 2>&1
            done
        fi
    }

    # Настройка таблицы маршрутов
    configure_route() {
        ip_version="$1"

        # Определяем таблицу маршрутизации
        if [ -n "$policy_mark" ]; then
            policy_table=$(ip rule show | awk -v policy="$policy_mark" '$0 ~ policy && /lookup/ && !/blackhole/ {print $(NF); exit}')
        fi
        source_table="${policy_table:-main}"

        # Проверяем есть ли default маршрут
        check_default() {
            if [ "$ip_version" = "6" ] && ! ip -6 route show default 2>/dev/null | grep -q .; then
                return 0
            fi
            if [ "$source_table" = "main" ]; then
                ip -"$ip_version" route show default 2>/dev/null | grep -q '^default'
            else
                ip -"$ip_version" route show table all 2>/dev/null | grep -E "^[[:space:]]*default .* table $policy_table([[:space:]]|$)" | grep -vq 'unreachable' >/dev/null
            fi
        }

        attempts=0
        max_attempts=4
        until check_default; do
            attempts=$((attempts + 1))
            if [ "$attempts" -ge "$max_attempts" ]; then
                [ "$ip_version" = "4" ] && touch "/tmp/noinet"
                return 1
            fi
            sleep 1
        done
        [ "$ip_version" = "4" ] && rm -f "/tmp/noinet"

        ip -"$ip_version" rule del fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" route flush table "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" route add local default dev lo table "$table_id" >/dev/null 2>&1 || true
        ip -"$ip_version" rule add fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1 || true

        # Копируем маршруты
        ip -"$ip_version" route show table "$source_table" 2>/dev/null | while read -r route_line; do
            case "$route_line" in
                default*|unreachable*|blackhole*) continue ;;
                *) ip -"$ip_version" route add table "$table_id" $route_line >/dev/null 2>&1 || true ;;
            esac
        done
        return 0
    }

    # Создание множественных правил multiport
    add_multiport_rules() {
        family="$1"
        table="$2"
        net="$3"
        mark="$4"
        ports="$5"
        target="$6"

        [ -z "$ports" ] && return

        num_ports=$(echo "$ports" | tr ',' '\n' | wc -l)
        i=1
        while [ "$i" -le "$num_ports" ]; do
            end=$((i + 6))
            chunk=$(echo "$ports" | tr ',' '\n' | sed -n "${i},${end}p" | tr '\n' ',' | sed 's/,$//')
            [ -z "$chunk" ] && break
            if [ -n "$mark" ]; then
                set -- -m connmark --mark "$mark" -m conntrack ! --ctstate INVALID -p "$net" -m multiport --dports "$chunk" $comment -j "$target"
            else
                set -- -m conntrack ! --ctstate INVALID -p "$net" -m multiport --dports "$chunk" $comment -j "$target"
            fi
            ipt -A PREROUTING "$@" >/dev/null 2>&1
            i=$((i + 7))
        done
    }

    # Добавление цепочек PREROUTING
    add_prerouting() {
        family="$1"
        table="$2"

        # MAC-bypass для built-in «Без доступа в интернет»: RETURN из PREROUTING
        # до xkeen-jumps, пакет минует TPROXY/REDIRECT/MARK и попадает в FORWARD,
        # где NDM-цепочка _NDM_HOTSPOT_FWD его дропнет штатно. -m mac --mac-source
        # видит L2-MAC только для устройств в одном broadcast-домене с роутером
        # (LAN/Wi-Fi/guest-bridge); за L3-VLAN правило безвредно неактивно.
        ipt -I PREROUTING 1 -m set --match-set "$name_ipset_deny_mac" src $comment -j RETURN >/dev/null 2>&1

        if [ "$table" = "$table_redirect" ] && [ -n "$port_dscp_force_proxy_redirect" ]; then
            for force_net in $network_dscp_force_proxy_redirect; do
                set -- -m conntrack ! --ctstate INVALID -p "$force_net" -m dscp --dscp "$dscp_force_proxy" $comment -j "${name_chain}_force"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done
        fi

        if [ "$table" = "$table_tproxy" ] && [ -n "$port_dscp_force_proxy_tproxy" ]; then
            for force_net in $network_dscp_force_proxy_tproxy; do
                set -- -m conntrack ! --ctstate INVALID -p "$force_net" -m dscp --dscp "$dscp_force_proxy" $comment -j "${name_chain}_force"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done
        fi

        for net in $networks; do
            if [ "$mode_proxy" = "Hybrid" ]; then
                [ "$table" = "nat"    ] && [ "$net" != "tcp" ] && continue
                [ "$table" = "mangle" ] && [ "$net" != "udp" ] && continue
            fi

            proto_match="-p $net"
            all_ports_proto_match=""
            [ "$mode_proxy" = "TProxy" ] && all_ports_proto_match="$proto_match"

            for dscp in $dscp_proxy; do
                set -- -m conntrack ! --ctstate INVALID $proto_match -m dscp --dscp "$dscp" $comment -j "$name_chain"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            done

            if [ "$proxy_router" = "on" ]; then
                set -- -i lo -m mark --mark "$table_mark" $proto_match $comment -j "$name_chain"
                ipt -A PREROUTING "$@" >/dev/null 2>&1
            fi

            # Пользовательские политики из xkeen.json
            # Heredoc вместо echo|while - while должен исполниться в parent shell,
            # чтобы аккумуляторы _xkeen_*_rules в ipt() модифицировались в нужном scope.
            while IFS='|' read -r pname pmark pmode pports; do
                [ -z "$pmark" ] && continue

                pmark=$(echo "$pmark" | tr -d ' \r\n')
                pmode=$(echo "$pmode" | tr -d ' \r\n')
                pports=$(echo "$pports" | tr -d ' \r\n')

                if [ "$pmode" = "all" ]; then
                    set -- -m connmark --mark 0x"$pmark" -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                elif [ "$pmode" = "include" ]; then
                    add_multiport_rules "$family" "$table" "$net" "0x$pmark" "$pports" "$name_chain"
                elif [ "$pmode" = "exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "0x$pmark" "$pports" "RETURN"
                    set -- -m connmark --mark 0x"$pmark" -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            done <<USER_POLICIES_EOF
$user_policies
USER_POLICIES_EOF

            # Политика xkeen (стандартная)
            if [ -n "$policy_mark" ]; then
                # заданы порты проксирования
                if [ -n "$port_donor" ]; then
                    add_multiport_rules "$family" "$table" "$net" "$policy_mark" "$port_donor" "$name_chain"
                # заданы порты исключения
                elif [ -n "$port_exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "$policy_mark" "$port_exclude" "RETURN"
                    set -- -m connmark --mark "$policy_mark" -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                else
                    # Политика xkeen, когда порты не указаны (проксирование на всех портах)
                    set -- -m connmark --mark "$policy_mark" -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            # НЕТ политики xkeen
            else
                # заданы порты проксирования
                if [ -n "$port_donor" ]; then
                    add_multiport_rules "$family" "$table" "$net" "" "$port_donor" "$name_chain"
                # заданы порты исключения
                elif [ -n "$port_exclude" ]; then
                    add_multiport_rules "$family" "$table" "$net" "" "$port_exclude" "RETURN"
                    set -- -m conntrack ! --ctstate INVALID -p "$net" $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                # Если нет ни xkeen, ни пользовательских политик -> перехватываем всё
                else
                    set -- -m conntrack ! --ctstate INVALID $all_ports_proto_match $comment -j "$name_chain"
                    ipt -A PREROUTING "$@" >/dev/null 2>&1
                fi
            fi
        done
    }

    # Добавление цепочек для проксирования трафика Entware
    add_output() {
        family="$1"
        table="$2"

        [ "$proxy_router" != "on" ] && return

        out_chain="${name_chain}_out"

        # ":${name_chain}_out -" в blob создаст/flush'ит chain атомарно,
        # body заполняется всегда.
        orig_chain="$chain"
        chain="$out_chain"

        ipt -A "$out_chain" -o lo $comment -j RETURN >/dev/null 2>&1
        ipt -A "$out_chain" -m mark --mark 255 $comment -j RETURN >/dev/null 2>&1
        policy_bypass_marks="$policy_mark"

        if [ -n "$user_policies" ]; then
            user_policy_marks=$(printf '%s\n' "$user_policies" | awk -F'|' '$2 != "" {print "0x"$2}')
            policy_bypass_marks="$policy_bypass_marks $user_policy_marks"
        fi

        for bypass_mark in $policy_bypass_marks; do
            [ -n "$bypass_mark" ] && ipt -A "$out_chain" -m mark --mark "$bypass_mark" $comment -j RETURN >/dev/null 2>&1
        done

        add_exclude_rules "$out_chain"

        add_ipset_exclude ext_exclude hash:ip
        add_ipset_exclude user_exclude hash:net
        add_geo_exclude

        chain="$orig_chain"

        for net in $networks; do
            if [ "$mode_proxy" = "Hybrid" ]; then
                [ "$table" = "nat"    ] && [ "$net" != "tcp" ] && continue
                [ "$table" = "mangle" ] && [ "$net" != "udp" ] && continue
            fi

            proto_match="-p $net"

            set -- -m conntrack ! --ctstate INVALID $proto_match $comment -j "$out_chain"
            ipt -A OUTPUT "$@" >/dev/null 2>&1

            if [ "$table" = "$table_redirect" ]; then
                set -- -p "$net" $comment -j REDIRECT --to-port "$port_redirect"
                ipt -A "$out_chain" "$@" >/dev/null 2>&1
            elif [ "$table" = "$table_tproxy" ]; then
                set -- -p "$net" $comment -j MARK --set-mark "$table_mark"
                ipt -A "$out_chain" "$@" >/dev/null 2>&1
            fi
        done
    }

    dns_redir() {
        family="$1"
        table="nat"

        [ "$aghfix" != "on" ] && return
        [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && return

        all_marks=""
        [ -n "$policy_mark" ] && all_marks="$policy_mark"

        [ -n "$custom_mark" ] && all_marks="$custom_mark $all_marks"

        if [ -n "$user_policies" ]; then
            user_marks=$(echo "$user_policies" | awk -F'|' '{if ($2 != "") print "0x"$2}')
            all_marks="$all_marks $user_marks"
        fi

        for mark in $all_marks; do
            mark=$(echo "$mark" | tr -d ' \r\n')
            [ -z "$mark" ] && continue

            for proto in udp tcp; do
                set -- -p "$proto" -m mark --mark "$mark" -m pkttype --pkt-type unicast -m "$proto" --dport 53 $comment -j REDIRECT --to-ports 53
                ipt -I _NDM_HOTSPOT_DNSREDIR "$@" >/dev/null 2>&1
            done
        done
    }

    if [ -n "$port_donor" ] || [ -n "$port_exclude" ]; then
        [ "$file_dns" = "true" ] && [ "$proxy_dns" = "on" ] && [ -n "$port_donor" ] && port_donor="53,$port_donor"
    fi
    for family in iptables ip6tables; do

        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && continue
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && continue

        if [ "$family" = "ip6tables" ]; then
            exclude_list="$val_exclude_ip6"
            proxy_ip="$ipv6_proxy"
            configure_route 6
        else
            exclude_list="$val_exclude_ip4"
            proxy_ip="$ipv4_proxy"
            configure_route 4
        fi
        if [ -n "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            for table in "$table_tproxy" "$table_redirect"; do
                add_ipt_rule "$family" "$table" "$name_chain"
                add_force_ipt_rule "$family" "$table" "${name_chain}_force"
                add_prerouting "$family" "$table"
                add_output "$family" "$table"
            done
        elif [ -z "$port_redirect" ] && [ -n "$port_tproxy" ]; then
            table="$table_tproxy"
            add_ipt_rule "$family" "$table" "$name_chain"
            add_force_ipt_rule "$family" "$table" "${name_chain}_force"
            add_prerouting "$family" "$table"
            add_output "$family" "$table"
        elif [ -n "$port_redirect" ] && [ -z "$port_tproxy" ]; then
            table="$table_redirect"
            add_ipt_rule "$family" "$table" "$name_chain"
            add_prerouting "$family" "$table"
            add_output "$family" "$table"
        fi

        dns_redir "$family"
    done

    # Атомарно применяем все аккумулированные правила одним
    # iptables-restore --noflush per (family, table).
    _xkeen_apply
else
    [ -f "/tmp/xkeen_starting.lock" ] && exit 0
    touch "/tmp/xkeen_starting.lock"
    . "$file_cpu"
    info_cpu

    fd_limit="$other_fd"
    [ "$architecture" = "arm64-v8a" ] && fd_limit="$arm64_fd"
    ulimit -SHn "$fd_limit"

    export SSL_CERT_FILE="$file_ca"
    case "$name_client" in
        xray)
            export XRAY_LOCATION_CONFDIR="$directory_xray_config"
            export XRAY_LOCATION_ASSET="$directory_xray_asset"
            "$name_client" run >/dev/null 2>&1 &
        ;;
        mihomo)
            export CLASH_HOME_DIR="$directory_configs_app"
            "$name_client" >/dev/null 2>&1 &
        ;;
    esac
    _probe=0
    while [ "$_probe" -lt 60 ]; do
        pidof "$name_client" >/dev/null 2>&1 && break
        _probe=$((_probe + 1))
        usleep 100000
    done
    unset _probe
    rm -f "/tmp/xkeen_starting.lock"
    if pidof "$name_client" >/dev/null; then
        restart_script "$@"
    else
        exit 1
    fi
fi
EOL
    sed -i '1,2!{/^[[:space:]]*#/d; /^[[:space:]]*$/d}' "$file_netfilter_hook"
    chmod 700 "$file_netfilter_hook"

    # Schedule.d-хук: NDM вызывает scripts/schedule.d при start/stop расписаний
    # (родительский контроль). Хук дёргает netfilter.d/proxy.sh, который
    # ре-синхронизирует ipset deny-MAC из актуального hotspot API.
    mkdir -p "$(dirname "$file_schedule_hook")" 2>/dev/null
    cat > "$file_schedule_hook" <<'SCHEDULE_EOL'
#!/bin/sh
# XKeen: re-sync deny MAC ipset on schedule start/stop. Auto-generated. DO NOT EDIT!
[ "$1" = "start" ] || [ "$1" = "stop" ] || exit 0
[ -x /opt/etc/ndm/netfilter.d/proxy.sh ] && /opt/etc/ndm/netfilter.d/proxy.sh
SCHEDULE_EOL
    chmod 755 "$file_schedule_hook"

    sh "$file_netfilter_hook"
}

# Удаление правил iptables
clean_firewall() {
    [ -f "$file_netfilter_hook" ] && : > "$file_netfilter_hook"

    get_ipver_support

    for family in iptables ip6tables; do
        [ "$family" = "iptables" ] && [ "$iptables_supported" != "true" ] && continue
        [ "$family" = "ip6tables" ] && [ "$ip6tables_supported" != "true" ] && continue

        if "$family" -w -t nat -nL _NDM_HOTSPOT_DNSREDIR >/dev/null 2>&1; then
            "$family" -w -t nat -S _NDM_HOTSPOT_DNSREDIR | grep -E -- "$comment_tag" | sed 's/^-A /-D /' | while IFS= read -r rule; do
                [ -n "$rule" ] && "$family" -w -t nat $rule >/dev/null 2>&1
            done
        fi
    done

    clean_run() {
        family="$1"
        table="$2"
        name_chain="$3"

        for sys_chain in PREROUTING OUTPUT; do
            "$family" -w -t "$table" -S "$sys_chain" 2>/dev/null | grep -E -- "$comment_tag" | sed 's/^-A /-D /' | while IFS= read -r rule; do
                [ -n "$rule" ] && "$family" -w -t "$table" $rule >/dev/null 2>&1
            done
        done

        if "$family" -w -t "$table" -nL "$name_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$name_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$name_chain" >/dev/null 2>&1
        fi

        out_chain="${name_chain}_out"
        if "$family" -w -t "$table" -nL "$out_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$out_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$out_chain" >/dev/null 2>&1
        fi

        force_chain="${name_chain}_force"
        if "$family" -w -t "$table" -nL "$force_chain" >/dev/null 2>&1; then
            "$family" -w -t "$table" -F "$force_chain" >/dev/null 2>&1
            "$family" -w -t "$table" -X "$force_chain" >/dev/null 2>&1
        fi
    }

    for family in iptables ip6tables; do
        for chain in nat mangle; do
            clean_run "$family" "$chain" "$name_chain"
        done
    done

    if command -v ip >/dev/null 2>&1; then
        for family in 4 6; do
            while ip -"$family" rule del fwmark "$table_mark" lookup "$table_id" >/dev/null 2>&1; do :; done
            ip -"$family" route flush table "$table_id" >/dev/null 2>&1 || true
        done
    fi

    # Очистка и удаление списков ipset
    if command -v ipset >/dev/null 2>&1; then
        for set in geo_override geo_override6 geo_exclude geo_exclude6 user_exclude user_exclude6 "$name_ipset_deny_mac"; do
            ipset flush "$set" >/dev/null 2>&1
            ipset destroy "$set" >/dev/null 2>&1
        done
    fi

    # Schedule.d-hook идемпотентно перегенерируется в configure_firewall,
    # на остановке убираем чтобы NDM не дёргал мёртвый netfilter.d/proxy.sh.
    [ -f "$file_schedule_hook" ] && rm -f "$file_schedule_hook"
}

# Мониторинг файловых дескрипторов
monitor_fd() {
    while true; do
        client_pid=$(pidof "$name_client" | awk '{print $1}')
        if [ -n "$client_pid" ] && [ -d "/proc/$client_pid/fd" ]; then
            limit=$(awk '/Max open files/ {print $4}' "/proc/$client_pid/limits")
            set -- /proc/$client_pid/fd/*
            [ -e "$1" ] || set --
            current=$#
            if [ "$limit" -gt 0 ] && [ "$current" -gt $((limit * 90 / 100)) ]; then
                log_warning_router "$name_client открыл $current из $limit файловых дескрипторов, инициирован перезапуск"
                rm -f "$file_pid_fd"
                fd_out=true
                proxy_stop
                proxy_start "on"
                exit 0
            fi
        fi
        sleep "$delay_fd"
    done
}

load_ipset() {
    set="$1"
    file="$2"
    family="$3"
    tmp="${set}_tmp"

    # Заполняем tmp; основной набор подменяется только после успешного restore
    ipset create "$set" hash:net family "$family" -exist
    ipset create "$tmp" hash:net family "$family" -exist
    ipset flush "$tmp"

    if [ -f "$file" ] && sed -e 's/\r$//' -e 's/#.*//' -e '/^[[:space:]]*$/d' "$file" | awk '{print "add '"$tmp"' "$1}' | ipset restore -exist; then
        ipset swap "$set" "$tmp"
    fi
    ipset destroy "$tmp"
}

apply_fd_limit() {
    fd_limit="$other_fd"
    [ "$architecture" = "arm64-v8a" ] && fd_limit="$arm64_fd"
    ulimit -SHn "$fd_limit"
}

cleanup_fd_monitor() {
    [ -f "$file_pid_fd" ] || return 0
    kill "$(cat "$file_pid_fd")" 2>/dev/null
    rm -f "$file_pid_fd"
}

missing_files_template='
  '"${light_blue}"'Отсутствуют исполняемые файлы:'"${reset}"'
  '"${yellow}"'%b'"${reset}"'

  '"${green}"'Возможные причины:'"${reset}"'
  • XKeen установлен во внутреннюю память и на ней недостаточно места
  • У файла отсутствуют права на выполнение

  '"${green}"'Рекомендуемые действия:'"${reset}"'
  • Переустановите XKeen на внешний накопитель
  • Скопируйте недостающий файл вручную и сделайте исполняемым
'

check_binary() {
    file="$1"
    path="$install_dir/$file"

    if [ ! -f "$path" ] || [ ! -x "$path" ]; then
        return 1
    fi

    check_cmd="version"
    [ "$file" = "xray" ] && check_cmd="version"
    [ "$file" = "yq" ] && check_cmd="--version"
    [ "$file" = "mihomo" ] && check_cmd="-v"

    if ! "$file" $check_cmd >/dev/null 2>&1; then
        log_error_router "Бинарный файл $file аварийно остановлен"
        log_error_terminal "
  Бинарный файл ${yellow}$file${reset} аварийно остановлен
  ${red}Файл повреждён или несовместим с процессором${reset} вашего роутера
  Установите другую версию ${yellow}$file${reset}
"
    fi

    return 0
}

info_health_binary() {
    missing_files=""

    add_to_missing() {
        file_name="$1"
        prefix="  - " 
        
        if [ -z "$missing_files" ]; then
            missing_files="${prefix}${yellow}${file_name}${reset}"
        else
            missing_files="${missing_files}\n  ${prefix}${yellow}${file_name}${reset}"
        fi
    }

    case "$name_client" in
        xray)
            if ! check_binary xray; then add_to_missing "xray"; fi
            ;;
       mihomo)
            for file in mihomo yq; do
                if ! check_binary "$file"; then add_to_missing "$file"; fi
            done
            ;;
        esac

    if [ -n "$missing_files" ]; then
        log_error_terminal "$(printf "$missing_files_template" "$missing_files")"
    fi
}

# Атомарный single-instance guard на cold_start. mkdir — POSIX-атомарен,
# единственный надёжный lock в busybox-ash без flock. Закрывает гонку
# повторного S05xkeen start от NDM (fs.d + init.d + reconnect-триггеры).
# Flag-файл xkeen_coldstart.lock сохранён для совместимости с условиями
# подавления логов в proxy_start/proxy_stop ("[ -f lock ] || log_info_router").
# PID владельца записывает _set_coldstart_pid после `nohup cold_start &` —
# текущий $$ это caller (S05xkeen start), который завершается сразу;
# проверка живости должна идти по PID фонового cold_start ($!).
_acquire_coldstart_guard() {
    if mkdir "/tmp/xkeen_coldstart.lock.d" 2>/dev/null; then
        touch "/tmp/xkeen_coldstart.lock"
        return 0
    fi
    _gpid=$(cat "/tmp/xkeen_coldstart.lock.d/pid" 2>/dev/null)
    if [ -n "$_gpid" ] && kill -0 "$_gpid" 2>/dev/null; then
        return 1
    fi
    # Без PID файла — guard свежий (caller ещё не дошёл до _set_coldstart_pid).
    # Не сбрасываем: иначе теряем защиту в окне между mkdir и записью PID.
    [ -z "$_gpid" ] && return 1
    # PID есть, но процесс мёртв → stale, перехват
    rm -rf "/tmp/xkeen_coldstart.lock.d"
    mkdir "/tmp/xkeen_coldstart.lock.d" 2>/dev/null || return 1
    touch "/tmp/xkeen_coldstart.lock"
    return 0
}

_set_coldstart_pid() {
    [ -d "/tmp/xkeen_coldstart.lock.d" ] || return 0
    echo "$1" > "/tmp/xkeen_coldstart.lock.d/pid"
}

_release_coldstart_guard() {
    rm -rf "/tmp/xkeen_coldstart.lock.d"
    rm -f "/tmp/xkeen_coldstart.lock"
}

# Защита от параллельного входа в proxy_start/proxy_stop из двух
# триггеров (cold_start vs xkeen -restart, два S05xkeen start
# подряд от NDM и т.п.). Второй конкурент тихо выходит.
# rc=0  — захватили; rc=1 — реальный конкурент; rc=2 — re-entrant
# (тот же процесс уже владеет mutex'ом, например proxy_start вложенно
# вызывает proxy_stop при TProxy 443-конфликте — не релизим).
_acquire_proxy_mutex() {
    if mkdir "/tmp/xkeen_proxy.mutex.d" 2>/dev/null; then
        echo $$ > "/tmp/xkeen_proxy.mutex.d/pid"
        return 0
    fi
    _mpid=$(cat "/tmp/xkeen_proxy.mutex.d/pid" 2>/dev/null)
    if [ "$_mpid" = "$$" ]; then
        return 2
    fi
    if [ -n "$_mpid" ] && kill -0 "$_mpid" 2>/dev/null; then
        return 1
    fi
    rm -rf "/tmp/xkeen_proxy.mutex.d"
    mkdir "/tmp/xkeen_proxy.mutex.d" 2>/dev/null || return 1
    echo $$ > "/tmp/xkeen_proxy.mutex.d/pid"
    return 0
}

_release_proxy_mutex() {
    rm -rf "/tmp/xkeen_proxy.mutex.d"
}

# Очистка при аварийной остановке прокси-клиента
emergency_clear() {
    rm -f "/tmp/xkeen_ready"
    _release_coldstart_guard
    cleanup_fd_monitor
    clean_firewall
}

# Запуск прокси-клиента
proxy_start() {
    _acquire_proxy_mutex
    _ps_mutex_rc=$?
    if [ "$_ps_mutex_rc" -eq 1 ]; then
        return 0
    fi
    if [ "$_ps_mutex_rc" -eq 0 ]; then
        trap '_release_proxy_mutex; trap - INT TERM HUP' INT TERM HUP
    fi
    start_manual="$1"
    if [ "$start_manual" = "on" ] || [ "$start_auto" = "on" ]; then
        _invalidate_inbounds_cache
        apply_ipv6_state
        get_ipver_support
        info_health_binary
        validate_xkeen_json
        check_policy_name_conflict
        check_xray_backups
        api_cache_init
        policy_mark=$(get_policy_mark)
        user_policies=$(resolve_user_policies)
        validate_entware_proxy_mark
        validate_pbr_routing_mark
        log_clean
        sync_deny_mac_ipset
        process_user_ports
        process_custom_mark
        port_redirect=$(get_port_redirect)
        network_redirect=$(get_network_redirect)
        port_tproxy=$(get_port_tproxy)
        network_tproxy=$(get_network_tproxy)
        mode_proxy=$(get_mode_proxy)
        if [ "$mode_proxy" != "Other" ]; then

            if [ -n "$policy_mark" ]; then
                if [ -n "$user_policies" ]; then
                    print_policy_info "yes" "yes"
                else
                    print_policy_info "yes" "no"
                fi
            else
                raw_user_policies=$(get_user_policies)
                ignored_custom="no"

                if [ -n "$raw_user_policies" ]; then
                    ignored_custom="yes"
                fi

                print_policy_info "no" "no" "$ignored_custom"

                user_policies=""
            fi

            networks=$(printf '%s\n' $network_redirect $network_tproxy | tr ',' ' ' | tr -s ' ' '\n' | sort -u | tr '\n' ' ')
            networks=${networks% }

            if [ -n "$policy_mark" ] && [ -z "$port_donor" ]; then
                port_exclude=$(get_port_exclude)
            fi
            if ! proxy_status && { [ -n "$port_donor" ] || [ -n "$port_exclude" ] || [ "$mode_proxy" = "TProxy" ] || [ "$mode_proxy" = "Hybrid" ]; }; then
                get_modules
            fi
            configure_dscp_force_proxy
            if [ "$mode_proxy" = "TProxy" ]; then
                keenetic_ssl="$(get_keenetic_port)" || {
                    proxy_stop
                    log_error_router "Порт 443 занят сервисами Keenetic"
                    log_error_terminal "
  Необходимый для режима ${light_blue}TProxy${reset} ${red}443 порт занят${reset} сервисами Keenetic

  Освободите его на странице 'Пользователи и доступ' веб-интерфейса роутера
"
                }
            fi
        fi
        if proxy_status; then
            echo -e "  Прокси-клиент уже ${green}запущен${reset}"
            # Marker до configure_firewall: тот завершается `sh proxy.sh`,
            # gate в хуке читает /tmp/xkeen_ready.
            touch "/tmp/xkeen_ready"
            [ "$mode_proxy" != "Other" ] && configure_firewall
            if [ "$start_manual" = "on" ]; then
                log_error_terminal "Не удалось запустить ${yellow}$name_client${reset}, так как он уже запущен"
            else
                log_info_router "Прокси-клиент успешно запущен в режиме $mode_proxy"
                _release_coldstart_guard
            fi
        else
            log_info_router "Инициирован запуск прокси-клиента"
            attempt=1
            . "$file_cpu"
            info_cpu
            export SSL_CERT_FILE="$file_ca"
            while [ "$attempt" -le "$start_attempts" ]; do
                case "$name_client" in
                    xray)
                        export XRAY_LOCATION_CONFDIR="$directory_xray_config"
                        export XRAY_LOCATION_ASSET="$directory_xray_asset"
                        find "$directory_xray_config" -maxdepth 1 -name '._*.json' -type f -delete
                        apply_fd_limit
                        if [ -n "$fd_out" ]; then
                            nohup "$name_client" run >/dev/null 2>&1 &
                            unset fd_out
                        else
                            if [ "$start_verbose" = "on" ]; then
                                "$name_client" run &
                            else
                                "$name_client" run >/dev/null 2>&1 &
                            fi
                        fi
                    ;;
                    mihomo)
                        export CLASH_HOME_DIR="$directory_configs_app"
                        apply_fd_limit
                        if [ -n "$fd_out" ]; then
                            nohup "$name_client" >/dev/null 2>&1 &
                            unset fd_out
                        else
                            if [ "$start_verbose" = "on" ]; then
                                "$name_client" &
                            else
                                "$name_client" >/dev/null 2>&1 &
                            fi
                        fi
                        ;;
                    *) log_error_terminal "Неизвестный прокси-клиент: ${yellow}$name_client${reset}" ;;
                esac
                _probe_attempt=0
                while [ "$_probe_attempt" -lt 60 ]; do
                    proxy_status && break
                    _probe_attempt=$((_probe_attempt + 1))
                    usleep 50000
                done
                unset _probe_attempt
                if proxy_status; then
                    # См. alive-branch: marker до configure_firewall.
                    touch "/tmp/xkeen_ready"
                    [ "$mode_proxy" != "Other" ] && configure_firewall
                    _pids=""
                    [ "$iptables_supported" = "true" ] && [ -f "$ru_exclude_ipv4" ] && { load_ipset geo_exclude "$ru_exclude_ipv4" inet & _pids="$_pids $!"; }
                    [ "$ip6tables_supported" = "true" ] && [ -f "$ru_exclude_ipv6" ] && { load_ipset geo_exclude6 "$ru_exclude_ipv6" inet6 & _pids="$_pids $!"; }
                    load_user_ipset & _pids="$_pids $!"
                    [ -n "$_pids" ] && wait $_pids
                    unset _pids
                    echo -e "  Прокси-клиент ${green}запущен${reset} в режиме ${light_blue}${mode_proxy}${reset}"
                    (
                        # Даём ядру прокси время полностью инициализироваться
                        # Это защищает от ситуаций, когда xray/mihomo
                        # успевает создать PID, но затем аварийно завершается,
                        # например, из-за битой конфигурации
                        sleep 3

                        if ! proxy_status; then
                            echo
                            echo -e "  Прокси-клиент ${red}аварийно завершился${reset}"
                            echo -e "  ${green}Выполняется очистка${reset} правил прозрачного проксирования"
                            log_error_router "Прокси-клиент аварийно завершился после запуска"
                            emergency_clear
                            printf '\n~ # '
                        fi
                    ) &
                    if [ -n "$api_policy_json" ]; then
                        if echo "$api_policy_json" | jq --arg policy "$name_policy" -e 'any(.[]; .description | ascii_downcase == $policy)' > /dev/null; then
                            if [ -e "/tmp/noinet" ]; then
                                echo
                                echo -e "  У политики ${yellow}$name_policy${reset} ${red}нет доступа в интернет${reset}"
                                echo "  Проверьте, установлена ли галка на подключении к провайдеру"
                            fi
                        fi
                    fi
                    [ "$mode_proxy" = "Other" ] && echo -e "  Функция прозрачного прокси ${red}не активна${reset}. Направляйте соединения на ${yellow}${name_client}${reset} вручную"
                    log_info_router "Прокси-клиент успешно запущен в режиме $mode_proxy"
                    _release_coldstart_guard
                    if [ "$check_fd" = "on" ]; then
                        cleanup_fd_monitor
                        monitor_fd &
                        echo $! > "$file_pid_fd"
                        log_info_router "Запущен контроль файловых дескрипторов $name_client"
                    fi
                    if [ "$_ps_mutex_rc" -eq 0 ]; then
                        _release_proxy_mutex
                        trap - INT TERM HUP
                    fi
                    return 0
                fi
                attempt=$((attempt + 1))
            done
            echo -e "  ${red}Не удалось запустить${reset} прокси-клиент"
            log_error_terminal "Не удалось запустить прокси-клиент"
            _release_coldstart_guard
        fi
    else
        clean_firewall
    fi
    if [ "$_ps_mutex_rc" -eq 0 ]; then
        _release_proxy_mutex
        trap - INT TERM HUP
    fi
}

# Активная проба готовности окружения вместо sleep $start_delay.
# Ждём ndmc, default route и insmod-ability xt_TPROXY (deps ndm
# подгружает асинхронно уже после ndmc-ready). $start_delay сохранён
# как safety cap (FAQ #12).
wait_for_ready() {
    _max=$(( ${start_delay:-60} * 2 ))
    _attempt=0
    _probe_ko=$(find_module_path "xt_TPROXY.ko")

    while [ "$_attempt" -lt "$_max" ]; do
        if ip route show default 2>/dev/null | grep -q '^default'; then
            # Проверка готовности API политик и модуля xt_TPROXY
            api_policy_json=$(curl_api "${url_server}/${url_policy}" 2>/dev/null)
            case "$api_policy_json" in
                ""|"{}")
                    ;;
                \{*)
                    if [ -z "$_probe_ko" ] \
                       || grep -q '^xt_TPROXY ' /proc/modules 2>/dev/null \
                       || insmod "$_probe_ko" >/dev/null 2>&1
                    then
                        return 0
                    fi
                    ;;
            esac
        fi
        usleep 500000
        _attempt=$((_attempt + 1))
    done
    return 0
}

# Остановка прокси-клиента
proxy_stop() {
    _acquire_proxy_mutex
    _pstop_mutex_rc=$?
    if [ "$_pstop_mutex_rc" -eq 1 ]; then
        return 0
    fi
    if [ "$_pstop_mutex_rc" -eq 0 ]; then
        trap '_release_proxy_mutex; trap - INT TERM HUP' INT TERM HUP
    fi
    rm -f "/tmp/xkeen_ready"
    if ! proxy_status; then
        echo -e "  Прокси-клиент ${red}не запущен${reset}"
        cleanup_fd_monitor
    else
        [ -f "/tmp/xkeen_coldstart.lock" ] || log_info_router "Инициирована остановка прокси-клиента"
        cleanup_fd_monitor
        attempt=1
        while [ "$attempt" -le "$start_attempts" ]; do
            clean_firewall
            killall -q "$name_client" 2>/dev/null
            _stop_attempt=0
            while [ "$_stop_attempt" -lt 30 ]; do
                pidof "$name_client" >/dev/null 2>&1 || break
                _stop_attempt=$((_stop_attempt + 1))
                usleep 50000
            done
            unset _stop_attempt
            if pidof "$name_client" >/dev/null 2>&1; then
                killall -q -9 "$name_client" 2>/dev/null
                usleep 200000
            fi
            if ! proxy_status; then
                echo -e "  Прокси-клиент ${red}остановлен${reset}"
                [ -f "/tmp/xkeen_coldstart.lock" ] || log_info_router "Прокси-клиент успешно остановлен"
                _release_coldstart_guard
                if [ "$_pstop_mutex_rc" -eq 0 ]; then
                    _release_proxy_mutex
                    trap - INT TERM HUP
                fi
                return 0
            fi
            attempt=$((attempt + 1))
        done
        echo -e "  Прокси-клиент ${red}не удалось остановить${reset}"
        log_error_terminal "Не удалось остановить прокси-клиент"
    fi
    if [ "$_pstop_mutex_rc" -eq 0 ]; then
        _release_proxy_mutex
        trap - INT TERM HUP
    fi
}

# Менеджер команд
case "$1" in
    start)
        ipset create ext_exclude hash:ip family inet -exist
        ipset create ext_exclude6 hash:ip family inet6 -exist
        if [ -z "$2" ]; then
            [ "$start_auto" != "on" ] && exit 0
            # Атомарный guard ДО spawn — повторный S05xkeen start от
            # NDM (fs.d / init.d / reconnect) увидит каталог и выйдет.
            _acquire_coldstart_guard || exit 0
            log_info_router "Подготовка к запуску прокси-клиента"
            nohup "$0" cold_start >/dev/null 2>&1 &
            # PID фонового cold_start — caller ($$) умрёт через exit 0,
            # а живость guard'а проверяется именно по этому PID.
            _set_coldstart_pid "$!"
            exit 0
        fi
        proxy_start "$2"
    ;;
    stop) proxy_stop ;;
    status)
        if proxy_status; then
            mode_proxy=""
            if [ -f "$file_netfilter_hook" ]; then
                mode_proxy=$(grep '^mode_proxy=' "$file_netfilter_hook" | awk -F"=" '{print $2}' | tr -d "'" 2>/dev/null)
            fi
            [ -z "$mode_proxy" ] && mode_proxy="Other"
            echo -e "  Прокси-клиент ${yellow}$name_client${reset} ${green}запущен${reset} в режиме ${light_blue}$mode_proxy${reset}"
        else
            echo -e "  Прокси-клиент ${red}не запущен${reset}"
        fi
        ;;
    dscp)
        if [ "$dscp_enable" != "off" ]; then
            echo
            print_dscp_force_proxy_status
        fi
        ;;
    restart) proxy_stop; proxy_start "$2" ;;
    cold_start)
        # Подстраховка: переписываем PID guard'а на свой ($$) на случай,
        # если caller-S05xkeen умер до того, как успел _set_coldstart_pid "$!".
        _set_coldstart_pid "$$"
        # Гарантированная задержка перед попыткой запуска прокси-клиента
        if [ -n "$init_delay" ] && [ "$init_delay" -gt 0 ] 2>/dev/null; then
            log_info_router "Ожидание перед проверкой готовности к запуску XKeen (${init_delay} сек...)"
            sleep "$init_delay"
        fi
        # Re-spawn в чистый S05xkeen: sh-функции (wait_for_ready) не
        # наследуются через nohup sh -c, поэтому пробу зовём отсюда.
        wait_for_ready
        proxy_start ""
        ;;
    *) echo -e "  Команды: ${green}start${reset} | ${red}stop${reset} | ${yellow}restart${reset} | status" ;;
esac

exit 0
