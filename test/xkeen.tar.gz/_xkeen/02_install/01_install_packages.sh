# Установка необходимых пакетов
install_packages() {
    package_status="$1"
    package_name="$2"

    if [ "${package_status}" = "not_installed" ]; then
        _xkeen_rundir=$(_xkeen_secure_rundir) || _xkeen_rundir=""
        if [ -z "$_xkeen_rundir" ] || [ ! -e "$_xkeen_rundir/opkg_updated" ]; then
            opkg update >/dev/null 2>&1 && [ -n "$_xkeen_rundir" ] && touch "$_xkeen_rundir/opkg_updated"
        fi
        opkg install "$package_name" >/dev/null 2>&1
        opkg_rc=$?
        if [ "$opkg_rc" -ne 0 ]; then
            echo "  Ошибка установки пакета: $package_name (opkg rc=$opkg_rc)" >&2
            return 1
        fi
    fi
}

# Устанавливает отсутствующие пакеты по данным _load_packages_info().
# Вызывается явно из scripts/xkeen вместе с _load_packages_info() — см. commit.
_ensure_installed_packages() {
    install_packages "$info_packages_curl" "curl"
    install_packages "$info_packages_jq" "jq"
    install_packages "$info_packages_ip_full" "ip-full"
    install_packages "$info_packages_iptables" "iptables"
    install_packages "$info_packages_ipset" "ipset"
    install_packages "$info_packages_cabundle" "ca-bundle"
    install_packages "$info_packages_uname" "coreutils-uname"
    install_packages "$info_packages_nohup" "coreutils-nohup"
}