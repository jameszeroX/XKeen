#Блок логирования

# Модули логирования
. "$xtools_dir/01_tools_logs/01_logs_clear.sh"
. "$xtools_dir/01_tools_logs/02_logs_console.sh"
. "$xtools_dir/01_tools_logs/03_logs_xkeen.sh"
